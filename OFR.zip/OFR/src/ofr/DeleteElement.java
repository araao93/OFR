/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;

import java.awt.Font;
import javax.swing.JLabel;
import java.util.function.Predicate;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
/**
 *
 * @author anton
 */
public class DeleteElement extends javax.swing.JInternalFrame{
    InstanceReport instanceReport;
    //this variable stores this software's internal index of the XBRL added elements, during the deletion process
    int genericIndex;
    //initializing strings to store the error messages text
    String M_Error08,M_Error09,M_Error10,M_Error11,M_Error12,M_Error24;
    //initializing strings to store the success messages text
    String M_Suc03;    
    //initializing log text area
    JTextArea LogTextArea;
    //String for JOprionPane Boxes Title
    String jopTitle; 
    int InsertOption;
    /**
     * Creates new form AddElement
     */
    public DeleteElement() {
        initComponents();
        // cleaning comboboxes
        AvailableStatementIdComboBox.removeAllItems();
        AvailableContextIdComboBox.removeAllItems();
        AvailableUnitIdComboBox.removeAllItems();
        NoteSelectionComboBox.removeAllItems();
        AvailableStatementContextComboBox.removeAllItems();
        Font newCheckBoxFont=new Font(ContextCheckBox.getFont().getName(),Font.ITALIC+Font.BOLD,ContextCheckBox.getFont().getSize());
        StatementCheckBox.setFont(newCheckBoxFont);
        ContextCheckBox.setFont(newCheckBoxFont);
        UnitCheckBox.setFont(newCheckBoxFont);
        NoteCheckBox.setFont(newCheckBoxFont);        
    }
    public void updateReport (InstanceReport instanceReport){
    this.instanceReport=instanceReport;
    //adding each report item to its proper combobox
        if(!this.instanceReport.contextList.isEmpty()){
            for(ContextDeclaration context : instanceReport.contextList){
                if(AvailableContextIdComboBox.getItemCount()==0){
                    AvailableContextIdComboBox.addItem(context.getId());
                    AvailableStatementContextComboBox.addItem(context.getId());
                }else{
                    boolean exist=false;
                    for(int j=0;j<AvailableContextIdComboBox.getItemCount();j++){
                        if(context.getId().equals(AvailableContextIdComboBox.getItemAt(j))){
                            exist=true;
                        }
                    }
                    if(!exist){
                        AvailableContextIdComboBox.addItem(context.getId());
                        AvailableStatementContextComboBox.addItem(context.getId());
                    }
                }                                                
            }
        }
        if(!this.instanceReport.unitList.isEmpty()){
            AvailableUnitIdComboBox.removeAllItems();
            for(UnitDeclaration unit : instanceReport.unitList){            
                AvailableUnitIdComboBox.addItem(unit.getId());
            }
        }
        if(!this.instanceReport.statementList.isEmpty()){
            for(StatementDeclaration statement : instanceReport.statementList){            
                if(AvailableStatementIdComboBox.getItemCount()==0){
                    AvailableStatementIdComboBox.addItem(statement.getId());
                }else{
                    boolean exist=false;
                    for(int j=0;j<AvailableStatementIdComboBox.getItemCount();j++){
                        if(statement.getId().equals(AvailableStatementIdComboBox.getItemAt(j))){
                            exist=true;
                        }
                    }
                    if(!exist){
                        AvailableStatementIdComboBox.addItem(statement.getId());
                    }
                }                            
            }
        }
        if(!this.instanceReport.noteList.isEmpty()){
            int i = 0;
            NoteSelectionComboBox.removeAllItems();
            for(NonNumericDeclaration note : instanceReport.noteList){                
                    NoteSelectionComboBox.addItem(note.getLabel()+String.valueOf(i+1));
                    i++;
            }
        }        
    }    
    public void Logloader(JTextArea LogTextArea){
        this.LogTextArea = LogTextArea;        
    }
        public void InsertOptionUpdate(int x){
        this.InsertOption=x;        
        if (this.InsertOption==1){
            ContextCheckBox.doClick();
        }else{
            if(this.InsertOption==2){
                UnitCheckBox.doClick();
            }else{
                if(this.InsertOption==3){
                    StatementCheckBox.doClick();
                }else{
                    if(this.InsertOption==4){
                        NoteCheckBox.doClick();
                    }
                }
            }
        }
    }
    public void LocateStatement(InstanceReport instanceReport){
        this.instanceReport=instanceReport;
        //Defining string variables to search for the desired statement  
        String statementIdChecker,contextIdChecker;
        //Checking for statement information availability
        if((AvailableStatementIdComboBox.getItemCount() != 0)&&(AvailableStatementContextComboBox.getItemCount() != 0)){
            statementIdChecker=AvailableStatementIdComboBox.getSelectedItem().toString();
            contextIdChecker=AvailableStatementContextComboBox.getSelectedItem().toString();
            for(StatementDeclaration statement : instanceReport.statementList){
                if((statementIdChecker.equals(statement.getId()))&&(contextIdChecker.equals(statement.getContextRef()))){
                StatementValueDynamicLabel.setText(statement.getValue());
                StatementDecimalsDynamicLabel.setText(statement.getDecimals());
                StatementUnitsDynamicLabel.setText(statement.getUnitRef());
                genericIndex=statement.getIndex();
                }                
            }
        }            
    }
    public void LocateContext(InstanceReport instanceReport){
        this.instanceReport=instanceReport;
        //Defining a string variable to search for the desired context
        String contextIdChecker;
        //Checking for context information availability
        if(AvailableContextIdComboBox.getItemCount() != 0){
            contextIdChecker=AvailableContextIdComboBox.getSelectedItem().toString();
            for(ContextDeclaration context : instanceReport.contextList){
                if(contextIdChecker.equals(context.getId())){
                    //varibles to store the upper substring limiter index. It allows showing item's names in the labels free from software stuff.
                    int axisSubstringIndex,memberSubstringIndex;
                    axisSubstringIndex=context.getExplicitMemberDimension().length();
                    memberSubstringIndex=context.getSiconfiDimension().length();
                    SiconfiCodeDynamicLabel.setText(context.getEntityIdentifier());
                    ContextAxisDynamicLabel.setText(context.getExplicitMemberDimension().substring(12,axisSubstringIndex-4));
                    StartDateDynamicLabel.setText(context.getPeriodStartDate());
                    EndDateDynamicLabel.setText(context.getPeriodEndDate());
                    SchemaDynamicLabel.setText(context.getEntityScheme());
                    ContextMemberDynamicLabel.setText(context.getSiconfiDimension().substring(12,memberSubstringIndex-6));
                    if(context.getHasCoupledAxis()){
                        int secondaryAxisSubstringIndex,secondaryMemberSubstringIndex;
                        secondaryAxisSubstringIndex=context.getSecondaryExplicitMemberDimension().length();
                        secondaryMemberSubstringIndex=context.getSecondarySiconfiDimension().length();
                        SecondaryContextAxisDynamicLabel.setText(context.getSecondaryExplicitMemberDimension().substring(12,secondaryAxisSubstringIndex-4));
                        SecondaryContextDimensionDynamicLabel.setText(context.getSecondarySiconfiDimension().substring(12,secondaryMemberSubstringIndex-6));                        
                    }else{
                        SecondaryContextAxisDynamicLabel.setText("");
                        SecondaryContextDimensionDynamicLabel.setText("");
                    }
                }
            }
        }
    }
    public void LocateUnit(InstanceReport instanceReport){
        this.instanceReport=instanceReport;
        //Defining a string variable to search for the desired context
        String UnitIdChecker;
        //Checking for context information availability
        if(AvailableUnitIdComboBox.getItemCount() != 0){
            UnitIdChecker=AvailableUnitIdComboBox.getSelectedItem().toString();
            for(UnitDeclaration unit : instanceReport.unitList){
                if(UnitIdChecker.equals(unit.getId())){
                    ISOCodeDynamicLabel.setText(unit.getISOIdentifier().substring(8));
                }
            }
        }
    }
    public void LocateNote(InstanceReport instanceReport){
        this.instanceReport=instanceReport;
        //Defining string variables to search for the desired context
        String NoteContexChecker,NoteContentChecker;
        int NotePosition;
        //Checking for context information availability
        if(NoteSelectionComboBox.getItemCount() != 0){
            NotePosition=Integer.valueOf(NoteSelectionComboBox.getSelectedItem().toString().substring(18));
            NonNumericDeclaration note = instanceReport.noteList.get(NotePosition-1);            
            NoteContentDynamicLabel.setText(note.getContent());
            NoteContextRefDynamicLabel.setText(note.getContextRef());
        }        
    }
    public void CheckBoxReset () {
        if(StatementCheckBox.isSelected()){StatementCheckBox.doClick();}
        if(ContextCheckBox.isSelected()){ContextCheckBox.doClick();}
        if(UnitCheckBox.isSelected()){UnitCheckBox.doClick();}
        if(NoteCheckBox.isSelected()){NoteCheckBox.doClick();}    
    }
    public void LanguageSelection(String language){
        if(language.equals("EN")){
            //frame title
            this.setTitle("Element exclusion manager");
            //labels
            StatementTagLabel.setText("Account tag");
            StatementCheckBox.setText("Account");
            StatementValueLabel.setText("Value");
            StatementDecimalsLabel.setText("Decimals");
            StatementUnitLabel.setText("Unit");
            StatementContextLabel.setText("Context");
            ContextIdLabel.setText("Name");
            ContextCheckBox.setText("Context");
            SiconfiCodeLabel.setText("Institution's code");
            ContextAxisLabel.setText("Context axis");
            StartDateLabel.setText("Start date");
            EndDateLabel.setText("End date");
            SchemaLabel.setText("Schema");
            ContextDimensionLabel.setText("Context dimension");
            StartDateFormatLabel.setText("YYYY-MM-DD");
            EndDateFormatLabel.setText("YYYY-MM-DD");
            UnitNameLabel.setText("Unit name");
            ISOCodeLabel.setText("ISO code");
            UnitCheckBox.setText("Unit");
            NoteContentLabel.setText("Description");
            NoteContextRefLabel.setText("Context");
            NoteCheckBox.setText("Non numeric");
            NoteSelectorLabel.setText("Selected non numeric element");
            SecondaryContextAxisLabel.setText("Secondary Context Axis");
            SecondaryContextDimensionLabel.setText("Secondary Context Dimension");            
            //buttons
            DeleteButton.setText("Delete");
            CancelButton.setText("Cancel");
            //error messages
            M_Error08="Please, make sure to add a context and an account before trying to delete an account.";
            M_Error09="Please, make sure to add a context before trying to delete one.";
            M_Error10="Please, make sure to add a unit before trying to delete one.";
            M_Error11="Please, make sure to add an explanatory note before trying to delete one.";
            M_Error12="It was not possible to delete the desired element. Please, review your data input and try again.";
            M_Error24="The selected element is still bonded to other elements";
            //success messages
            M_Suc03="Element successfully deleted.";
            //JOptionPane
            jopTitle="WARN";
            AvailableContextIdComboBox.setToolTipText("Choose the Name of the context you want to remove.");
            AvailableUnitIdComboBox.setToolTipText("Choose the Name of the unit you want to remove.");
            AvailableStatementIdComboBox.setToolTipText("Choose the tag of the account you want to remove.");
            AvailableStatementContextComboBox.setToolTipText("Choose the context of the account you want to remove.");
            NoteSelectionComboBox.setToolTipText("Choose the non numeric element you want to remove.");            
        }else{
            if(language.equals("PT")){
                //frame title
                this.setTitle("Gerenciador de exclusão de elementos");
                //labels
                StatementTagLabel.setText("Tag da conta");
                StatementCheckBox.setText("Conta");
                StatementValueLabel.setText("Valor");
                StatementDecimalsLabel.setText("Decimais");
                StatementUnitLabel.setText("Unidade");
                StatementContextLabel.setText("Contexto");
                ContextIdLabel.setText("Nome");
                ContextCheckBox.setText("Contexto");
                SiconfiCodeLabel.setText("Código da Instituição");
                ContextAxisLabel.setText("Eixo do contexto");
                StartDateLabel.setText("Início");
                EndDateLabel.setText("Término");
                SchemaLabel.setText("Schema");
                ContextDimensionLabel.setText("Dimensão do contexto");
                StartDateFormatLabel.setText("AAAA-MM-DD");
                EndDateFormatLabel.setText("AAAA-MM-DD");
                UnitNameLabel.setText("Nome da unidade");
                ISOCodeLabel.setText("Código ISO");
                UnitCheckBox.setText("Unidade");
                NoteContentLabel.setText("Descrição");
                NoteContextRefLabel.setText("Contexto");
                NoteCheckBox.setText("Não numérico");
                NoteSelectorLabel.setText("Elemento não numérico selecionado");
                SecondaryContextAxisLabel.setText("Eixo secundário do contexto");
                SecondaryContextDimensionLabel.setText("Dimensão secundária do contexto");                 
                //buttons
                DeleteButton.setText("Remover");
                CancelButton.setText("Cancelar");
                //error messages
                M_Error08="Por favor, certifique-se de adicionar um contexto e uma conta antes de tentar deletar uma conta.";
                M_Error09="Por favor, certifique-se de adicionar um contexto antes de tentar deletar um.";
                M_Error10="Por favor, certifique-se de adicionar uma unidade antes de tentar deletar uma.";
                M_Error11="Por favor, certifique-se de adicionar uma nota explicativa antes de tentar deletar uma.";
                M_Error12="Não foi possível remover o elemento desejado. Por favor, revise os dados fornecidos e tente novamente.";                
                M_Error24="O elemento ainda está ligado à outros elementos do relatório.";
                //success messages
                M_Suc03="Elemento removido com sucesso."; 
                //JOptionPane
                jopTitle="AVISO";  
                AvailableContextIdComboBox.setToolTipText("Escolha o nome do contexto que você quer editar.");
                AvailableUnitIdComboBox.setToolTipText("Escolha o nome da unidade que você quer editar.");
                AvailableStatementIdComboBox.setToolTipText("Escolha o tag da conta que você quer editar.");
                AvailableStatementContextComboBox.setToolTipText("Escolha o contexto da conta que você quer editar.");
                NoteSelectionComboBox.setToolTipText("Escolha o elemento não numérico que você quer editar.");                 
            }else{
                //frame title
                this.setTitle("Gestor de exclusión de elementos");
                //labels
                StatementTagLabel.setText("Etiqueta de cuenta");
                StatementCheckBox.setText("Cuenta");
                StatementValueLabel.setText("Valor");
                StatementDecimalsLabel.setText("Decimales");
                StatementUnitLabel.setText("Unidad de valor");
                StatementContextLabel.setText("Contexto");
                ContextIdLabel.setText("Nombre");
                ContextCheckBox.setText("Contexto");
                SiconfiCodeLabel.setText("Código de la institución");
                ContextAxisLabel.setText("Eje de contexto");
                StartDateLabel.setText("Fecha de inicio");
                EndDateLabel.setText("Fecha final");
                SchemaLabel.setText("Schema");
                ContextDimensionLabel.setText("Dimensión de contexto");
                StartDateFormatLabel.setText("AAAA-MM-DD");
                EndDateFormatLabel.setText("AAAA-MM-DD");
                UnitNameLabel.setText("Código de la unidad de valor");
                ISOCodeLabel.setText("Código ISO");
                UnitCheckBox.setText("Unidad de valor");
                NoteContentLabel.setText("Descripción");
                NoteContextRefLabel.setText("Contexto");
                NoteCheckBox.setText("No numérico");
                NoteSelectorLabel.setText("Elemento no numérico seleccionado");
                SecondaryContextAxisLabel.setText("Eje de contexto secundario");
                SecondaryContextDimensionLabel.setText("Dimensión de contexto secundaria");                
                //buttons
                DeleteButton.setText("Eliminar");
                CancelButton.setText("Cancelar");
                //error messages
                M_Error08="Por favor, asegúrese de agregar un contexto y un estado financiero antes de intentar eliminar un estado financiero.";
                M_Error09="Por favor, asegúrese de agregar un contexto antes de intentar eliminar uno.";
                M_Error10="Por favor, asegúrese de agregar una unidad antes de intentar eliminar una.";
                M_Error11="Por favor, asegúrese de agregar una nota explicativa antes de intentar eliminar una.";
                M_Error12="No fue posible eliminar el elemento deseado. Por favor, revise la entrada de datos e inténtelo de nuevo.";                
                M_Error24="El elemento está vinculado a otros elementos.";
                //success messages
                M_Suc03="Elemento eliminado correctamente."; 
                //JOptionPane
                jopTitle="ADVERTENCIA";
                AvailableContextIdComboBox.setToolTipText("Elija el Nombre del contexto que desea editar.");
                AvailableUnitIdComboBox.setToolTipText("Elija el nombre de la unidad que desea editar.");
                AvailableStatementIdComboBox.setToolTipText("Elija la etiqueta de la cuenta que desea editar.");
                AvailableStatementContextComboBox.setToolTipText("Elija el contexto de la cuenta que desea editar.");
                NoteSelectionComboBox.setToolTipText("Elija el elemento no numérico que desea editar.");                
            }            
        }
    }    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DeleteButton = new javax.swing.JButton();
        StatementCheckBox = new javax.swing.JCheckBox();
        ContextCheckBox = new javax.swing.JCheckBox();
        UnitCheckBox = new javax.swing.JCheckBox();
        NoteCheckBox = new javax.swing.JCheckBox();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        StatementValueLabel = new javax.swing.JLabel();
        CancelButton = new javax.swing.JButton();
        UnitNameLabel = new javax.swing.JLabel();
        ISOCodeLabel = new javax.swing.JLabel();
        AvailableStatementIdComboBox = new javax.swing.JComboBox<>();
        StatementTagLabel = new javax.swing.JLabel();
        StatementDecimalsLabel = new javax.swing.JLabel();
        StatementUnitLabel = new javax.swing.JLabel();
        StatementContextLabel = new javax.swing.JLabel();
        ContextIdLabel = new javax.swing.JLabel();
        SiconfiCodeLabel = new javax.swing.JLabel();
        ContextDimensionLabel = new javax.swing.JLabel();
        ContextAxisLabel = new javax.swing.JLabel();
        SchemaLabel = new javax.swing.JLabel();
        StartDateLabel = new javax.swing.JLabel();
        EndDateLabel = new javax.swing.JLabel();
        StartDateFormatLabel = new javax.swing.JLabel();
        EndDateFormatLabel = new javax.swing.JLabel();
        NoteContentLabel = new javax.swing.JLabel();
        NoteContextRefLabel = new javax.swing.JLabel();
        StatementValueDynamicLabel = new javax.swing.JLabel();
        StatementDecimalsDynamicLabel = new javax.swing.JLabel();
        StatementUnitsDynamicLabel = new javax.swing.JLabel();
        AvailableContextIdComboBox = new javax.swing.JComboBox<>();
        SiconfiCodeDynamicLabel = new javax.swing.JLabel();
        ContextAxisDynamicLabel = new javax.swing.JLabel();
        StartDateDynamicLabel = new javax.swing.JLabel();
        EndDateDynamicLabel = new javax.swing.JLabel();
        SchemaDynamicLabel = new javax.swing.JLabel();
        ContextMemberDynamicLabel = new javax.swing.JLabel();
        AvailableUnitIdComboBox = new javax.swing.JComboBox<>();
        ISOCodeDynamicLabel = new javax.swing.JLabel();
        NoteContentDynamicLabel = new javax.swing.JLabel();
        AvailableStatementContextComboBox = new javax.swing.JComboBox<>();
        NoteSelectionComboBox = new javax.swing.JComboBox<>();
        NoteContextRefDynamicLabel = new javax.swing.JLabel();
        NoteSelectorLabel = new javax.swing.JLabel();
        SecondaryContextAxisLabel = new javax.swing.JLabel();
        SecondaryContextDimensionLabel = new javax.swing.JLabel();
        SecondaryContextAxisDynamicLabel = new javax.swing.JLabel();
        SecondaryContextDimensionDynamicLabel = new javax.swing.JLabel();

        setTitle("Element deletion manager");
        setPreferredSize(new java.awt.Dimension(765, 590));

        DeleteButton.setText("Delete");
        DeleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteButtonActionPerformed(evt);
            }
        });

        StatementCheckBox.setText("Account");
        StatementCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StatementCheckBoxActionPerformed(evt);
            }
        });

        ContextCheckBox.setText("Context");
        ContextCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContextCheckBoxActionPerformed(evt);
            }
        });

        UnitCheckBox.setText("Unit");
        UnitCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UnitCheckBoxActionPerformed(evt);
            }
        });

        NoteCheckBox.setText("Explanatory note");
        NoteCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoteCheckBoxActionPerformed(evt);
            }
        });

        StatementValueLabel.setText("Value");

        CancelButton.setText("Cancel");
        CancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });

        UnitNameLabel.setText("Unit name");

        ISOCodeLabel.setText("ISO code");

        AvailableStatementIdComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        AvailableStatementIdComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvailableStatementIdComboBoxActionPerformed(evt);
            }
        });

        StatementTagLabel.setText("Statement tag");

        StatementDecimalsLabel.setText("Decimals");

        StatementUnitLabel.setText("Unit");

        StatementContextLabel.setText("Context");

        ContextIdLabel.setText("Context name");

        SiconfiCodeLabel.setText("Institution's code");

        ContextDimensionLabel.setText("Context Dimension");

        ContextAxisLabel.setText("Context Axis");

        SchemaLabel.setText("Schema");

        StartDateLabel.setText("Start date");

        EndDateLabel.setText("End date");

        StartDateFormatLabel.setText("YYYY-MM-DD");

        EndDateFormatLabel.setText("YYYY-MM-DD");

        NoteContentLabel.setText("Note full text ");

        NoteContextRefLabel.setText("Context Reference");

        StatementValueDynamicLabel.setText(" ");

        StatementDecimalsDynamicLabel.setText(" ");

        StatementUnitsDynamicLabel.setText(" ");

        AvailableContextIdComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        AvailableContextIdComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvailableContextIdComboBoxActionPerformed(evt);
            }
        });

        SiconfiCodeDynamicLabel.setText(" ");

        ContextAxisDynamicLabel.setText(" ");

        StartDateDynamicLabel.setText(" ");

        EndDateDynamicLabel.setText(" ");

        SchemaDynamicLabel.setText(" ");

        ContextMemberDynamicLabel.setText(" ");

        AvailableUnitIdComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        AvailableUnitIdComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvailableUnitIdComboBoxActionPerformed(evt);
            }
        });

        ISOCodeDynamicLabel.setText(" ");

        NoteContentDynamicLabel.setText(" ");

        AvailableStatementContextComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        AvailableStatementContextComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvailableStatementContextComboBoxActionPerformed(evt);
            }
        });

        NoteSelectionComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        NoteSelectionComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoteSelectionComboBoxActionPerformed(evt);
            }
        });

        NoteContextRefDynamicLabel.setText(" ");

        NoteSelectorLabel.setText("Note selector");

        SecondaryContextAxisLabel.setText("Secondary Context Axis");

        SecondaryContextDimensionLabel.setText("Secondary Context Dimension");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(13, 13, 13)
                            .addComponent(NoteCheckBox))
                        .addComponent(NoteContextRefLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(NoteContextRefDynamicLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(NoteContentDynamicLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NoteContentLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NoteSelectorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 724, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(140, 140, 140)
                        .addComponent(NoteSelectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 585, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(UnitCheckBox, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(UnitNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(AvailableUnitIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(ISOCodeDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ISOCodeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(StartDateDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(ContextCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(StartDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(StartDateFormatLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(AvailableContextIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(EndDateDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(ContextIdLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(EndDateLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(EndDateFormatLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(SiconfiCodeDynamicLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(SchemaLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(SchemaDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(SiconfiCodeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(0, 0, Short.MAX_VALUE))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(SecondaryContextAxisLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(SecondaryContextAxisDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(ContextMemberDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ContextAxisLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ContextDimensionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(SecondaryContextDimensionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(SecondaryContextDimensionDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addContainerGap(389, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ContextAxisDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(CancelButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DeleteButton)
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 727, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(StatementCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(AvailableStatementIdComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(StatementTagLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 569, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(StatementValueLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(StatementValueDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(StatementDecimalsDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(StatementDecimalsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(StatementUnitsDynamicLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(StatementUnitLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(AvailableStatementContextComboBox, 0, 162, Short.MAX_VALUE)
                                    .addComponent(StatementContextLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ContextIdLabel)
                    .addComponent(SiconfiCodeLabel)
                    .addComponent(ContextAxisLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ContextCheckBox)
                    .addComponent(AvailableContextIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SiconfiCodeDynamicLabel)
                    .addComponent(ContextAxisDynamicLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ContextDimensionLabel)
                    .addComponent(SchemaLabel)
                    .addComponent(StartDateLabel)
                    .addComponent(EndDateLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StartDateDynamicLabel)
                    .addComponent(EndDateDynamicLabel)
                    .addComponent(SchemaDynamicLabel)
                    .addComponent(ContextMemberDynamicLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StartDateFormatLabel)
                    .addComponent(EndDateFormatLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SecondaryContextAxisLabel)
                    .addComponent(SecondaryContextDimensionLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SecondaryContextDimensionDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SecondaryContextAxisDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ISOCodeLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(UnitNameLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(UnitCheckBox)
                    .addComponent(AvailableUnitIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ISOCodeDynamicLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(StatementTagLabel)
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AvailableStatementIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StatementCheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StatementValueLabel)
                    .addComponent(StatementDecimalsLabel)
                    .addComponent(StatementUnitLabel)
                    .addComponent(StatementContextLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StatementValueDynamicLabel)
                    .addComponent(StatementDecimalsDynamicLabel)
                    .addComponent(StatementUnitsDynamicLabel)
                    .addComponent(AvailableStatementContextComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(NoteSelectorLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NoteCheckBox)
                    .addComponent(NoteSelectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NoteContextRefLabel)
                    .addComponent(NoteContentLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(NoteContentDynamicLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(NoteContextRefDynamicLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CancelButton)
                    .addComponent(DeleteButton))
                .addGap(0, 34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DeleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteButtonActionPerformed
        // TODO add your handling code here:
        //This button removes instance elements from the report, as long as they sucessfuly go through the validation steps below
        //Boolean variable to verify if the element is valid and if the app shall dispose the window
        boolean IsElementValid = false;               
        //Trying to delete a financial statement
        if(StatementCheckBox.isSelected()){
             //Checking for statement information availability
             if((AvailableStatementIdComboBox.getItemCount() != 0)&&(AvailableStatementContextComboBox.getItemCount() != 0)){
                 //String variables to store the data gathered from the Combobox. That is the minimal information you need to distinguish financial statements.
                 String StatementIdToBeDeleted,StatementContextRefToBeDeleted;
                 StatementIdToBeDeleted=AvailableStatementIdComboBox.getSelectedItem().toString();
                 StatementContextRefToBeDeleted=AvailableStatementContextComboBox.getSelectedItem().toString();            
                 //removing the desired element from the report, if it is there
                 IsElementValid=instanceReport.statementList.removeIf(statement -> (statement.getId().equals(StatementIdToBeDeleted) && statement.getContextRef().equals(StatementContextRefToBeDeleted)));
                 
             }else{
                 JOptionPane.showMessageDialog(this,M_Error08,jopTitle,JOptionPane.WARNING_MESSAGE);
             }
        }
        //Trying to delete a financial context
        if(ContextCheckBox.isSelected()){
            //Checking for context information availability
            if(AvailableContextIdComboBox.getItemCount() != 0){
               //String variables to store the data gathered from the Combobox. That is the minimal information you need to distinguish financial contexts.
               String ContextIdToBeDeleted = AvailableContextIdComboBox.getSelectedItem().toString();
               boolean bind=false;
               for(StatementDeclaration statementAnalysis:instanceReport.statementList){
                   if(ContextIdToBeDeleted.equals(statementAnalysis.getContextRef())){
                       bind=true;
                   }
               }
               for(NonNumericDeclaration noteAnalysis:instanceReport.noteList){
                   if(ContextIdToBeDeleted.equals(noteAnalysis.getContextRef())){
                       bind=true;
                   }
               }               
               if(bind){
                   JOptionPane.showMessageDialog(this,M_Error24,jopTitle,JOptionPane.WARNING_MESSAGE);
               }else{
                    //removing the desired element from the report, if it is there
                    IsElementValid=instanceReport.contextList.removeIf(context -> context.getId().equals(ContextIdToBeDeleted));
               }
            }else{
                 JOptionPane.showMessageDialog(this,M_Error09,jopTitle,JOptionPane.WARNING_MESSAGE);
            }
        }
        //Trying to delete a financial unit
        if(UnitCheckBox.isSelected()){
            //Checking for unit information availability
            if(AvailableUnitIdComboBox.getItemCount() != 0){
                //String variables to store the data gathered from the Combobox. That is the minimal information you need to distinguish financial units.
                String UnitIdToBeDeleted = AvailableUnitIdComboBox.getSelectedItem().toString();
                boolean bind=false;
                for(StatementDeclaration statementAnalysis:instanceReport.statementList){
                    if(UnitIdToBeDeleted.equals(statementAnalysis.getUnitRef())){
                        bind=true;
                    }
                }
                if(bind){
                   JOptionPane.showMessageDialog(this,M_Error24,jopTitle,JOptionPane.WARNING_MESSAGE);
                }else{
                    //removing the desired element from the report, if it is there
                    IsElementValid=instanceReport.unitList.removeIf(unit -> unit.getId().equals(UnitIdToBeDeleted));               
                }                            
            }else{
                 JOptionPane.showMessageDialog(this,M_Error10,jopTitle,JOptionPane.WARNING_MESSAGE);
             }
        }
        //Trying to delete a financial explanantory note
        if(NoteCheckBox.isSelected()){
            //Checking for explanantory note information availability
            if(NoteSelectionComboBox.getItemCount() != 0){
                //String variables to store the data gathered from the dynamic labels.
                String NoteIdToBeDeleted = NoteContentDynamicLabel.getText();
                String NoteContexToBeDeleted = NoteContextRefDynamicLabel.getText();
                //removing the desired element from the report, if it is there
                IsElementValid=instanceReport.noteList.removeIf(note -> note.getContent().equals(NoteIdToBeDeleted)&& note.getContextRef().equals(NoteContexToBeDeleted));
                            
            }else{
                 JOptionPane.showMessageDialog(this,M_Error11,jopTitle,JOptionPane.WARNING_MESSAGE);
             }
        }
        // This window is only disposed after a successful element deleticion        
        if(IsElementValid){
            LogTextArea.setText(LogTextArea.getText()+"\n"+M_Suc03);
            this.dispose();            
        }else{
            JOptionPane.showMessageDialog(this,M_Error12,jopTitle,JOptionPane.WARNING_MESSAGE);
        } 
    }//GEN-LAST:event_DeleteButtonActionPerformed

    private void CancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelButtonActionPerformed
        // TODO add your handling code here:
        InsertOptionUpdate(InsertOption);
        this.setVisible(false);
        if(StatementCheckBox.isSelected()){StatementCheckBox.doClick();}
        if(ContextCheckBox.isSelected()){ContextCheckBox.doClick();}
        if(UnitCheckBox.isSelected()){UnitCheckBox.doClick();}
        if(NoteCheckBox.isSelected()){NoteCheckBox.doClick();}        
    }//GEN-LAST:event_CancelButtonActionPerformed

    private void StatementCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StatementCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides support for removing one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to delete
        boolean state;
        if(StatementCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        ContextCheckBox.setEnabled(state);
        AvailableContextIdComboBox.setEnabled(state);
        SiconfiCodeDynamicLabel.setEnabled(state);
        ContextAxisDynamicLabel.setEnabled(state);
        StartDateDynamicLabel.setEnabled(state);
        EndDateDynamicLabel.setEnabled(state);
        SchemaDynamicLabel.setEnabled(state);
        ContextMemberDynamicLabel.setEnabled(state);
        UnitCheckBox.setEnabled(state);
        AvailableUnitIdComboBox.setEnabled(state);
        ISOCodeDynamicLabel.setEnabled(state);
        NoteCheckBox.setEnabled(state);
        NoteContextRefDynamicLabel.setEnabled(state);
        NoteContentDynamicLabel.setEnabled(state);
        NoteSelectionComboBox.setEnabled(state);
        SecondaryContextAxisDynamicLabel.setEnabled(state);
        SecondaryContextDimensionDynamicLabel.setEnabled(state);
    }//GEN-LAST:event_StatementCheckBoxActionPerformed

    private void ContextCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContextCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(ContextCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        StatementCheckBox.setEnabled(state);
        AvailableStatementIdComboBox.setEnabled(state);
        StatementValueDynamicLabel.setEnabled(state);
        StatementDecimalsDynamicLabel.setEnabled(state);
        StatementUnitsDynamicLabel.setEnabled(state);
        AvailableStatementContextComboBox.setEnabled(state);
        UnitCheckBox.setEnabled(state);
        AvailableUnitIdComboBox.setEnabled(state);
        ISOCodeDynamicLabel.setEnabled(state);
        NoteCheckBox.setEnabled(state);
        NoteContextRefDynamicLabel.setEnabled(state);
        NoteContentDynamicLabel.setEnabled(state);
        NoteSelectionComboBox.setEnabled(state);
    }//GEN-LAST:event_ContextCheckBoxActionPerformed

    private void UnitCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UnitCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(UnitCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        StatementCheckBox.setEnabled(state);
        AvailableStatementIdComboBox.setEnabled(state);
        StatementValueDynamicLabel.setEnabled(state);
        StatementDecimalsDynamicLabel.setEnabled(state);
        StatementUnitsDynamicLabel.setEnabled(state);
        AvailableStatementContextComboBox.setEnabled(state);
        ContextCheckBox.setEnabled(state);
        AvailableContextIdComboBox.setEnabled(state);
        SiconfiCodeDynamicLabel.setEnabled(state);
        ContextAxisDynamicLabel.setEnabled(state);
        StartDateDynamicLabel.setEnabled(state);
        EndDateDynamicLabel.setEnabled(state);
        SchemaDynamicLabel.setEnabled(state);
        ContextMemberDynamicLabel.setEnabled(state);
        NoteCheckBox.setEnabled(state);
        NoteContextRefDynamicLabel.setEnabled(state);
        NoteContentDynamicLabel.setEnabled(state);        
        NoteSelectionComboBox.setEnabled(state);
        SecondaryContextAxisDynamicLabel.setEnabled(state);
        SecondaryContextDimensionDynamicLabel.setEnabled(state);
    }//GEN-LAST:event_UnitCheckBoxActionPerformed

    private void NoteCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoteCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(NoteCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        StatementCheckBox.setEnabled(state);
        AvailableStatementIdComboBox.setEnabled(state);
        StatementValueDynamicLabel.setEnabled(state);
        StatementDecimalsDynamicLabel.setEnabled(state);
        StatementUnitsDynamicLabel.setEnabled(state);
        AvailableStatementContextComboBox.setEnabled(state);
        ContextCheckBox.setEnabled(state);
        AvailableContextIdComboBox.setEnabled(state);
        SiconfiCodeDynamicLabel.setEnabled(state);
        ContextAxisDynamicLabel.setEnabled(state);
        StartDateDynamicLabel.setEnabled(state);
        EndDateDynamicLabel.setEnabled(state);
        SchemaDynamicLabel.setEnabled(state);
        ContextMemberDynamicLabel.setEnabled(state);
        UnitCheckBox.setEnabled(state);
        AvailableUnitIdComboBox.setEnabled(state);
        ISOCodeDynamicLabel.setEnabled(state);  
        SecondaryContextAxisDynamicLabel.setEnabled(state);
        SecondaryContextDimensionDynamicLabel.setEnabled(state);
    }//GEN-LAST:event_NoteCheckBoxActionPerformed

    private void AvailableStatementIdComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvailableStatementIdComboBoxActionPerformed
        // TODO add your handling code here:
        LocateStatement(instanceReport);
    }//GEN-LAST:event_AvailableStatementIdComboBoxActionPerformed

    private void AvailableStatementContextComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvailableStatementContextComboBoxActionPerformed
        // TODO add your handling code here:
        LocateStatement(instanceReport);
    }//GEN-LAST:event_AvailableStatementContextComboBoxActionPerformed

    private void AvailableContextIdComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvailableContextIdComboBoxActionPerformed
        // TODO add your handling code here:
         LocateContext(instanceReport);
    }//GEN-LAST:event_AvailableContextIdComboBoxActionPerformed

    private void AvailableUnitIdComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvailableUnitIdComboBoxActionPerformed
        // TODO add your handling code here:
        LocateUnit(instanceReport);
    }//GEN-LAST:event_AvailableUnitIdComboBoxActionPerformed

    private void NoteSelectionComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoteSelectionComboBoxActionPerformed
        // TODO add your handling code here:
        LocateNote(instanceReport);
    }//GEN-LAST:event_NoteSelectionComboBoxActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> AvailableContextIdComboBox;
    private javax.swing.JComboBox<String> AvailableStatementContextComboBox;
    private javax.swing.JComboBox<String> AvailableStatementIdComboBox;
    private javax.swing.JComboBox<String> AvailableUnitIdComboBox;
    private javax.swing.JButton CancelButton;
    private javax.swing.JLabel ContextAxisDynamicLabel;
    private javax.swing.JLabel ContextAxisLabel;
    private javax.swing.JCheckBox ContextCheckBox;
    private javax.swing.JLabel ContextDimensionLabel;
    private javax.swing.JLabel ContextIdLabel;
    private javax.swing.JLabel ContextMemberDynamicLabel;
    private javax.swing.JButton DeleteButton;
    private javax.swing.JLabel EndDateDynamicLabel;
    private javax.swing.JLabel EndDateFormatLabel;
    private javax.swing.JLabel EndDateLabel;
    private javax.swing.JLabel ISOCodeDynamicLabel;
    private javax.swing.JLabel ISOCodeLabel;
    private javax.swing.JCheckBox NoteCheckBox;
    private javax.swing.JLabel NoteContentDynamicLabel;
    private javax.swing.JLabel NoteContentLabel;
    private javax.swing.JLabel NoteContextRefDynamicLabel;
    private javax.swing.JLabel NoteContextRefLabel;
    private javax.swing.JComboBox<String> NoteSelectionComboBox;
    private javax.swing.JLabel NoteSelectorLabel;
    private javax.swing.JLabel SchemaDynamicLabel;
    private javax.swing.JLabel SchemaLabel;
    private javax.swing.JLabel SecondaryContextAxisDynamicLabel;
    private javax.swing.JLabel SecondaryContextAxisLabel;
    private javax.swing.JLabel SecondaryContextDimensionDynamicLabel;
    private javax.swing.JLabel SecondaryContextDimensionLabel;
    private javax.swing.JLabel SiconfiCodeDynamicLabel;
    private javax.swing.JLabel SiconfiCodeLabel;
    private javax.swing.JLabel StartDateDynamicLabel;
    private javax.swing.JLabel StartDateFormatLabel;
    private javax.swing.JLabel StartDateLabel;
    private javax.swing.JCheckBox StatementCheckBox;
    private javax.swing.JLabel StatementContextLabel;
    private javax.swing.JLabel StatementDecimalsDynamicLabel;
    private javax.swing.JLabel StatementDecimalsLabel;
    private javax.swing.JLabel StatementTagLabel;
    private javax.swing.JLabel StatementUnitLabel;
    private javax.swing.JLabel StatementUnitsDynamicLabel;
    private javax.swing.JLabel StatementValueDynamicLabel;
    private javax.swing.JLabel StatementValueLabel;
    private javax.swing.JCheckBox UnitCheckBox;
    private javax.swing.JLabel UnitNameLabel;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    // End of variables declaration//GEN-END:variables
}
