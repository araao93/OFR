/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.util.Vector;
/**
 *
 * @author anton
 */
public class EditElement extends javax.swing.JInternalFrame{
    InstanceReport instanceReport;
    //initializing string arrays with the comboboxes items                
    Vector<String> contextAxisComboBox = new Vector<String>();
    Vector<String> schemaComboBox = new Vector<String>();
    Vector<String> isoCodeComboBox = new Vector<String>();
    Vector<String> statementIdComboBox = new Vector<String>();
    Vector<String> contextMemberComboBox = new Vector<String>();        
    Vector<String> nonNumericElementsComboBox = new Vector<String>();
    Vector<String> coupledAxisList = new Vector<String>();
    Vector<String> secondaryAxisComboBox = new Vector<String>();  
    Vector<String> startDateComboBox=new Vector<String>();
    Vector<String> endDateComboBox=new Vector<String>();    
    //this variable stores this software's internal index of the XBRL added elements, during the deletion process
    int genericIndex;
    //initializing strings to store the error messages text
    String M_Error13,M_Error14,M_Error15,M_Error16,M_Error17,M_Error18,M_Error19,M_Error20,M_Error21,M_Error22,M_Error23,M_Error28,M_Error29;    
    //initializing strings to store the success messages text
    String M_Suc02;    
    //initializing log text area
    JTextArea LogTextArea; 
    //String for JOprionPane Boxes Title
    String jopTitle;  
    int InsertOption;
    /**
     * Creates new form AddElement
     */
    public EditElement()throws IOException {
        LoadAuxiliarFiles();
        //initializing all JFrame components
        initComponents();
        StaticComboBoxInitializer();
        CurrentExplanatoryNoteContent.setVisible(false);
        SecondaryContextAxisComboBox.setEnabled(false);
        SecondaryContextDimensionComboBox.setEnabled(false);  
        AvailableStatementIdComboBox.setBackground(Color.decode("#275787"));
        AvailableStatementContextComboBox.setBackground(Color.decode("#275787"));
        NoteSelectionComboBox.setBackground(Color.decode("#275787"));
        AvailableContextIdComboBox.setBackground(Color.decode("#275787"));
        AvailableUnitIdComboBox.setBackground(Color.decode("#275787"));
        Font newCheckBoxFont=new Font(ContextCheckBox.getFont().getName(),Font.ITALIC+Font.BOLD,ContextCheckBox.getFont().getSize());
        StatementCheckBox.setFont(newCheckBoxFont);
        ContextCheckBox.setFont(newCheckBoxFont);
        UnitCheckBox.setFont(newCheckBoxFont);
        NoteCheckBox.setFont(newCheckBoxFont);         
    }
    public void StaticComboBoxInitializer (){
        //cleaning the existing comboboxes
        availableUnitsComboBox.removeAllItems();
        availableContextsComboBox.removeAllItems();
        NoteContextRefComboBox.removeAllItems(); 
        StatementIdComboBox.removeAllItems();
        ContextAxisComboBox.removeAllItems();
        SchemaComboBox.removeAllItems();
        ContextMemberComboBox.removeAllItems();
        ISOCodeComboBox.removeAllItems();
        AvailableStatementIdComboBox.removeAllItems();
        AvailableContextIdComboBox.removeAllItems();
        AvailableUnitIdComboBox.removeAllItems();
        NoteSelectionComboBox.removeAllItems();
        AvailableStatementContextComboBox.removeAllItems();
        NonNumericElementsComboBox.removeAllItems();
        jComboBox1.removeAllItems();
        jComboBox2.removeAllItems();
        //creating a counter
        int i;  
        //loading comboboxes items 
        for(i=0;i<isoCodeComboBox.size();i++){
            ISOCodeComboBox.addItem(isoCodeComboBox.elementAt(i));
        }
        for(i=0;i<schemaComboBox.size();i++){
            SchemaComboBox.addItem(schemaComboBox.elementAt(i));
        }            
        for(i=0;i<contextAxisComboBox.size();i++){
            ContextAxisComboBox.addItem(contextAxisComboBox.elementAt(i));
        }
        for(i=0;i<nonNumericElementsComboBox.size();i++){
            NonNumericElementsComboBox.addItem(nonNumericElementsComboBox.elementAt(i));
        }
        for(i=0;i<startDateComboBox.size();i++){
            jComboBox1.addItem(startDateComboBox.elementAt(i));
        } 
        for(i=0;i<endDateComboBox.size();i++){
            jComboBox2.addItem(endDateComboBox.elementAt(i));
        }         
    }
    public void updateReport (InstanceReport instanceReport){       
        this.instanceReport=instanceReport;
        //adding each report item to its proper combobox
        if(!this.instanceReport.contextList.isEmpty()){
            for(ContextDeclaration context : instanceReport.contextList){
                if(availableContextsComboBox.getItemCount()==0){
                    availableContextsComboBox.addItem(context.getId());
                    NoteContextRefComboBox.addItem(context.getId());
                }else{
                    boolean exist=false;
                    for(int j=0;j<availableContextsComboBox.getItemCount();j++){
                        if(context.getId().equals(availableContextsComboBox.getItemAt(j))){
                            exist=true;
                        }
                    }
                    if(!exist){
                        availableContextsComboBox.addItem(context.getId());
                        NoteContextRefComboBox.addItem(context.getId());
                    }
                }
            }
        }
        if(!this.instanceReport.unitList.isEmpty()){
            availableUnitsComboBox.removeAllItems();
            for(UnitDeclaration unit : instanceReport.unitList){            
                availableUnitsComboBox.addItem(unit.getId());
            }
        }
        if(!this.instanceReport.contextList.isEmpty()){
            for(ContextDeclaration context : instanceReport.contextList){
                if(AvailableContextIdComboBox.getItemCount()==0){
                    AvailableContextIdComboBox.addItem(context.getId());
                    AvailableStatementContextComboBox.addItem(context.getId());
                }else{
                    boolean exist=false;
                    for(int j=0;j<AvailableContextIdComboBox.getItemCount();j++){
                        if(context.getId().equals(AvailableContextIdComboBox.getItemAt(j))){
                            exist=true;
                        }
                    }
                    if(!exist){
                        AvailableContextIdComboBox.addItem(context.getId());
                        AvailableStatementContextComboBox.addItem(context.getId());
                    }
                }                
            }
        }
        if(!this.instanceReport.unitList.isEmpty()){
            AvailableUnitIdComboBox.removeAllItems();
            for(UnitDeclaration unit : instanceReport.unitList){            
                AvailableUnitIdComboBox.addItem(unit.getId());
            }
        }
        if(!this.instanceReport.statementList.isEmpty()){
            for(StatementDeclaration statement : instanceReport.statementList){            
                if(AvailableStatementIdComboBox.getItemCount()==0){
                    AvailableStatementIdComboBox.addItem(statement.getId());
                }else{
                    boolean exist=false;
                    for(int j=0;j<AvailableStatementIdComboBox.getItemCount();j++){
                        if(statement.getId().equals(AvailableStatementIdComboBox.getItemAt(j))){
                            exist=true;
                        }
                    }
                    if(!exist){
                        AvailableStatementIdComboBox.addItem(statement.getId());
                    }
                }
            }
        }
        if(!this.instanceReport.noteList.isEmpty()){
            int i = 0;
            NoteSelectionComboBox.removeAllItems();
            for(NonNumericDeclaration note : instanceReport.noteList){                
                    NoteSelectionComboBox.addItem(note.getLabel()+String.valueOf(i+1));
                    i++;
            }
        }        
    }
    public void LoadAuxiliarFiles()throws IOException{
                //initializing a Buffered Reader so its possible to use the method readLine() to get the codes from the text file and to compare them with the inted one                 
                InputStream reader = getClass().getResourceAsStream("SiconfiAxis.txt");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes
                String CodeLine;                
                // loop for checking all codes within the text file                
                while ((CodeLine = bufferedReader.readLine()) != null) {
                    contextAxisComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close();
                reader = getClass().getResourceAsStream("SiconfiSchema.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                   schemaComboBox.add(CodeLine);
                }
                //closing the file reader
                reader.close();      
                reader = getClass().getResourceAsStream("IsoCode.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    isoCodeComboBox.add(CodeLine);
                }
                //closing the file reader
                reader.close(); 
                reader = getClass().getResourceAsStream("SiconfiStatementId.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    statementIdComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close(); 
                reader = getClass().getResourceAsStream("SiconfiDimension.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    contextMemberComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close();
                reader = getClass().getResourceAsStream("SiconfiNonNumeric.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    nonNumericElementsComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close();
                reader = getClass().getResourceAsStream("CoupledAxisList.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    coupledAxisList.add(CodeLine);
                }                
                //closing the file reader
                reader.close(); 
                reader = getClass().getResourceAsStream("StartDateList.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    startDateComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close();   
                reader = getClass().getResourceAsStream("EndDateList.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    endDateComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close();                
    }    
    public void Logloader(JTextArea LogTextArea){
        this.LogTextArea = LogTextArea;        
    }
    public void InsertOptionUpdate(int x){
        this.InsertOption=x;        
        if (this.InsertOption==1){
            ContextCheckBox.doClick();
        }else{
            if(this.InsertOption==2){
                UnitCheckBox.doClick();
            }else{
                if(this.InsertOption==3){
                    StatementCheckBox.doClick();
                }else{
                    if(this.InsertOption==4){
                        NoteCheckBox.doClick();
                    }
                }
            }
        }
    }    
    public void ContextDimensionComboBoxFiller(Vector<String> contextAxisComboBox,Vector<String> contextMemberComboBox)throws IOException{
        //each axis has a number of members dimensions so, it was necessary to implement this function to fill up the member combobox with the proper options fo each axis
        String SiconfiAxis;
        int i;
        InputStream reader;
        BufferedReader bufferedReader;
        String CodeLine;        
        if(ContextAxisComboBox.getSelectedItem()!=null){
        SiconfiAxis = ContextAxisComboBox.getSelectedItem().toString();
        for(i=0;i<contextAxisComboBox.size();i++){
            if(SiconfiAxis.equals(contextAxisComboBox.elementAt(i))){
                reader = getClass().getResourceAsStream("ContextMemberAxis"+String.valueOf(i)+".txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));
                while ((CodeLine = bufferedReader.readLine()) != null) {
                    ContextMemberComboBox.addItem(CodeLine);
                }
                reader.close();
            }
        }
        }           
    }
    public void StatementIdComboBoxFiller(Vector<String> contextAxisComboBox,Vector<String> statementIdComboBox,InstanceReport instanceReport)throws IOException{
        this.instanceReport=instanceReport;
        //each axis has a number of members dimensions so, it was necessary to implement this function to fill up the member combobox with the proper options fo each axis
        String SiconfiAxis="";
        int i;
        InputStream reader;
        BufferedReader bufferedReader;
        String CodeLine;          
        if(availableContextsComboBox.getItemCount() != 0){
            for(ContextDeclaration context : this.instanceReport.contextList){
                if (context.getId().equals(availableContextsComboBox.getSelectedItem().toString()))
                    for(i=12;i<context.getExplicitMemberDimension().length()-4;i++){
                        SiconfiAxis=SiconfiAxis+context.getExplicitMemberDimension().charAt(i);
                    }                
            }        
        if(!SiconfiAxis.equals("")){
            for(i=0;i<contextAxisComboBox.size();i++){
                if(SiconfiAxis.equals(contextAxisComboBox.elementAt(i))){
                    reader = getClass().getResourceAsStream("StatementAxis"+String.valueOf(i)+".txt");
                    bufferedReader = new BufferedReader(new InputStreamReader(reader));
                    while ((CodeLine = bufferedReader.readLine()) != null) {
                        StatementIdComboBox.addItem(CodeLine);
                    }
                    reader.close();
                }
            }
        }
        }
    }    
    public int ContextIndexCalc(String Id){
    int index=0;
    for(int i=0;i<contextMemberComboBox.size();i++){
        if(Id.equals(contextMemberComboBox.size())){
            index=i;
        }
    }
    return index;
    }
    public int StatementIndexCalc(String Id){
    int index=0;
    for(int i=0;i<statementIdComboBox.size();i++){
        if(Id.equals(statementIdComboBox.size())){
            index=i;
        }
    }
    return index;
    }
        public void LocateStatement(InstanceReport instanceReport){
        this.instanceReport=instanceReport;
        //Defining string variables to search for the desired statement  
        String statementIdChecker,contextIdChecker;
        //Checking for statement information availability
        if((AvailableStatementIdComboBox.getItemCount() != 0)&&(AvailableStatementContextComboBox.getItemCount() != 0)){
            statementIdChecker=AvailableStatementIdComboBox.getSelectedItem().toString();
            contextIdChecker=AvailableStatementContextComboBox.getSelectedItem().toString();
            for(StatementDeclaration statement : instanceReport.statementList){
                if((statementIdChecker.equals(statement.getId()))&&(contextIdChecker.equals(statement.getContextRef()))){
                    //filling up editing area with the retrieved element
                    StatementValue.setText(statement.getValue().substring(0, statement.getValue().length()-1-Integer.valueOf(statement.getDecimals()))+statement.getValue().substring(statement.getValue().length()-Integer.valueOf(statement.getDecimals())));
                    StatementDecimals.setText(statement.getDecimals());
                    availableUnitsComboBox.setSelectedItem(statement.getUnitRef());
                    availableContextsComboBox.setSelectedItem(statement.getContextRef());
                    StatementIdComboBox.setSelectedItem(statement.getId());
                    genericIndex=statement.getIndex();
                }                
            }
        }            
    }
    public void LocateContext(InstanceReport instanceReport){
        this.instanceReport=instanceReport;
        //Defining a string variable to search for the desired context
        String contextIdChecker;
        //Checking for context information availability
        if(AvailableContextIdComboBox.getItemCount() != 0){
            contextIdChecker=AvailableContextIdComboBox.getSelectedItem().toString();
            for(ContextDeclaration context : instanceReport.contextList){
                if(contextIdChecker.equals(context.getId())){
                    //varibles to store the upper substring limiter index. It allows showing item's names in the labels free from software stuff.
                    int axisSubstringIndex,memberSubstringIndex;
                    axisSubstringIndex=context.getExplicitMemberDimension().length();
                    memberSubstringIndex=context.getSiconfiDimension().length();
                    ContextId.setText(context.getId());
                    SiconfiCodeTextBox.setText(context.getEntityIdentifier());
                    ContextAxisComboBox.setSelectedItem(context.getExplicitMemberDimension().substring(12,axisSubstringIndex-4));
                    jComboBox1.setSelectedItem(context.getPeriodStartDate());
                    jComboBox2.setSelectedItem(context.getPeriodEndDate());
                    SchemaComboBox.setSelectedItem(context.getEntityScheme());
                    ContextMemberComboBox.setSelectedItem(context.getSiconfiDimension().substring(12,memberSubstringIndex-6));
                    if(context.getHasCoupledAxis()){
                        int secondaryAxisSubstringIndex,secondaryMemberSubstringIndex;
                        secondaryAxisSubstringIndex=context.getSecondaryExplicitMemberDimension().length();
                        secondaryMemberSubstringIndex=context.getSecondarySiconfiDimension().length();
                        SecondaryContextAxisComboBox.setSelectedItem(context.getSecondaryExplicitMemberDimension().substring(12,secondaryAxisSubstringIndex-4));
                        SecondaryContextDimensionComboBox.setSelectedItem(context.getSecondarySiconfiDimension().substring(12,secondaryMemberSubstringIndex-6));                        
                    }                
                }
            }
        }
    }
    public void LocateUnit(InstanceReport instanceReport){
        this.instanceReport=instanceReport;
        //Defining a string variable to search for the desired context
        String UnitIdChecker;
        //Checking for context information availability
        if(AvailableUnitIdComboBox.getItemCount() != 0){
            UnitIdChecker=AvailableUnitIdComboBox.getSelectedItem().toString();
            for(UnitDeclaration unit : instanceReport.unitList){
                if(UnitIdChecker.equals(unit.getId())){
                    ISOCodeComboBox.setSelectedItem(unit.getISOIdentifier().substring(8));
                    UnitId.setText(unit.getId());
                }
            }
        }
    }
    public void LocateNote(InstanceReport instanceReport){
        this.instanceReport=instanceReport;
        //Defining string variables to search for the desired context
        String NoteContexChecker,NoteContentChecker;
        int NotePosition;
        //Checking for context information availability
        if(NoteSelectionComboBox.getItemCount() != 0){
            NotePosition=Integer.valueOf(NoteSelectionComboBox.getSelectedItem().toString().substring(18));
            NonNumericDeclaration note = instanceReport.noteList.get(NotePosition-1);            
            NoteContent.setText(note.getContent());
            CurrentExplanatoryNoteContent.setText(note.getContent());
            NoteContextRefComboBox.setSelectedItem(note.getContextRef());
            NoteCurrentContextDynamicLabel.setText(note.getContextRef());            
        }        
    }
    public void CheckBoxReset () {
        if(StatementCheckBox.isSelected()){StatementCheckBox.doClick();}
        if(ContextCheckBox.isSelected()){ContextCheckBox.doClick();}
        if(UnitCheckBox.isSelected()){UnitCheckBox.doClick();}
        if(NoteCheckBox.isSelected()){NoteCheckBox.doClick();}    
    }    
        public void LanguageSelection(String language){
        if(language.equals("EN")){
            //frame title
            this.setTitle("Element edition manager");
            //labels
            StatementTagLabel.setText("Account tag");
            StatementCheckBox.setText("Account");
            StatementValueLabel.setText("Value");
            StatementDecimalsLabel.setText("Decimals");
            StatementUnitLabel.setText("Unit");
            StatementContextLabel.setText("Context");
            ContextIdLabel.setText("Context name");
            ContextCheckBox.setText("Context");
            SiconfiCodeLabel.setText("Institution's code");
            ContextAxisLabel.setText("Context axis");
            StartDateLabel.setText("Start date");
            EndDateLabel.setText("End date");
            SchemaLabel.setText("Schema");
            ContextDimensionLabel.setText("Context dimension");
            StartDateFormatLabel.setText("YYYY-MM-DD");
            EndDateFormatLabel.setText("YYYY-MM-DD");
            UnitNameLabel.setText("Unit name");
            ISOCodeLabel.setText("ISO code");
            UnitCheckBox.setText("Unit");
            NoteContentLabel.setText("Description");
            NoteContextRefLabel.setText("Context");
            NoteCheckBox.setText("Non numeric");
            CurrentStatementTagLabel.setText("Selected account tag");
            CurrentStatementContextLabel.setText("Selected context");
            CurrentContextNameLabel.setText("Selected context name");
            CurrentUnitNameLabel.setText("Selected unit name");
            CurrentNoteLabel.setText("Selected element");
            NoteCurrentContextLabel.setText("Context");
            StatementEditionAreaLabel.setText("Edition area");
            ContextEditionAreaLabel.setText("Edition area");
            EditionUnitAreaLabel.setText("Edition area");
            EditionNoteAreaLabel.setText("Edition area");
            NonNumericElementsComboBoxLabel.setText("Non numeric element tag");
            StatementValue.setToolTipText("Do not add decimals' separators. Write 1,123.45 as 112345, for example.");
            SecondaryContextAxisLabel.setText("Secondary Context Axis");
            SecondaryContextDimensionLabel.setText("Secondary Context Dimension");            
            //buttons
            EditButton.setText("Update");
            CancelButton.setText("Cancel");
            //error messages
            M_Error13="Please, make sure to fill up all the required fields before editing an element.";
            M_Error14="Please, make sure to add a context and an account before trying to edit an account.";
            M_Error15="Please, make sure to add a context and a unit before editing accounts.";
            M_Error16="Please, make sure to insert a valid institutional code.";
            M_Error17="Please, make sure to insert a valid period.";
            M_Error18="The context name must be unique. Please, check your input data.";
            M_Error19="Please, make sure to add a context before trying to edit one.";
            M_Error20="Please, make sure to add a unit before trying to edit one.";
            M_Error21="Please, make sure to add an explanatory note before trying to edit one.";
            M_Error22="Please, make sure to add a context before editing explanatory notes.";
            M_Error23="Please, also make sure you are not incurring one of the following situations: \n" +
            "1 - You tried to edit an element without marking the appropriate Element type Checkbox. \n" +
            "2 - You forgot to properly fill up any field.\n" +
            "";
            M_Error28="1-The Value field and the Decimals field only accepts integer numbers."+"\n"+"2-It is not possible to turn the selected element into an existing one."+"\n"+"3-Please, review the input data.";
            M_Error29="1-A context's name must be unique."+"\n"+"2-The Institution's code field must be a valid Siconfi's code."+"\n"+"3-The End date must always be ulterior to the Start date."+"\n"+"4-Please, review the input data.";                        
            //success messages
            M_Suc02="Element successfully edited.";
            //JOptionPane
            jopTitle="WARN";
            AvailableContextIdComboBox.setToolTipText("Choose the Name of the context you want to edit.");
            AvailableUnitIdComboBox.setToolTipText("Choose the Name of the unit you want to edit.");
            AvailableStatementIdComboBox.setToolTipText("Choose the tag of the account you want to edit.");
            AvailableStatementContextComboBox.setToolTipText("Choose the context of the account you want to edit.");
            NoteSelectionComboBox.setToolTipText("Choose the non numeric element you want to edit.");
        }else{
            if(language.equals("PT")){
                //frame title
                this.setTitle("Gerenciador de edição de elementos");
                //labels
                StatementTagLabel.setText("Tag da conta");
                StatementCheckBox.setText("Conta");
                StatementValueLabel.setText("Valor");
                StatementDecimalsLabel.setText("Decimais");
                StatementUnitLabel.setText("Unidade");
                StatementContextLabel.setText("Contexto");
                ContextIdLabel.setText("Nome do contexto");
                ContextCheckBox.setText("Contexto");
                SiconfiCodeLabel.setText("Código da Instituição");
                ContextAxisLabel.setText("Eixo do contexto");
                StartDateLabel.setText("Início");
                EndDateLabel.setText("Término");
                SchemaLabel.setText("Schema");
                ContextDimensionLabel.setText("Dimensão do contexto");
                StartDateFormatLabel.setText("AAAA-MM-DD");
                EndDateFormatLabel.setText("AAAA-MM-DD");
                UnitNameLabel.setText("Unidade");
                ISOCodeLabel.setText("Código ISO");
                UnitCheckBox.setText("Unidade");
                NoteContentLabel.setText("Descrição");
                NoteContextRefLabel.setText("Contexto");
                NoteCheckBox.setText("Não numérico");
                CurrentStatementTagLabel.setText("Tag da conta selecionada");
                CurrentStatementContextLabel.setText("Contexto selecionado");
                CurrentContextNameLabel.setText("Contexto selecionado");
                CurrentUnitNameLabel.setText("Unidade selecionada");
                CurrentNoteLabel.setText("Elemento selecionado");
                NoteCurrentContextLabel.setText("Contexto");                
                StatementEditionAreaLabel.setText("Area de edição");
                ContextEditionAreaLabel.setText("Area de edição");
                EditionUnitAreaLabel.setText("Area de edição");
                EditionNoteAreaLabel.setText("Area de edição");                
                StatementValue.setToolTipText("Não adicione separadores decimais. Escreva 1.123,45 como 112345, por exemplo.");
                NonNumericElementsComboBoxLabel.setText("Tag do elemento não numérico");
                SecondaryContextAxisLabel.setText("Eixo secundário do contexto");
                SecondaryContextDimensionLabel.setText("Dimensão secundária do contexto");                
                //buttons
                EditButton.setText("Atualizar");
                CancelButton.setText("Cancelar");
                //error messages
                M_Error13="Por favor, certifique-se de ter preenchido todos os compos requeridos antes de editar um elemento.";
                M_Error14="Por favor, certifique-se de adicionar um contexto e uma conta antes de editar uma conta.";
                M_Error15="Por favor, certifique-se de adicionar um contexto e uma unidade antes de editar uma conta.";
                M_Error16="Por favor, certifique-se de inserir um código institucional válido.";
                M_Error17="Por favor, certifique-se de inserir um período válido.";
                M_Error18="O nome de um contexto deve ser único. Por favor, verifique seus dados de entrada.";
                M_Error19="Por favor, certifique-se de adicionar um contexto antes de tentar editar um.";
                M_Error20="Por favor, certifique-se de adicionar uma unidade antes de tentar editar uma.";
                M_Error21="Por favor, certifique-se de adicionar uma nota explicativa antes de tentar editar uma.";
                M_Error22="Por favor, certifique-se de inserir um contexto antes de editar uma nota explicativa.";
                M_Error23="Por favor, também certifique-se que nenhuma das seguintes situações está ocorrendo: \n" +
                "1 - Você tentou editar um elemento sem marcar a checkbox apropriada ao tipo de elemento. \n" +
                "2 - Você preencheu algum campo inadequadamente.\n" +
                "";
                //success messages
                M_Suc02="Elemento editado com sucesso."; 
                M_Error28="1-Os campos Valor e Decimais aceitam apenas números inteiros."+"\n"+"2-Não é possível transformar o elemento selecionado em outro já existente."+"\n"+"3-Por favor, revise os dados inseridos.";
                M_Error29="1-O nome de cada contexto deve ser único"+"\n"+"2-O campo Código da instituição deve ser válido de acordo com a relação de códigos do Siconfi."+"\n"+"O término do período deve ser sempre ulterior ao seu início."+"\n"+"3-Por favor, revise os dados inseridos.";
                //JOptionPane
                jopTitle="AVISO";
                AvailableContextIdComboBox.setToolTipText("Escolha o nome do contexto que você quer editar.");
                AvailableUnitIdComboBox.setToolTipText("Escolha o nome da unidade que você quer editar.");
                AvailableStatementIdComboBox.setToolTipText("Escolha o tag da conta que você quer editar.");
                AvailableStatementContextComboBox.setToolTipText("Escolha o contexto da conta que você quer editar.");
                NoteSelectionComboBox.setToolTipText("Escolha o elemento não numérico que você quer editar.");                
            }else{
                //frame title
                this.setTitle("Gestor de edición de elementos");
                //labels
                StatementTagLabel.setText("Etiqueta de cuenta");
                StatementCheckBox.setText("Cuenta");
                StatementValueLabel.setText("Valor");
                StatementDecimalsLabel.setText("Decimales");
                StatementUnitLabel.setText("Unidad de valor");
                StatementContextLabel.setText("Contexto");
                ContextIdLabel.setText("Nombre de contexto");
                ContextCheckBox.setText("Contexto");
                SiconfiCodeLabel.setText("Código de la institución");
                ContextAxisLabel.setText("Eje de contexto");
                StartDateLabel.setText("Fecha de inicio");
                EndDateLabel.setText("Fecha final");
                SchemaLabel.setText("Schema");
                ContextDimensionLabel.setText("Dimensión de contexto");
                StartDateFormatLabel.setText("AAAA-MM-DD");
                EndDateFormatLabel.setText("AAAA-MM-DD");
                UnitNameLabel.setText("Nombre de la unidad de valor");
                ISOCodeLabel.setText("Código ISO");
                UnitCheckBox.setText("Unidad de valor");
                NoteContentLabel.setText("Descripción");
                NoteContextRefLabel.setText("Contexto");
                NoteCheckBox.setText("No numérico");
                CurrentStatementTagLabel.setText("Etiqueta de cuenta seleccionada");
                CurrentStatementContextLabel.setText("Contexto seleccionado");
                CurrentContextNameLabel.setText("Contexto seleccionado");
                CurrentUnitNameLabel.setText("Unidad seleccionada");
                CurrentNoteLabel.setText("Elemento seleccionado");
                NoteCurrentContextLabel.setText("Contexto");                
                StatementEditionAreaLabel.setText("Área de edición");
                ContextEditionAreaLabel.setText("Área de edición");
                EditionUnitAreaLabel.setText("Área de edición");
                EditionNoteAreaLabel.setText("Área de edición");                
                StatementValue.setToolTipText("No agregue separadores de decimales. Escriba 1,123.45 como 112345, por ejemplo.");
                NonNumericElementsComboBoxLabel.setText("Etiqueta de elemento no numérico");
                SecondaryContextAxisLabel.setText("Eje de contexto secundario");
                SecondaryContextDimensionLabel.setText("Dimensión de contexto secundaria");                
                //buttons
                EditButton.setText("Actualizar");
                CancelButton.setText("Cancelar");
                //error messages
                M_Error13="Por favor, asegúrese de completar todos los campos obligatorios antes de editar un elemento.";
                M_Error14="Por favor, asegúrese de agregar un contexto y un estado financiero antes de intentar editar un estado financiero.";
                M_Error15="Por favor, asegúrese de agregar un contexto y una unidad antes de editar los estados financieros.";
                M_Error16="Por favor, asegúrese de insertar un código institucional válido.";
                M_Error17="Por favor, asegúrese de insertar un período válido.";
                M_Error18="El nombre del contexto debe ser exclusivo. Por favor, verifique sus datos de entrada.";
                M_Error19="Por favor, asegúrese de agregar un contexto antes de intentar editar uno.";
                M_Error20="Por favor, asegúrese de agregar una unidad antes de intentar editar una.";
                M_Error21="Por favor, asegúrese de agregar una nota explicativa antes de intentar editar una.";
                M_Error22="Por favor, asegúrese de agregar un contexto antes de editar notas explicativas.";
                M_Error23="Por favor, asegúrese también de no estar incurriendo en una de las siguientes situaciones: \n" +
                "1 - Intentó editar un elemento sin marcar la casilla de verificación del tipo de elemento correspondiente. \n" +
                "2 - Olvidó completar correctamente cualquier campo.\n" +
                "";
                M_Error28="1-El campo Valor y el campo Decimales solo aceptan números enteros."+"\n"+"2-No es posible convertir el elemento seleccionado en uno existente."+"\n"+"3-Por favor, revise los datos de entrada.";
                M_Error29="1-El nombre de un contexto debe ser único."+"\n"+"2-El campo del código de la institución debe ser un código válido de Siconfi."+"\n"+"3-La fecha de finalización siempre debe ser posterior a la fecha de inicio."+"\n"+"4-Por favor, revise los datos de entrada.";                            
                //success messages
                M_Suc02="Elemento editado correctamente.";     
                //JOptionPane
                jopTitle="ADVERTENCIA";
                AvailableContextIdComboBox.setToolTipText("Elija el Nombre del contexto que desea editar.");
                AvailableUnitIdComboBox.setToolTipText("Elija el nombre de la unidad que desea editar.");
                AvailableStatementIdComboBox.setToolTipText("Elija la etiqueta de la cuenta que desea editar.");
                AvailableStatementContextComboBox.setToolTipText("Elija el contexto de la cuenta que desea editar.");
                NoteSelectionComboBox.setToolTipText("Elija el elemento no numérico que desea editar.");
                
            }            
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator6 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        EditButton = new javax.swing.JButton();
        StatementCheckBox = new javax.swing.JCheckBox();
        ContextCheckBox = new javax.swing.JCheckBox();
        UnitCheckBox = new javax.swing.JCheckBox();
        NoteCheckBox = new javax.swing.JCheckBox();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        StatementValueLabel = new javax.swing.JLabel();
        CancelButton = new javax.swing.JButton();
        ISOCodeComboBox = new javax.swing.JComboBox<>();
        UnitId = new javax.swing.JTextField();
        UnitNameLabel = new javax.swing.JLabel();
        ISOCodeLabel = new javax.swing.JLabel();
        StatementIdComboBox = new javax.swing.JComboBox<>();
        availableUnitsComboBox = new javax.swing.JComboBox<>();
        availableContextsComboBox = new javax.swing.JComboBox<>();
        StatementTagLabel = new javax.swing.JLabel();
        StatementDecimalsLabel = new javax.swing.JLabel();
        StatementUnitLabel = new javax.swing.JLabel();
        StatementContextLabel = new javax.swing.JLabel();
        ContextIdLabel = new javax.swing.JLabel();
        ContextId = new javax.swing.JTextField();
        ContextAxisComboBox = new javax.swing.JComboBox<>();
        ContextMemberComboBox = new javax.swing.JComboBox<>();
        SchemaComboBox = new javax.swing.JComboBox<>();
        SiconfiCodeLabel = new javax.swing.JLabel();
        ContextDimensionLabel = new javax.swing.JLabel();
        ContextAxisLabel = new javax.swing.JLabel();
        SchemaLabel = new javax.swing.JLabel();
        StartDateLabel = new javax.swing.JLabel();
        EndDateLabel = new javax.swing.JLabel();
        StartDateFormatLabel = new javax.swing.JLabel();
        EndDateFormatLabel = new javax.swing.JLabel();
        NoteContentLabel = new javax.swing.JLabel();
        NoteContextRefLabel = new javax.swing.JLabel();
        NoteContextRefComboBox = new javax.swing.JComboBox<>();
        NoteContent = new javax.swing.JTextField();
        SiconfiCodeTextBox = new javax.swing.JTextField();
        StatementEditionAreaLabel = new javax.swing.JLabel();
        CurrentStatementTagLabel = new javax.swing.JLabel();
        AvailableStatementIdComboBox = new javax.swing.JComboBox<>();
        AvailableStatementContextComboBox = new javax.swing.JComboBox<>();
        CurrentStatementContextLabel = new javax.swing.JLabel();
        AvailableContextIdComboBox = new javax.swing.JComboBox<>();
        CurrentContextNameLabel = new javax.swing.JLabel();
        ContextEditionAreaLabel = new javax.swing.JLabel();
        CurrentUnitNameLabel = new javax.swing.JLabel();
        AvailableUnitIdComboBox = new javax.swing.JComboBox<>();
        EditionUnitAreaLabel = new javax.swing.JLabel();
        EditionNoteAreaLabel = new javax.swing.JLabel();
        CurrentNoteLabel = new javax.swing.JLabel();
        NoteSelectionComboBox = new javax.swing.JComboBox<>();
        NoteCurrentContextLabel = new javax.swing.JLabel();
        NoteCurrentContextDynamicLabel = new javax.swing.JLabel();
        CurrentExplanatoryNoteContent = new javax.swing.JLabel();
        StatementValue = new javax.swing.JTextField();
        StatementDecimals = new javax.swing.JTextField();
        NonNumericElementsComboBoxLabel = new javax.swing.JLabel();
        NonNumericElementsComboBox = new javax.swing.JComboBox<>();
        SecondaryContextAxisLabel = new javax.swing.JLabel();
        SecondaryContextDimensionLabel = new javax.swing.JLabel();
        SecondaryContextAxisComboBox = new javax.swing.JComboBox<>();
        SecondaryContextDimensionComboBox = new javax.swing.JComboBox<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jSeparator4 = new javax.swing.JSeparator();

        setTitle("Element edition manager");
        setPreferredSize(new java.awt.Dimension(765, 670));

        EditButton.setText("Edit");
        EditButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditButtonActionPerformed(evt);
            }
        });

        StatementCheckBox.setText("Financial Statement");
        StatementCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StatementCheckBoxActionPerformed(evt);
            }
        });

        ContextCheckBox.setText("Context");
        ContextCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContextCheckBoxActionPerformed(evt);
            }
        });

        UnitCheckBox.setText("Unit");
        UnitCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UnitCheckBoxActionPerformed(evt);
            }
        });

        NoteCheckBox.setText("Explanatory note");
        NoteCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoteCheckBoxActionPerformed(evt);
            }
        });

        StatementValueLabel.setText("Value");

        CancelButton.setText("Cancel");
        CancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });

        ISOCodeComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        UnitNameLabel.setText("Unit name");

        ISOCodeLabel.setText("ISO code");

        StatementIdComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        availableUnitsComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        availableContextsComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        availableContextsComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                availableContextsComboBoxActionPerformed(evt);
            }
        });

        StatementTagLabel.setText("Statement tag");

        StatementDecimalsLabel.setText("Decimals");

        StatementUnitLabel.setText("Unit");

        StatementContextLabel.setText("Context");

        ContextIdLabel.setText("Context name");

        ContextAxisComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ContextAxisComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContextAxisComboBoxActionPerformed(evt);
            }
        });

        ContextMemberComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ContextMemberComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContextMemberComboBoxActionPerformed(evt);
            }
        });

        SchemaComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        SiconfiCodeLabel.setText("Institution's code");

        ContextDimensionLabel.setText("Context Dimension");

        ContextAxisLabel.setText("Context Axis");

        SchemaLabel.setText("Schema");

        StartDateLabel.setText("Start date");

        EndDateLabel.setText("End date");

        StartDateFormatLabel.setText("YYYY-MM-DD");

        EndDateFormatLabel.setText("YYYY-MM-DD");

        NoteContentLabel.setText("Note");

        NoteContextRefLabel.setText("Context");

        NoteContextRefComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        StatementEditionAreaLabel.setText("Edition area");

        CurrentStatementTagLabel.setText("Current statement tag");

        AvailableStatementIdComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        AvailableStatementIdComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvailableStatementIdComboBoxActionPerformed(evt);
            }
        });

        AvailableStatementContextComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        AvailableStatementContextComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvailableStatementContextComboBoxActionPerformed(evt);
            }
        });

        CurrentStatementContextLabel.setText("Current statement context");

        AvailableContextIdComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        AvailableContextIdComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvailableContextIdComboBoxActionPerformed(evt);
            }
        });

        CurrentContextNameLabel.setText("Current context name");

        ContextEditionAreaLabel.setText("Edition area");

        CurrentUnitNameLabel.setText("Current unit name");

        AvailableUnitIdComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        AvailableUnitIdComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AvailableUnitIdComboBoxActionPerformed(evt);
            }
        });

        EditionUnitAreaLabel.setText("Edition area");

        EditionNoteAreaLabel.setText("Edition area");

        CurrentNoteLabel.setText("Current note");

        NoteSelectionComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        NoteSelectionComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoteSelectionComboBoxActionPerformed(evt);
            }
        });

        NoteCurrentContextLabel.setText("Current context");

        NoteCurrentContextDynamicLabel.setText(" ");

        CurrentExplanatoryNoteContent.setText(" ");

        StatementValue.setText(" ");

        StatementDecimals.setText(" ");

        NonNumericElementsComboBoxLabel.setText("Non numeric element tag");

        NonNumericElementsComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        SecondaryContextAxisLabel.setText("Secondary Context Axis");

        SecondaryContextDimensionLabel.setText("Secondary Context Dimension");

        SecondaryContextAxisComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        SecondaryContextDimensionComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NoteContextRefComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NoteContextRefLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(NoteContent)
                                .addGap(282, 282, 282))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(NoteContentLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(NonNumericElementsComboBoxLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(CurrentNoteLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(NoteSelectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(CancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(EditionNoteAreaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(NonNumericElementsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(62, 62, 62)
                                .addComponent(EditButton, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CurrentExplanatoryNoteContent, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(StatementValue, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(StatementDecimals, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(availableUnitsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(StatementUnitLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(availableContextsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(StatementContextLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(EditionUnitAreaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(UnitCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(13, 13, 13)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(UnitNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(UnitId, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(ISOCodeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(ISOCodeComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(CurrentUnitNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(18, 18, 18)
                                                        .addComponent(AvailableUnitIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(StartDateFormatLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(SecondaryContextAxisLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGroup(layout.createSequentialGroup()
                                                                .addComponent(StartDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addComponent(EndDateFormatLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                            .addGroup(layout.createSequentialGroup()
                                                                .addComponent(ContextCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(12, 12, 12)
                                                                .addComponent(ContextIdLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                            .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                    .addComponent(EndDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(ContextEditionAreaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(36, 36, 36)
                                                        .addComponent(ContextId, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(20, 20, 20)))
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(SiconfiCodeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGap(3, 3, 3)
                                                        .addComponent(SchemaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addComponent(SchemaComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(SiconfiCodeTextBox, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(10, 10, 10)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(SecondaryContextDimensionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(ContextAxisLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(ContextDimensionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(ContextAxisComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(ContextMemberComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(91, 91, 91)
                                                .addComponent(CurrentContextNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(AvailableContextIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(SecondaryContextAxisComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 359, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(SecondaryContextDimensionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(StatementEditionAreaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(StatementValueLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(StatementCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, 0)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(StatementIdComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(CurrentStatementTagLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(CurrentStatementContextLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(AvailableStatementIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(AvailableStatementContextComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addComponent(StatementTagLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(154, 154, 154)
                                                .addComponent(StatementDecimalsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(0, 16, Short.MAX_VALUE))
                            .addComponent(jSeparator4)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(NoteCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(NoteCurrentContextLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(NoteCurrentContextDynamicLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43))
                            .addComponent(jSeparator2))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AvailableContextIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CurrentContextNameLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ContextAxisLabel)
                            .addComponent(SiconfiCodeLabel)
                            .addComponent(ContextIdLabel)))
                    .addComponent(ContextCheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ContextAxisComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(SiconfiCodeTextBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ContextId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(ContextEditionAreaLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(StartDateLabel)
                        .addComponent(EndDateLabel))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(SchemaLabel)
                        .addComponent(ContextDimensionLabel)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ContextMemberComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SchemaComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StartDateFormatLabel)
                    .addComponent(EndDateFormatLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SecondaryContextAxisLabel)
                    .addComponent(SecondaryContextDimensionLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SecondaryContextAxisComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SecondaryContextDimensionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CurrentUnitNameLabel)
                    .addComponent(AvailableUnitIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(UnitCheckBox)
                    .addComponent(UnitNameLabel)
                    .addComponent(ISOCodeLabel))
                .addGap(2, 2, 2)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(UnitId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ISOCodeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EditionUnitAreaLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(StatementCheckBox)
                        .addComponent(AvailableStatementIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(AvailableStatementContextComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(CurrentStatementTagLabel)
                        .addGap(27, 27, 27))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(CurrentStatementContextLabel)
                        .addGap(26, 26, 26)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(StatementTagLabel)
                        .addGap(1, 1, 1)
                        .addComponent(StatementIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(StatementEditionAreaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StatementValueLabel)
                    .addComponent(StatementDecimalsLabel)
                    .addComponent(StatementUnitLabel)
                    .addComponent(StatementContextLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(availableUnitsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(availableContextsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StatementValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StatementDecimals, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 5, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CurrentNoteLabel)
                    .addComponent(NoteSelectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NoteCurrentContextLabel)
                    .addComponent(NoteCurrentContextDynamicLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NoteCheckBox)
                    .addComponent(NonNumericElementsComboBoxLabel))
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EditionNoteAreaLabel)
                    .addComponent(NonNumericElementsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EditButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NoteContextRefLabel)
                    .addComponent(NoteContentLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NoteContextRefComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NoteContent)
                    .addComponent(CancelButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addComponent(CurrentExplanatoryNoteContent)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EditButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditButtonActionPerformed
        // TODO add your handling code here:
        //This button adds instance elements to the report, as long as they sucessfuly go through the validation steps below
        //Boolean variable to verify if the element is valid and if the app shall dispose the window
        boolean IsElementValid = false;
        boolean fault=false;
        boolean alreadyExistis=false;
        int repetitionCheckerIndex=0-5;
        char valueComparator;
        //Checking for financial statement insertion validity
        if(StatementCheckBox.isSelected()){
            //Checking for previously added context and unit
            if(!instanceReport.contextList.isEmpty()&&!instanceReport.unitList.isEmpty()){
                for(int j=0;j<StatementValue.getText().length();j++){
                    valueComparator=StatementValue.getText().charAt(j);
                    if((((((((((valueComparator!='0')&&(valueComparator!='1'))&&(valueComparator!='2'))&&(valueComparator!='3'))&&(valueComparator!='4'))&&(valueComparator!='5'))&&(valueComparator!='6'))&&(valueComparator!='7'))&&(valueComparator!='8'))&&(valueComparator!='9')){
                         fault=true;
                    }
                }
                if(!fault){                
                    String statementId = StatementIdComboBox.getSelectedItem().toString();
                    String statementContextReference = availableContextsComboBox.getSelectedItem().toString();
                    String statementUnitReference = availableUnitsComboBox.getSelectedItem().toString();
                    StatementDeclaration statementUnderEdition= new StatementDeclaration(StatementIndexCalc(statementId),statementId,statementContextReference,StatementDecimals.getText(),statementUnitReference,StatementValue.getText().substring(0, StatementValue.getText().length()-Integer.valueOf(StatementDecimals.getText()))+"."+StatementValue.getText().substring(StatementValue.getText().length()-Integer.valueOf(StatementDecimals.getText())));
                    //Checking for blank value and decimal precision
                    if(StatementDecimals.getText().equals("")||StatementValue.getText().equals("")){
                        JOptionPane.showMessageDialog(this,M_Error13,jopTitle,JOptionPane.WARNING_MESSAGE);
                    }else{
                        //then it is a valid statement input
                        //Checking for statement information availability
                        if((AvailableStatementIdComboBox.getItemCount() != 0)&&(AvailableStatementContextComboBox.getItemCount() != 0)){
                            //String variables to store the data gathered from the Combobox. That is the minimal information you need to distinguish financial statements.
                            String StatementIdToBeDeleted,StatementContextRefToBeDeleted;
                            StatementIdToBeDeleted=AvailableStatementIdComboBox.getSelectedItem().toString();
                            StatementContextRefToBeDeleted=AvailableStatementContextComboBox.getSelectedItem().toString();            
                            for(StatementDeclaration s : instanceReport.statementList){
                                if(StatementIdToBeDeleted.equals(s.getId())&&(StatementContextRefToBeDeleted.equals(s.getContextRef()))){
                                    repetitionCheckerIndex=instanceReport.statementList.indexOf(s);
                                }
                            }
                            for(StatementDeclaration s : instanceReport.statementList){
                                if(statementUnderEdition.getId().equals(s.getId())){
                                    if(statementUnderEdition.getContextRef().equals(s.getContextRef())){
                                        if(repetitionCheckerIndex!=instanceReport.statementList.indexOf(s)){
                                            alreadyExistis=true;
                                        }
                                    }
                                }
                            }
                            if(!alreadyExistis){
                                //Edit element = delete existing one, then add a new one                            
                                IsElementValid=instanceReport.statementList.removeIf(statement -> (statement.getId().equals(StatementIdToBeDeleted) && statement.getContextRef().equals(StatementContextRefToBeDeleted)));
                                if(IsElementValid){
                                    instanceReport.addStatement(statementUnderEdition);
                                    //then it is a valid element
                                }
                            }
                        }else{
                        JOptionPane.showMessageDialog(this,M_Error14,jopTitle,JOptionPane.WARNING_MESSAGE);
                        }
                    }
                }
            }else{
                JOptionPane.showMessageDialog(this,M_Error15,jopTitle,JOptionPane.WARNING_MESSAGE);
            }            
        }
        //Checking for context insertion validity
        if(ContextCheckBox.isSelected()){
            //Gathering context elements
            String SiconfiCode = SiconfiCodeTextBox.getText().toUpperCase();
            String ContextSchema = SchemaComboBox.getSelectedItem().toString();
            String SiconfiAxis = ContextAxisComboBox.getSelectedItem().toString();
            String SiconfiDimension = ContextMemberComboBox.getSelectedItem().toString();      
            ContextDeclaration contextUnderEdition = new ContextDeclaration(ContextIndexCalc(SiconfiDimension),ContextId.getText().replace(" ","").toUpperCase(),SiconfiCode,ContextSchema,SiconfiAxis,SiconfiDimension,jComboBox1.getSelectedItem().toString(),jComboBox2.getSelectedItem().toString());
            
            //It was not possible to load the 11000 codes as an array for a combobox, so I had to put them into a text file and serach for them every time the user adds a context.
            
            //creating a boolean variable to check if the inserted context's institution belongs to Siconfi's table 
            boolean ContextInstitutionIndexFound=false;           
            try {
                //initializing a Buffered Reader so its possible to use the method readLine() to get the codes from the text file and to compare them with the inted one  
                InputStream reader = getClass().getResourceAsStream("SiconfiEntityCode.txt");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes
                String CodeLine;                
                // loop for checking all codes within the text file 
                while ((CodeLine = bufferedReader.readLine()) != null) {
                    // checking if there is an equivalent code...
                    if(SiconfiCode.equals(CodeLine)){
                        ContextInstitutionIndexFound=true;
                    }
                }
                //closing the file reader
                reader.close();
                
                //creating a boolean variable to check if the inserted context's period is valid
                boolean ContextPeriodValid=false;
                if(!jComboBox2.getSelectedItem().toString().equals("")&&!jComboBox1.getSelectedItem().toString().equals("")){
                    // creating two string to sore and process the dates the user typed in
                    String OlderDate,NewerDate;
                    OlderDate=jComboBox2.getSelectedItem().toString().substring(0,4)+jComboBox2.getSelectedItem().toString().substring(5,7)+jComboBox2.getSelectedItem().toString().substring(8,10);
                    NewerDate=jComboBox1.getSelectedItem().toString().substring(0,4)+jComboBox1.getSelectedItem().toString().substring(5,7)+jComboBox1.getSelectedItem().toString().substring(8,10);
                    //check if the informed dates describe a valid period
                    if(Integer.valueOf(OlderDate)>Integer.valueOf(NewerDate)){
                        ContextPeriodValid=true;                    
                    }
                }
                //Overall context validity check
                if(!ContextInstitutionIndexFound){
                    // if there is no equivalent code...
                    JOptionPane.showMessageDialog(this,M_Error16,jopTitle,JOptionPane.WARNING_MESSAGE);                    
                }else{
                    //if the period is valid...
                    if(!ContextPeriodValid){
                        JOptionPane.showMessageDialog(this,M_Error17,jopTitle,JOptionPane.WARNING_MESSAGE);
                    }else{
                       //if the context id is not blank
                       if(ContextId.getText().equals("")){
                           //JOptionPane.showMessageDialog(null,M_Error18,jopTitle,JOptionPane.WARNING_MESSAGE);
                       }else{
                           //then it is a valid context input                         
                           if(AvailableContextIdComboBox.getItemCount() != 0){
                               boolean exist=false;
                               int contextIndexAux=0-1;
                               //String variables to store the data gathered from the Combobox. That is the minimal information you need to distinguish financial contexts.
                               String ContextIdToBeDeleted = AvailableContextIdComboBox.getSelectedItem().toString();
                               for(ContextDeclaration contexToDelete : instanceReport.contextList){
                                   if(contexToDelete.getId().equals(ContextIdToBeDeleted)){
                                       contextIndexAux=contexToDelete.getIndex();
                                       repetitionCheckerIndex=instanceReport.contextList.indexOf(contexToDelete);
                                   }
                               }
                               for(ContextDeclaration contexToDelete : instanceReport.contextList){
                                   if(contexToDelete.getId().equals(contextUnderEdition.getId())&&(contextIndexAux!=contexToDelete.getIndex())){
                                       exist=true;
                                   }
                                   if(contextUnderEdition.getEntityIdentifier().equals(contexToDelete.getEntityIdentifier())){
                                        if(contextUnderEdition.getExplicitMemberDimension().equals(contexToDelete.getExplicitMemberDimension())){
                                           if(contextUnderEdition.getSiconfiDimension().equals(contexToDelete.getSiconfiDimension())){
                                             if(contextUnderEdition.getHasCoupledAxis()){
                                                 if(contextUnderEdition.getSecondaryExplicitMemberDimension().equals(contexToDelete.getSecondaryExplicitMemberDimension())){
                                                     if(contextUnderEdition.getSecondarySiconfiDimension().equals(contexToDelete.getSecondarySiconfiDimension())){
                                                         if(contextUnderEdition.getPeriodStartDate().equals(contexToDelete.getPeriodStartDate())){
                                                              if(contextUnderEdition.getPeriodEndDate().equals(contexToDelete.getPeriodEndDate())){
                                                                  if(repetitionCheckerIndex!=instanceReport.contextList.indexOf(contexToDelete)){
                                                                      alreadyExistis=true;
                                                                    }
                                                                }
                                                            }                                                     
                                                        }
                                                    }
                                                }else{
                                                  if(contextUnderEdition.getPeriodStartDate().equals(contexToDelete.getPeriodStartDate())){
                                                      if(contextUnderEdition.getPeriodEndDate().equals(contexToDelete.getPeriodEndDate())){
                                                          if(repetitionCheckerIndex!=instanceReport.contextList.indexOf(contexToDelete)){
                                                              alreadyExistis=true;
                                                            }
                                                        }
                                                    }
                                                }  
                                            }    
                                        }
                                    }   
                                }
                               if(exist||alreadyExistis){
                                   //JOptionPane.showMessageDialog(null,M_Error18,jopTitle,JOptionPane.WARNING_MESSAGE);
                               }else{                                   
                                   //Edit element = delete existing one, then add a new one
                                   IsElementValid=instanceReport.contextList.removeIf(context -> context.getId().equals(ContextIdToBeDeleted));
                                   if(IsElementValid){
                                      // if its a cupled axis context, then...
                                       if(SecondaryContextAxisComboBox.isEnabled()){
                                           contextUnderEdition.setHasCoupledAxis(true);
                                           contextUnderEdition.setSecondaryExplicitMemberDimension(SecondaryContextAxisComboBox.getSelectedItem().toString());
                                           contextUnderEdition.setSecondarySiconfiDimension(SecondaryContextDimensionComboBox.getSelectedItem().toString());
                                       }                                         
                                       instanceReport.addContext(contextUnderEdition);
                                       //then it is a valid element                               
                                   }
                               }                               
                            }else{
                                JOptionPane.showMessageDialog(this,M_Error19,jopTitle,JOptionPane.WARNING_MESSAGE);
                            }                           
                       }
                    }
                }                
            } catch (IOException e) {
                e.printStackTrace();
            }                        
        }         
        //Checking for unit insertion validity
        if(UnitCheckBox.isSelected()){            
            //Gathering context elements
            String IsoCode = ISOCodeComboBox.getSelectedItem().toString();
            UnitDeclaration unitUnderEdition = new UnitDeclaration(UnitId.getText().toUpperCase().replace(" ",""),IsoCode);
            //cheking for blank unit id
            if(!UnitId.getText().equals("")){
                //then it is a valid unit
                //Checking for unit information availability
                if(AvailableUnitIdComboBox.getItemCount() != 0){
                    //String variables to store the data gathered from the Combobox. That is the minimal information you need to distinguish financial units.
                    String UnitIdToBeDeleted = AvailableUnitIdComboBox.getSelectedItem().toString();
                    //Edit element = delete existing one, then add a new one
                    IsElementValid=instanceReport.unitList.removeIf(unit -> unit.getId().equals(UnitIdToBeDeleted));
                    if(IsElementValid){
                        instanceReport.addUnit(unitUnderEdition);
                        //then it is a valid element                    
                    }                                    
                }else{
                    JOptionPane.showMessageDialog(this,M_Error20,jopTitle,JOptionPane.WARNING_MESSAGE);
                }                
            }else{
                JOptionPane.showMessageDialog(this,M_Error13,jopTitle,JOptionPane.WARNING_MESSAGE);
            }            
        }
        //Checking for explanatory note insertion validity
        if(NoteCheckBox.isSelected()){
            if(NonNumericElementsComboBox.getSelectedItem().toString().equals(nonNumericElementsComboBox.elementAt(0))){
            //Checking for previously added context
            if(!instanceReport.contextList.isEmpty()){
                //cheking for blank note content
                if(!NoteContent.getText().equals("")){
                    //Gathering explanatory note elements
                    String noteContextRef = NoteContextRefComboBox.getSelectedItem().toString();
                    //Checking for explanantory note information availability
                    if(NoteSelectionComboBox.getItemCount() != 0){
                        //String variables to store the data gathered from the dynamic labels.
                        String NoteIdToBeDeleted = CurrentExplanatoryNoteContent.getText();
                        String NoteContexToBeDeleted = NoteCurrentContextDynamicLabel.getText();
                        //Edit element = delete existing one, then add a new one
                        IsElementValid=instanceReport.noteList.removeIf(note -> note.getContent().equals(NoteIdToBeDeleted)&& note.getContextRef().equals(NoteContexToBeDeleted));
                        if(IsElementValid){
                            instanceReport.addNote(new NonNumericDeclaration(noteContextRef,NoteContent.getText(),NonNumericElementsComboBox.getSelectedItem().toString()));
                            //then it is a valid element                        
                        }                                    
                    }else{
                        JOptionPane.showMessageDialog(this,M_Error21,jopTitle,JOptionPane.WARNING_MESSAGE);
                    }                    
                }
            }else{
                JOptionPane.showMessageDialog(this,M_Error22,jopTitle,JOptionPane.WARNING_MESSAGE);
            }            
        }
        }
        // If somehow the user did not provide a valid input...
        if(!IsElementValid){
            if(StatementCheckBox.isSelected()){
                JOptionPane.showMessageDialog(this,M_Error28,jopTitle,JOptionPane.WARNING_MESSAGE);
            }else{
                if(ContextCheckBox.isSelected()){                
                    JOptionPane.showMessageDialog(this,M_Error29,jopTitle,JOptionPane.WARNING_MESSAGE);
                }else{
                    JOptionPane.showMessageDialog(this,M_Error23,jopTitle,JOptionPane.WARNING_MESSAGE);
                }
            }
        }
        // This window is only disposed after a successful element insertion        
        if(IsElementValid){
            LogTextArea.setText(LogTextArea.getText()+"\n"+M_Suc02);
            this.dispose();            
        }                                    
    }//GEN-LAST:event_EditButtonActionPerformed

    private void CancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelButtonActionPerformed
        // TODO add your handling code here:
        InsertOptionUpdate(InsertOption);
        this.setVisible(false);
        if(StatementCheckBox.isSelected()){StatementCheckBox.doClick();}
        if(ContextCheckBox.isSelected()){ContextCheckBox.doClick();}
        if(UnitCheckBox.isSelected()){UnitCheckBox.doClick();}
        if(NoteCheckBox.isSelected()){NoteCheckBox.doClick();}        
    }//GEN-LAST:event_CancelButtonActionPerformed

    private void StatementCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StatementCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(StatementCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        ContextCheckBox.setEnabled(state);
        ContextId.setEnabled(state);
        SiconfiCodeTextBox.setEnabled(state);
        ContextAxisComboBox.setEnabled(state);
        jComboBox1.setEnabled(state);
        jComboBox2.setEnabled(state);
        SchemaComboBox.setEnabled(state);
        ContextMemberComboBox.setEnabled(state);
        UnitCheckBox.setEnabled(state);
        UnitId.setEnabled(state);
        ISOCodeComboBox.setEnabled(state);
        NoteCheckBox.setEnabled(state);
        NoteContextRefComboBox.setEnabled(state);
        NoteContent.setEnabled(state);
        AvailableContextIdComboBox.setEnabled(state);
        AvailableUnitIdComboBox.setEnabled(state);
        NoteSelectionComboBox.setEnabled(state);
        NoteCurrentContextDynamicLabel.setEnabled(state);
        NonNumericElementsComboBox.setEnabled(state);
        SecondaryContextAxisComboBox.setEnabled(false);
        SecondaryContextDimensionComboBox.setEnabled(false);        
    }//GEN-LAST:event_StatementCheckBoxActionPerformed

    private void ContextCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContextCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(ContextCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        StatementCheckBox.setEnabled(state);
        StatementIdComboBox.setEnabled(state);
        StatementValue.setEnabled(state);
        StatementDecimals.setEnabled(state);
        availableUnitsComboBox.setEnabled(state);
        availableContextsComboBox.setEnabled(state);
        UnitCheckBox.setEnabled(state);
        UnitId.setEnabled(state);
        ISOCodeComboBox.setEnabled(state);
        NoteCheckBox.setEnabled(state);
        NoteContextRefComboBox.setEnabled(state);
        NoteContent.setEnabled(state);
        AvailableUnitIdComboBox.setEnabled(state);
        NoteSelectionComboBox.setEnabled(state);
        AvailableStatementIdComboBox.setEnabled(state);
        AvailableStatementContextComboBox.setEnabled(state);
        NoteCurrentContextDynamicLabel.setEnabled(state);
        NonNumericElementsComboBox.setEnabled(state);
    }//GEN-LAST:event_ContextCheckBoxActionPerformed

    private void UnitCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UnitCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(UnitCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        StatementCheckBox.setEnabled(state);
        StatementIdComboBox.setEnabled(state);
        StatementValue.setEnabled(state);
        StatementDecimals.setEnabled(state);
        availableUnitsComboBox.setEnabled(state);
        availableContextsComboBox.setEnabled(state);
        ContextCheckBox.setEnabled(state);
        ContextId.setEnabled(state);
        SiconfiCodeTextBox.setEnabled(state);
        ContextAxisComboBox.setEnabled(state);
        jComboBox1.setEnabled(state);
        jComboBox2.setEnabled(state);
        SchemaComboBox.setEnabled(state);
        ContextMemberComboBox.setEnabled(state);
        NoteCheckBox.setEnabled(state);
        NoteContextRefComboBox.setEnabled(state);
        NoteContent.setEnabled(state);
        NoteSelectionComboBox.setEnabled(state);
        AvailableStatementIdComboBox.setEnabled(state);
        AvailableStatementContextComboBox.setEnabled(state);
        AvailableContextIdComboBox.setEnabled(state);
        NoteCurrentContextDynamicLabel.setEnabled(state);
        NonNumericElementsComboBox.setEnabled(state);
        SecondaryContextAxisComboBox.setEnabled(false);
        SecondaryContextDimensionComboBox.setEnabled(false);        
    }//GEN-LAST:event_UnitCheckBoxActionPerformed

    private void NoteCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoteCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(NoteCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        StatementCheckBox.setEnabled(state);
        StatementIdComboBox.setEnabled(state);
        StatementValue.setEnabled(state);
        StatementDecimals.setEnabled(state);
        availableUnitsComboBox.setEnabled(state);
        availableContextsComboBox.setEnabled(state);
        ContextCheckBox.setEnabled(state);
        ContextId.setEnabled(state);
        SiconfiCodeTextBox.setEnabled(state);
        ContextAxisComboBox.setEnabled(state);
        jComboBox1.setEnabled(state);
        jComboBox2.setEnabled(state);
        SchemaComboBox.setEnabled(state);
        ContextMemberComboBox.setEnabled(state);
        UnitCheckBox.setEnabled(state);
        UnitId.setEnabled(state);
        ISOCodeComboBox.setEnabled(state);
        AvailableStatementIdComboBox.setEnabled(state);
        AvailableStatementContextComboBox.setEnabled(state);
        AvailableContextIdComboBox.setEnabled(state); 
        AvailableUnitIdComboBox.setEnabled(state);
        SecondaryContextAxisComboBox.setEnabled(false);
        SecondaryContextDimensionComboBox.setEnabled(false);
    }//GEN-LAST:event_NoteCheckBoxActionPerformed

    private void ContextMemberComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContextMemberComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContextMemberComboBoxActionPerformed

    private void ContextAxisComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContextAxisComboBoxActionPerformed
        // TODO add your handling code here:
        Vector<String> axisList = new Vector<String>();
        boolean thereIsCoupledAxis=false;        
        int i, j;
        String CodeLine,CodeLine1;
        InputStream reader;
        BufferedReader bufferedReader;
        ContextMemberComboBox.removeAllItems();
        SecondaryContextAxisComboBox.removeAllItems();
        SecondaryContextDimensionComboBox.removeAllItems();
        axisList.removeAllElements();
        try{
            ContextDimensionComboBoxFiller(contextAxisComboBox,contextMemberComboBox);
            if(ContextAxisComboBox.getItemCount()!=0){
            for(i=0;i<coupledAxisList.size();i++){                
                if(ContextAxisComboBox.getSelectedItem().toString().equals(coupledAxisList.elementAt(i))){
                   thereIsCoupledAxis=true;
                   reader = getClass().getResourceAsStream("SecondarySiconfiAxis"+String.valueOf(i)+".txt");
                   bufferedReader = new BufferedReader(new InputStreamReader(reader));
                   while ((CodeLine = bufferedReader.readLine()) != null) {
                       SecondaryContextAxisComboBox.addItem(CodeLine);
                       axisList.add(CodeLine);
                   }
                   reader.close();
                   for (j=0;j<SecondaryContextAxisComboBox.getItemCount();j++){
                       if(SecondaryContextAxisComboBox.getSelectedItem().toString().equals(axisList.elementAt(j))){
                           reader = getClass().getResourceAsStream("SecondaryContextMember"+String.valueOf(j)+"Axis"+String.valueOf(i)+".txt");
                           bufferedReader = new BufferedReader(new InputStreamReader(reader));
                           while ((CodeLine1 = bufferedReader.readLine()) != null) {
                               SecondaryContextDimensionComboBox.addItem(CodeLine1);
                            }
                           reader.close();                           
                       }
                   } 
                }
            }
            if(thereIsCoupledAxis){
                SecondaryContextAxisComboBox.setEnabled(true);
                SecondaryContextDimensionComboBox.setEnabled(true);
            }else{
                SecondaryContextAxisComboBox.setEnabled(false);
                SecondaryContextDimensionComboBox.setEnabled(false);
            }
            }
        }catch(Exception e){}
    }//GEN-LAST:event_ContextAxisComboBoxActionPerformed

    private void availableContextsComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_availableContextsComboBoxActionPerformed
        // TODO add your handling code here:
        StatementIdComboBox.removeAllItems();
        try{StatementIdComboBoxFiller(contextAxisComboBox,statementIdComboBox,instanceReport);}catch(Exception e){}
    }//GEN-LAST:event_availableContextsComboBoxActionPerformed

    private void AvailableStatementIdComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvailableStatementIdComboBoxActionPerformed
        // TODO add your handling code here:
        LocateStatement(instanceReport);
    }//GEN-LAST:event_AvailableStatementIdComboBoxActionPerformed

    private void AvailableStatementContextComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvailableStatementContextComboBoxActionPerformed
        // TODO add your handling code here:
        LocateStatement(instanceReport);
    }//GEN-LAST:event_AvailableStatementContextComboBoxActionPerformed

    private void AvailableContextIdComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvailableContextIdComboBoxActionPerformed
        // TODO add your handling code here:
        LocateContext(instanceReport);
    }//GEN-LAST:event_AvailableContextIdComboBoxActionPerformed

    private void AvailableUnitIdComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AvailableUnitIdComboBoxActionPerformed
        // TODO add your handling code here:
        LocateUnit(instanceReport);
    }//GEN-LAST:event_AvailableUnitIdComboBoxActionPerformed

    private void NoteSelectionComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoteSelectionComboBoxActionPerformed
        // TODO add your handling code here:
        LocateNote(instanceReport);
    }//GEN-LAST:event_NoteSelectionComboBoxActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> AvailableContextIdComboBox;
    private javax.swing.JComboBox<String> AvailableStatementContextComboBox;
    private javax.swing.JComboBox<String> AvailableStatementIdComboBox;
    private javax.swing.JComboBox<String> AvailableUnitIdComboBox;
    private javax.swing.JButton CancelButton;
    private javax.swing.JComboBox<String> ContextAxisComboBox;
    private javax.swing.JLabel ContextAxisLabel;
    private javax.swing.JCheckBox ContextCheckBox;
    private javax.swing.JLabel ContextDimensionLabel;
    private javax.swing.JLabel ContextEditionAreaLabel;
    private javax.swing.JTextField ContextId;
    private javax.swing.JLabel ContextIdLabel;
    private javax.swing.JComboBox<String> ContextMemberComboBox;
    private javax.swing.JLabel CurrentContextNameLabel;
    private javax.swing.JLabel CurrentExplanatoryNoteContent;
    private javax.swing.JLabel CurrentNoteLabel;
    private javax.swing.JLabel CurrentStatementContextLabel;
    private javax.swing.JLabel CurrentStatementTagLabel;
    private javax.swing.JLabel CurrentUnitNameLabel;
    private javax.swing.JButton EditButton;
    private javax.swing.JLabel EditionNoteAreaLabel;
    private javax.swing.JLabel EditionUnitAreaLabel;
    private javax.swing.JLabel EndDateFormatLabel;
    private javax.swing.JLabel EndDateLabel;
    private javax.swing.JComboBox<String> ISOCodeComboBox;
    private javax.swing.JLabel ISOCodeLabel;
    private javax.swing.JComboBox<String> NonNumericElementsComboBox;
    private javax.swing.JLabel NonNumericElementsComboBoxLabel;
    private javax.swing.JCheckBox NoteCheckBox;
    private javax.swing.JTextField NoteContent;
    private javax.swing.JLabel NoteContentLabel;
    private javax.swing.JComboBox<String> NoteContextRefComboBox;
    private javax.swing.JLabel NoteContextRefLabel;
    private javax.swing.JLabel NoteCurrentContextDynamicLabel;
    private javax.swing.JLabel NoteCurrentContextLabel;
    private javax.swing.JComboBox<String> NoteSelectionComboBox;
    private javax.swing.JComboBox<String> SchemaComboBox;
    private javax.swing.JLabel SchemaLabel;
    private javax.swing.JComboBox<String> SecondaryContextAxisComboBox;
    private javax.swing.JLabel SecondaryContextAxisLabel;
    private javax.swing.JComboBox<String> SecondaryContextDimensionComboBox;
    private javax.swing.JLabel SecondaryContextDimensionLabel;
    private javax.swing.JLabel SiconfiCodeLabel;
    private javax.swing.JTextField SiconfiCodeTextBox;
    private javax.swing.JLabel StartDateFormatLabel;
    private javax.swing.JLabel StartDateLabel;
    private javax.swing.JCheckBox StatementCheckBox;
    private javax.swing.JLabel StatementContextLabel;
    private javax.swing.JTextField StatementDecimals;
    private javax.swing.JLabel StatementDecimalsLabel;
    private javax.swing.JLabel StatementEditionAreaLabel;
    private javax.swing.JComboBox<String> StatementIdComboBox;
    private javax.swing.JLabel StatementTagLabel;
    private javax.swing.JLabel StatementUnitLabel;
    private javax.swing.JTextField StatementValue;
    private javax.swing.JLabel StatementValueLabel;
    private javax.swing.JCheckBox UnitCheckBox;
    private javax.swing.JTextField UnitId;
    private javax.swing.JLabel UnitNameLabel;
    private javax.swing.JComboBox<String> availableContextsComboBox;
    private javax.swing.JComboBox<String> availableUnitsComboBox;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    // End of variables declaration//GEN-END:variables
}
