/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;

/**
 *
 * @author anton
 */
public class UnitDeclaration {
    private String id;
    private String ISOIdentifier;
    public UnitDeclaration(String id,String ISOIdentifier){
        this.id=id;
        this.ISOIdentifier=ISOIdentifier;
     }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getISOIdentifier() {
        return "iso4217:"+ISOIdentifier;
    }
    public void setISOIdentifier(String ISOIdentifier) {
        this.ISOIdentifier = ISOIdentifier;
    }
    public String toString() {
        return id;
    }    
}
    
