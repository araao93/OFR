/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;

/**
 *
 * @author anton
 */
public class FootnoteDeclaration {
    private String footnoteLinkType;
    private String footnoteLinkRole;
    private String footnoteType;
    private String footnoteLabel;
    private String footnoteRole;
    private String footnoteXMLlang;
    private String footnoteContent;
    private String locType;
    private String locLabel;
    private String locRef;
    private String footnoteArcType;
    private String footnoteArcFrom;
    private String footnoteArcTo;
    //private String footnoteArcTitle;
    private String footnoteArcArcrole;
    public FootnoteDeclaration(String footnoteLinkType,String footnoteLinkRole,String footnoteType,String footnoteLabel,String footnoteRole,String footnoteXMLlang,String footnoteContent,String locType,String locLabel,String locRef,String footnoteArcType,String footnoteArcFrom,String footnoteArcTo,String footnoteArcArcrole){
        this.footnoteLinkType=footnoteLinkType;
        this.footnoteLinkRole=footnoteLinkRole;
        this.footnoteType=footnoteType;
        this.footnoteLabel=footnoteLabel;
        this.footnoteRole=footnoteRole;
        this.footnoteXMLlang=footnoteXMLlang;
        this.footnoteContent=footnoteContent;
        this.locType=locType;
        this.locLabel=locLabel;
        this.locRef=locRef;
        this.footnoteArcType=footnoteArcType;
        this.footnoteArcFrom=footnoteArcFrom;
        this.footnoteArcTo=footnoteArcTo;
      //this.footnoteArcTitle=footnoteArcTitle;
        this.footnoteArcArcrole=footnoteArcArcrole;
    }
    public String getFootnoteLinkType() {
        return footnoteLinkType;
    }
    public void setFootnoteLinkType(String footnoteLinkType) {
        this.footnoteLinkType = footnoteLinkType;
    }
    public String getFootnoteLinkRole() {
        return footnoteLinkRole;
    }
    public void setFootnoteLinkRole(String footnoteLinkRole) {
        this.footnoteLinkRole = footnoteLinkRole;
    }
    public String getFootnoteType() {
        return footnoteType;
    }
    public void setFootnoteType(String footnoteType) {
        this.footnoteType = footnoteType;
    }
    public String getFootnoteLabel() {
        return footnoteLabel;
    }
    public void setFootnoteLabel(String footnoteLabel) {
        this.footnoteLabel = footnoteLabel;
    }
    public String getFootnoteRole() {
        return footnoteRole;
    }
    public void setFootnoteRole(String footnoteRole) {
        this.footnoteRole = footnoteRole;
    }
    public String getFootnoteXMLlang() {
        return footnoteXMLlang;
    } 
    public void setFootnoteXMLlang(String footnoteXMLlang) {
        this.footnoteXMLlang = footnoteXMLlang;
    }
    public String getFootnoteContent() {
        return footnoteContent;
    }
    public void setFootnoteContent(String footnoteContent) {
        this.footnoteContent = footnoteContent;
    }
    public String getLocType() {
        return locType;
    }
    public void setLocType(String locType) {
        this.locType = locType;
    }
    public String getLocLabel() {
        return locLabel;
    }
    public void setLocLabel(String locLabel) {
        this.locLabel = locLabel;
    }
    public String getLocRef() {
        return locRef;
    }
    public void setLocRef(String locRef) {
        this.locRef = locRef;
    }
    public String getFootnoteArcType() {
        return footnoteArcType;
    }
    public void setFootnoteArcType(String footnoteArcType) {
        this.footnoteArcType = footnoteArcType;
    }
    public String getFootnoteArcFrom() {
        return footnoteArcFrom;
    }
    public void setFootnoteArcFrom(String footnoteArcFrom) {
        this.footnoteArcFrom = footnoteArcFrom;
    }
    public String getFootnoteArcTo() {
        return footnoteArcTo;
    }
    public void setFootnoteArcTo(String footnoteArcTo) {
        this.footnoteArcTo = footnoteArcTo;
    }
  //public String getFootnoteArcTitle() {
  //    return footnoteArcTitle;
  //}
  //public void setFootnoteArcTitle(String footnoteArcTitle) {
  //    this.footnoteArcTitle = footnoteArcTitle;
  //}
    public String getFootnoteArcArcrole() {
        return footnoteArcArcrole;
    }
    public void setFootnoteArcArcrole(String footnoteArcArcrole) {
        this.footnoteArcArcrole = footnoteArcArcrole;
    }    
}
