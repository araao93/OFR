/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;

/**
 *
 * @author anton
 */
public class NonNumericDeclaration {
    private int Index;
    private String ContextRef;
    private String Content;
    private String Label;
    private String Attachment;
    public NonNumericDeclaration(String ContextRef,String Content,String Label){
        this.Index=Index;
        this.ContextRef=ContextRef;
        this.Content=Content;
        this.Label=Label;
    }
        public String getContextRef() {
        return ContextRef;
    }
    public void setContextRef(String ContextRef) {
        this.ContextRef = ContextRef;
    }
    public String getContent() {
        return Content;
    }
    public void setContent(String Content) {
        this.Content = Content;
    }
    public int getIndex(){
        return Index;
    }
    public void setIndex(int Index){
        this.Index = Index;
    }
    public String getLabel(){
        return Label;
    }
    public void setLabel(String Label){
        this.Label = Label;
    }
    public String getAttachment(){
        return Attachment;
    }
    public void setAttachment(String Attachment){
        this.Attachment = Attachment;
    }    
    public String toString() {
        return Label;
    }    
}
