/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;

import static com.sun.jmx.mbeanserver.DefaultMXBeanMappingFactory.propertyName;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JInternalFrame;
import java.lang.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import javax.swing.event.*;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultMutableTreeNode;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import java.io.File;
import java.io.IOException;
import java.util.List;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import java.awt.*; 
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.util.Vector;
import javax.swing.Icon;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;

;
/**
 *
 * @author anton
 */
public class OpenFinancialReporting extends javax.swing.JFrame  implements InternalFrameListener,ActionListener{
        //It defines a list to store the financial statements that will compose the XBRL instance document
        List<StatementDeclaration> statementList;
        //It defines a list to store the contexts that the financial statements refer to
        List<ContextDeclaration> contextList;
        //It defines a list to store the units to express the financial statements
        List<UnitDeclaration> unitList;
        //It defines a list to store the explanatory notes regarding contexts
        List<NonNumericDeclaration> noteList;
        InstanceReport instanceReport;
        //It defines a variavle to store the instance file name
        String fileName;
        //It defines a variavle to store the instance file path
        String filePath;
        //It defines a variable to store the language the api shall display
        String ChoosenLanguage="EN";
        //It defines a variable to store the JTree root node's label
        String rootNodeLabel="Report";
        //initializing strings to store the success messages text
        String M_Suc09="Instance document successfully loaded.",M_Suc10="Instance file successfully generated.",M_Suc07="Instance file successfully validated.",M_Suc11="There are no problems regarding the accounts' context declaration.",M_Suc12="There are no problems regarding the accounts' unit declaration.",M_Suc13="There are no problems regarding the accounts' axis declaration.",M_Suc14="There are no problems regarding the non-numeric elements.",M_Suc15="There are no problems regarding the accounts' precision.",M_Suc16="Report model successfully loaded.",M_Error26="The instance document could not be validated."+"\n"+"There might be wrong values registered in the following accounts:"+"\n"+"ReceitasExcetoIntraOrcamentarias"+"\n"+"related to the following contexts:",M_Error27="The file load process failed. Please try it again.",M_Error32="The instance document could not be validated."+"\n"+" There might be some missing elements for validating the report.";
        //initializing strings to store the confimation messages
        String M_Conf00="Do you wish to save the current report before quitting?", M_Conf01="Do you wish to save the current report before loading the new report model?";
        //initializing strings to store the inconsistencies related messages
        String M_Fault00="The following accounts are missin a valid context declaration:",M_Fault01="The following accounts are missin a valid unit declaration:",M_Fault02="The following accounts are missin a valid axis declaration:",M_Fault03="Non-numeric elements regarding the context list below need valid context references:",M_Fault04="Siconfi's reports use only two decimals to express account values. Please check such inconsistencies regarding the following accounts:";
        //initializing string to store the help button message
        String M_Help="OFR prototype V1."+"\n"+"Thanks for using the Open Financial Reporting software!"+"\n"+"If you got any trouble, access the link to the software's documentation:"+"\n"+"";
        //initializing string to store the validation warn message
        String M_Error30="Please, remove the report's inconsistencies before trying to validate it.";
        String WIP = "This source will be available in another OFR's version...";
        //initializing string to store the report option
        String reportOption="";
        //Define jInternalFrames 
        AddElement addElement;
        DeleteElement deleteElement;
        EditElement editElement;       
        //Initialize the JTree elements
        DefaultTreeModel model;
        DefaultMutableTreeNode rootNode,newElementnode,newContentnode;
        //vectors to assure the internal index calculation to preserv the order of the presentation link  
        Vector<String> statementIdIndex = new Vector<String>();
        Vector<String> contextMemberIndex = new Vector<String>();
        Vector<String> nonNumericElementsComboBox = new Vector<String>();
        Vector<String> contextAxis = new Vector<String>();
        Vector<String> schemaRef = new Vector<String>();
        Vector<String> nonNumericElements = new Vector<String>();
        Vector<String> entryPointsList = new Vector<String>();
        Vector<String> schemaRefList = new Vector<String>();
        //initializing file chooser for saving and opening files
        JFileChooser saveJfc,openJfc;
        //string for file chooser titles
        String saveJfcTitle="Save",openJfcTitle="Open";
        //String for the confimation joptionpane titles
        String jopTitle="MESSAGE";
        //String for the confimation joptionpane options
        String options[] = {"Yes","No"};
        //Valid report
        boolean validReportOppening;
        //Options from the meus
        int insertOption,editOption=0,removeOption=0;
        //Strings for the tip messages
        String M_Tip00 = "First, go to the Report Models menu and choose one among the available options.",
                M_Tip01 = "To cerate a new report, go to the File menu and choose the option New Report",
                M_Tip02 = "Your report is empty! Go to the Insert menu, choose the option Insert Context, and insert your data through the opened window.",
                M_Tip03 = "Try inserting a new context! Go to the Insert menu, choose the option Insert Context, and insert your data through the opened window.",
                M_Tip04 = "Try inserting a new Unit! Go to the Insert menu, choose the option Insert Unit, and insert your data through the opened window.",
                M_Tip05 = "Try inserting a new Account! Go to the Insert menu, choose the option Insert Account, and insert your data through the opened window.",
                M_Tip06 = "Try inserting a new Non Numeric element! Go to the Insert menu, choose the option Insert Non Numeric element, and insert your data through the opened window.",
                M_Tip07 = "You can edit elements through the options under the Edit menu whenever the report validation is unsuccessful."+"\n"+"You can also deal with inconsistent elements in that way."+"\n"+"You can also delete elements through the options under the Remove menu.",
                M_Tip08 = "In the Element Edit Manager window, use the blue boxes to choose the element you want to edit."+"\n"+"Then the OFR will fill up the remaining boxes with the information of that element for you to edit.",
                M_Tip09 = "In the Element Exclusion Manager window, use the boxes to choose the element you want to remove.";
    /**
     * Creates new form NewMDIApplication
     */
    public OpenFinancialReporting() throws IOException {
        LoadAuxiliarFiles();
        //Initializing all java.swing components
        initComponents();
        //setting icon
        InputStream reader = getClass().getResourceAsStream("OFRLogo2.png");
        BufferedImage img = ImageIO.read(reader);
        setIconImage(img);
        reader.close();
        //needs dynamical interface code i don't know how to imlplement
        ReportModel0.setText(entryPointsList.elementAt(0));
        ReportModel1.setText(entryPointsList.elementAt(1));
        //setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("OFRLogo2.png").getFile()));
        //Getting JTree model
        model=(DefaultTreeModel)InstanceDocTree.getModel();      
        //Getting JTree root node
        rootNode=(DefaultMutableTreeNode)model.getRoot();
        InstanceDocTree.setRootVisible(false);
        //Disabling some menus
        NewReport.setVisible(false);
        openMenuItem.setVisible(false);
        saveMenuItem.setVisible(false);                
        InsertMenu.setVisible(false);
        EditMenu.setVisible(false);
        RemoveMenu.setVisible(false);
        InstanceValidation.setVisible(false); 
        saveInstanceFileButton.setEnabled(false);
        LogTextArea.setLineWrap(true);
        LogTextArea.setWrapStyleWord(true);
        InconsistenciesLogTextArea.setLineWrap(true);
        InconsistenciesLogTextArea.setWrapStyleWord(true);
        LogTextArea.setEditable(false);
        InconsistenciesLogTextArea.setEditable(false);
        InstanceDocTree.setEditable(false);
        this.addWindowListener(new WindowListener() {
        @Override    
        public void windowOpened(WindowEvent e) {
        }
        @Override
        public void windowIconified(WindowEvent e) {
        }
        @Override
        public void windowDeiconified(WindowEvent e) {
        }
        @Override
        public void windowDeactivated(WindowEvent e) {
        }
        @Override
        public void windowClosing(WindowEvent e) {
            exitMenuItem.doClick();
        }
        @Override
        public void windowClosed(WindowEvent e) {
        }
        @Override
        public void windowActivated(WindowEvent e) {}});        
        
    }
    public void LoadAuxiliarFiles()throws IOException{
                // variable for storing the retrived codes
                String CodeLine;
                //initializing a Buffered Reader so its possible to use the method readLine() to get the codes from the text file and to compare them with the inted one                                
                InputStream reader = getClass().getResourceAsStream("SiconfiStatementId.txt");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    statementIdIndex.add(CodeLine);
                }                
                //closing the file reader
                reader.close(); 
                reader = getClass().getResourceAsStream("SiconfiDimension.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    contextMemberIndex.add(CodeLine);
                }
                //closing the file reader
                reader.close();
                reader = getClass().getResourceAsStream("SiconfiNonNumeric.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    nonNumericElementsComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close(); 
                reader = getClass().getResourceAsStream("SiconfiAxis.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                   contextAxis.add(CodeLine);
                }
                //closing the file reader
                reader.close();                 
                reader = getClass().getResourceAsStream("SiconfiSchema.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                   schemaRef.add(CodeLine);
                }
                //closing the file reader
                reader.close();
                reader = getClass().getResourceAsStream("attachmentList.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                   nonNumericElements.add(CodeLine);
                }
                //closing the file reader
                reader.close();
                reader = getClass().getResourceAsStream("entryPointsList.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                   entryPointsList.add(CodeLine);
                }
                //closing the file reader
                reader.close();
                reader = getClass().getResourceAsStream("schemaRefList.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                   schemaRefList.add(CodeLine);
                }
                //closing the file reader
                reader.close();                
    }
    
    //This method updates the tree viewer
    public void UpdateTree() {
        //This cleans all nodes from the Tree 
        rootNode.removeAllChildren();
        rootNode.setUserObject(rootNodeLabel);
        model.nodeChanged(rootNode);
        //This updates the Tree viewer
        model.reload();
        //Instance element's counter
        int i =0;
        //Adding all explanatory notes to the tree
        for(NonNumericDeclaration noteItem : instanceReport.noteList){
        //This creates a new node
        newElementnode=new DefaultMutableTreeNode(noteItem.getLabel());
        //This inserts the node in the root at position i 
        rootNode.insert(newElementnode,i);
        newContentnode=new DefaultMutableTreeNode(noteItem.getContextRef());
        newElementnode.insert(newContentnode,0);
        newContentnode=new DefaultMutableTreeNode(noteItem.getContent());
        newElementnode.insert(newContentnode,1);
        //This increments the element counter
        i++;
        }        
        // Adding all contexts to the tree
        for(ContextDeclaration context : instanceReport.contextList){
        //This creates a new node
        newElementnode=new DefaultMutableTreeNode(context.getId());
        //This inserts the node in the root at position i 
        rootNode.insert(newElementnode,i);
        newContentnode=new DefaultMutableTreeNode(context.getEntityScheme());
        newElementnode.insert(newContentnode,0); 
        newContentnode=new DefaultMutableTreeNode(context.getEntityIdentifier());
        newElementnode.insert(newContentnode,1); 
        newContentnode=new DefaultMutableTreeNode(context.getExplicitMemberDimension());
        newElementnode.insert(newContentnode,2);
        newContentnode=new DefaultMutableTreeNode(context.getSiconfiDimension());
        newElementnode.insert(newContentnode,3);
        if(context.getHasCoupledAxis()){
        newContentnode=new DefaultMutableTreeNode(context.getSecondaryExplicitMemberDimension());
        newElementnode.insert(newContentnode,4);
        newContentnode=new DefaultMutableTreeNode(context.getSecondarySiconfiDimension());
        newElementnode.insert(newContentnode,5);        
        newContentnode=new DefaultMutableTreeNode(context.getPeriodStartDate());
        newElementnode.insert(newContentnode,6);
        newContentnode=new DefaultMutableTreeNode(context.getPeriodEndDate());
        newElementnode.insert(newContentnode,7); 
        }else{
        newContentnode=new DefaultMutableTreeNode(context.getPeriodStartDate());
        newElementnode.insert(newContentnode,4);
        newContentnode=new DefaultMutableTreeNode(context.getPeriodEndDate());
        newElementnode.insert(newContentnode,5); 
        }
        //This increments the element counter
        i++;
        }
        // Adding all units to the tree
        for(UnitDeclaration unit : instanceReport.unitList){
        //This creates a new node
        newElementnode=new DefaultMutableTreeNode(unit.getId());
        //This inserts the node in the root at position i 
        rootNode.insert(newElementnode,i);
        newContentnode=new DefaultMutableTreeNode(unit.getISOIdentifier());
        newElementnode.insert(newContentnode,0);       
        //This increments the element counter
        i++;
        }
        // Adding all statements to the tree
        for(StatementDeclaration statement : instanceReport.statementList){
        //This creates a new node
        newElementnode=new DefaultMutableTreeNode(statement.getId());
        //This inserts the node in the root at position i 
        rootNode.insert(newElementnode,i);
        newContentnode=new DefaultMutableTreeNode(statement.getContextRef());
        newElementnode.insert(newContentnode,0); 
        newContentnode=new DefaultMutableTreeNode(statement.getDecimals());
        newElementnode.insert(newContentnode,1); 
        newContentnode=new DefaultMutableTreeNode(statement.getUnitRef());
        newElementnode.insert(newContentnode,2); 
        newContentnode=new DefaultMutableTreeNode(statement.getValue());
        newElementnode.insert(newContentnode,3);         
        //This increments the element counter
        i++;        
        }   
    }
    //this method organizes the elements of each object list that composes the report
    public void PresentationOrdering (InstanceReport unsortedInstanceReport){
        unsortedInstanceReport.sortContextList();
        unsortedInstanceReport.sortStatementList();
        unsortedInstanceReport.sortNoteList();
    }
    public int ContextIndexCalc(String Id){
    int index=0;
    for(int i=0;i<contextMemberIndex.size();i++){
        if(Id.equals(contextMemberIndex.elementAt(i))){
            index=i;
        }
    }
    return index;
    }
    public int StatementIndexCalc(String Id){
    int index=0;
    for(int i=0;i<statementIdIndex.size();i++){
        if(Id.equals(statementIdIndex.elementAt(i))){
            index=i;
        }
    }
    return index;
    }
    public boolean InconsistencyChecker(InstanceReport instanceReport)throws IOException{
        InputStream reader;
        BufferedReader bufferedReader;
        boolean contextFault = true;
        boolean unitFault = true;
        boolean nonNumericFault = true;
        boolean hyperCubeFault = true;
        boolean functionReturn = false;
        int axisSubstringIndex = 0,i;
        String listOfStatementsC="",listOfStatementsU="",listOfStatementsH="",listOfNonNumeric="",listOfStatementsD="",statementAxis,fileLine;
        InconsistenciesLogTextArea.setText("");
        if(!instanceReport.statementList.isEmpty()){
        for(StatementDeclaration statement:instanceReport.statementList){
            statementAxis="";
            for(ContextDeclaration context:instanceReport.contextList){
                if(statement.getContextRef().equals(context.getId())){
                    contextFault=false;
                    statementAxis=context.getExplicitMemberDimension();
                    axisSubstringIndex=context.getExplicitMemberDimension().length();
                    reader = getClass().getResourceAsStream("SiconfiSchema.txt");
                    bufferedReader = new BufferedReader(new InputStreamReader(reader));
                    while ((fileLine = bufferedReader.readLine()) != null) {
                        if(fileLine.equals(context.getEntityScheme())){
                            if(Integer.valueOf(statement.getDecimals())!=2){
                                listOfStatementsD=listOfStatementsD+statement.getId()+" "+statement.getContextRef()+"\n";
                            }                                                              
                        }
                    }
                    reader.close();
                }                
            }
            if(contextFault){
                listOfStatementsC=listOfStatementsC+statement.getId()+" "+statement.getContextRef()+"\n";
            }
            contextFault = true;
            for(UnitDeclaration unit:instanceReport.unitList){
                if(statement.getUnitRef().equals(unit.getId())){
                    unitFault=false;
                }
            }
            if(unitFault){
                listOfStatementsU=listOfStatementsU+statement.getId()+" "+statement.getContextRef()+"\n";
            }
            unitFault = true;
            if(!statementAxis.equals("")){
                statementAxis=statementAxis.substring(12,axisSubstringIndex-4);
                for (i=0;i<contextAxis.size();i++){
                    if(statementAxis.equals(contextAxis.elementAt(i))){
                       reader = getClass().getResourceAsStream("StatementAxis"+String.valueOf(i)+".txt");
                       bufferedReader = new BufferedReader(new InputStreamReader(reader));
                       while ((fileLine = bufferedReader.readLine()) != null) {
                           if(fileLine.equals(statement.getId())){
                               hyperCubeFault = false;                               
                           }
                       }
                       reader.close();
                    }
                }
                if(hyperCubeFault){
                    listOfStatementsH=listOfStatementsH+statement.getId()+" "+statement.getContextRef()+"\n";
                }
            }
            hyperCubeFault = true;            
        }
        }
        if(!instanceReport.noteList.isEmpty()){
        for(NonNumericDeclaration nonNumeric:instanceReport.noteList){
            for(ContextDeclaration context:instanceReport.contextList){
                if(nonNumeric.getContextRef().equals(context.getId())){
                    nonNumericFault=false;                                     
                }                
            }
            if(nonNumericFault){
                listOfNonNumeric=listOfNonNumeric+nonNumeric.getContextRef()+"\n";
            }
            nonNumericFault = true;            
        }
        }
        if(!listOfStatementsC.equals("")){
            InconsistenciesLogTextArea.setText(InconsistenciesLogTextArea.getText()+M_Fault00+"\n"+listOfStatementsC+"\n"+"\n");
            functionReturn = true;
        }else{
            InconsistenciesLogTextArea.setText(InconsistenciesLogTextArea.getText()+M_Suc11+"\n"+"\n");
        }
        if(!listOfStatementsU.equals("")){
            InconsistenciesLogTextArea.setText(InconsistenciesLogTextArea.getText()+M_Fault01+"\n"+listOfStatementsU+"\n"+"\n");
            functionReturn = true;
        }else{
            InconsistenciesLogTextArea.setText(InconsistenciesLogTextArea.getText()+M_Suc12+"\n"+"\n");
        }        
        if(!listOfStatementsH.equals("")){
            InconsistenciesLogTextArea.setText(InconsistenciesLogTextArea.getText()+M_Fault02+"\n"+listOfStatementsH+"\n"+"\n");
            functionReturn = true;
        }else{
            InconsistenciesLogTextArea.setText(InconsistenciesLogTextArea.getText()+M_Suc13+"\n"+"\n");
        }
        if(!listOfNonNumeric.equals("")){
            InconsistenciesLogTextArea.setText(InconsistenciesLogTextArea.getText()+M_Fault03+"\n"+listOfStatementsH+"\n"+"\n");
            functionReturn = true;
        }else{
            InconsistenciesLogTextArea.setText(InconsistenciesLogTextArea.getText()+M_Suc14+"\n"+"\n");
        }        
        if(!listOfStatementsD.equals("")){
            InconsistenciesLogTextArea.setText(InconsistenciesLogTextArea.getText()+M_Fault04+"\n"+listOfStatementsD+"\n"+"\n");
            functionReturn = true;
        }else{
            InconsistenciesLogTextArea.setText(InconsistenciesLogTextArea.getText()+M_Suc15+"\n"+"\n");
        } 
    return functionReturn;
    }
    public void AttachmentSetter (InstanceReport instanceReport,Vector<String> nonNumericElements)throws IOException{
        InputStream reader;
        BufferedReader bufferedReader;
        String CodeLine;               
        if(!instanceReport.noteList.isEmpty()){
            for(NonNumericDeclaration element: instanceReport.noteList){                
                for(ContextDeclaration context:instanceReport.contextList){
                    if(element.getContextRef().equals(context.getId())){                        
                       for(int l=0;l<nonNumericElements.size();l++){                           
                           reader = getClass().getResourceAsStream("attachmentMemberList"+String.valueOf(l)+".txt");
                           bufferedReader = new BufferedReader(new InputStreamReader(reader));
                           while ((CodeLine = bufferedReader.readLine()) != null) {
                               if(context.getSiconfiDimension().substring(12,context.getSiconfiDimension().length()-6).equals(CodeLine)){
                                  element.setAttachment(nonNumericElements.elementAt(l));
                                  element.setIndex(l);
                               }
                           }
                           reader.close();
                       }
                    }
                }    
            }
        }
    }
    
    public void InstanceValidation (InstanceReport instanceReport){        
        String statementValueSubstring,contextRef1="",contextRef2="",contextRef3="";
        long PrevisaoAtualizada=0-1,ReceitasRealizadasAteOBimestre=0-1,SaldoReceita=0-1;
        if(!instanceReport.contextList.isEmpty()&&!instanceReport.statementList.isEmpty()){
            for(StatementDeclaration statement : instanceReport.statementList){
                if(statement.getId().equals("ReceitasExcetoIntraOrcamentarias")){
                    for(ContextDeclaration context : instanceReport.contextList){
                        if(statement.getContextRef().equals(context.getId())){
                            statementValueSubstring=statement.getValue().substring(0, statement.getValue().length()-3)+statement.getValue().substring(statement.getValue().length()-2); 
                            if(context.getSiconfiDimension().substring(12,context.getSiconfiDimension().length()-6).equals("PrevisaoAtualizada")){                                
                                PrevisaoAtualizada=Long.valueOf(statementValueSubstring);
                                contextRef1=statement.getContextRef();
                            }  
                            if(context.getSiconfiDimension().substring(12,context.getSiconfiDimension().length()-6).equals("ReceitasRealizadasAteOBimestre")){
                                ReceitasRealizadasAteOBimestre=Long.valueOf(statementValueSubstring);
                                contextRef2=statement.getContextRef();
                            }
                            if(context.getSiconfiDimension().substring(12,context.getSiconfiDimension().length()-6).equals("SaldoReceita")){
                                SaldoReceita=Long.valueOf(statementValueSubstring);
                                contextRef3=statement.getContextRef();
                            }
                        }
                    }
                }
            }
            if(((SaldoReceita<0)||(ReceitasRealizadasAteOBimestre<0))||(PrevisaoAtualizada<0)){
                JOptionPane.showMessageDialog(desktopPane,M_Error32,jopTitle,JOptionPane.ERROR_MESSAGE);
                LogTextArea.setText(LogTextArea.getText()+"\n"+M_Error32);                
            }else{
                if(SaldoReceita==PrevisaoAtualizada-ReceitasRealizadasAteOBimestre){
                    JOptionPane.showMessageDialog(desktopPane,M_Suc07,jopTitle,JOptionPane.PLAIN_MESSAGE);
                    LogTextArea.setText(LogTextArea.getText()+"\n"+M_Suc07);
                }else{
                    JOptionPane.showMessageDialog(desktopPane,M_Error26+"\n"+contextRef1+"\n"+contextRef2+"\n"+contextRef3+"\n",jopTitle,JOptionPane.ERROR_MESSAGE);
                    LogTextArea.setText(LogTextArea.getText()+"\n"+M_Error26+"\n"+contextRef1+"\n"+contextRef2+"\n"+contextRef3+"\n");
                }
            } 
        }else{
            JOptionPane.showMessageDialog(desktopPane,M_Error32,jopTitle,JOptionPane.ERROR_MESSAGE);
            LogTextArea.setText(LogTextArea.getText()+"\n"+M_Error32);
        }
    }
    public void SummonAddElement(int x){
        for(JInternalFrame internalFrm:desktopPane.getAllFrames()){
            internalFrm.setVisible(false);
        } 
        
        //This if clause prevents the creation of multiple windows of the same kind
        if (addElement == null || addElement.isClosed()){
        try{addElement = new AddElement();}catch (Exception e){}
        addElement.addInternalFrameListener(this);
        desktopPane.add(addElement);
        addElement.setVisible(true);
        }else{
        addElement.CheckBoxReset();
        addElement.setVisible(true);
        }
        //passing the instance report object to the invoked frame, so it can edit the report        
        addElement.updateReport(instanceReport);
        //passing the language reference that the invoked frame shall display
        addElement.LanguageSelection(ChoosenLanguage);
        addElement.Logloader(LogTextArea);
        addElement.InsertOptionUpdate(x);
        
    }
    public void SummonEditElement (int x){
for(JInternalFrame internalFrm:desktopPane.getAllFrames()){
            internalFrm.setVisible(false);
        }         
        //This if clause prevents the creation of multiple windows of the same kind
        if (editElement == null || editElement.isClosed()){
        try{editElement = new EditElement();}catch (Exception e){}
        editElement.addInternalFrameListener(this);
        desktopPane.add(editElement);
        editElement.setVisible(true);
        }else{
        editElement.CheckBoxReset();            
        editElement.setVisible(true);
        }
        //passing the instance report object to the invoked frame, so it can edit the report
        editElement.updateReport(instanceReport);
        //passing the language reference that the invoked frame shall display
        editElement.LanguageSelection(ChoosenLanguage);
        editElement.Logloader(LogTextArea); 
        editElement.InsertOptionUpdate(x);        
    }
    public void SummonDeleteElement(int x){
        for(JInternalFrame internalFrm:desktopPane.getAllFrames()){
            internalFrm.setVisible(false);
        }         
        //This if clause prevents the creation of multiple windows of the same kind
        if (deleteElement == null || deleteElement.isClosed()){
        deleteElement = new DeleteElement();
        deleteElement.addInternalFrameListener(this);
        desktopPane.add(deleteElement);
        deleteElement.setVisible(true);
        }else{
        deleteElement.CheckBoxReset();            
        deleteElement.setVisible(true);
        }
        //passing the instance report object to the invoked frame, so it can edit the report
        deleteElement.updateReport(instanceReport);
        //passing the language reference that the invoked frame shall display
        deleteElement.LanguageSelection(ChoosenLanguage);
        deleteElement.Logloader(LogTextArea);
        deleteElement.InsertOptionUpdate(x);        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        desktopPane = new javax.swing.JDesktopPane();
        TreejScrollPane = new javax.swing.JScrollPane();
        InstanceDocTree = new javax.swing.JTree();
        LogjScrollPane = new javax.swing.JScrollPane();
        LogTextArea = new javax.swing.JTextArea();
        LogoButtonScrollPane = new javax.swing.JScrollPane();
        LogoButton = new javax.swing.JButton();
        saveInstanceFileButton = new javax.swing.JButton();
        InconsistenciesLogjScrollPane = new javax.swing.JScrollPane();
        InconsistenciesLogTextArea = new javax.swing.JTextArea();
        closeButton = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        NewReport = new javax.swing.JMenuItem();
        openMenuItem = new javax.swing.JMenuItem();
        saveMenuItem = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();
        Taxonomy = new javax.swing.JMenu();
        LoadTaxonomySet = new javax.swing.JMenuItem();
        AvailableReportModels = new javax.swing.JMenu();
        ReportModel0 = new javax.swing.JMenuItem();
        ReportModel1 = new javax.swing.JMenuItem();
        InsertMenu = new javax.swing.JMenu();
        InsertContextMenuItem = new javax.swing.JMenuItem();
        InsertUnitMenuItem = new javax.swing.JMenuItem();
        InsertAccountMenuItem = new javax.swing.JMenuItem();
        InsertNonNumericMenuItem = new javax.swing.JMenuItem();
        EditMenu = new javax.swing.JMenu();
        EditContextMenuItem = new javax.swing.JMenuItem();
        EditUnitMenuItem = new javax.swing.JMenuItem();
        EditAccountMenuItem = new javax.swing.JMenuItem();
        EditNonNumericMenuItem = new javax.swing.JMenuItem();
        RemoveMenu = new javax.swing.JMenu();
        RemoveContextMenuItem = new javax.swing.JMenuItem();
        RemoveUnitMenuItem = new javax.swing.JMenuItem();
        RemoveAccountMenuItem = new javax.swing.JMenuItem();
        RemoveNonNumericMenuItem = new javax.swing.JMenuItem();
        InstanceValidation = new javax.swing.JMenu();
        FormulaValidation = new javax.swing.JMenuItem();
        LanguageSelectionMenu = new javax.swing.JMenu();
        EnglishMenuItem = new javax.swing.JMenuItem();
        EspanolMenuItem = new javax.swing.JMenuItem();
        PortuguesMenuItem = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        HelpTipsMenuItem = new javax.swing.JMenuItem();
        aboutMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Open Financial Reporting");

        javax.swing.tree.DefaultMutableTreeNode treeNode1 = new javax.swing.tree.DefaultMutableTreeNode("Report");
        InstanceDocTree.setModel(new javax.swing.tree.DefaultTreeModel(treeNode1));
        InstanceDocTree.setEditable(true);
        TreejScrollPane.setViewportView(InstanceDocTree);

        desktopPane.add(TreejScrollPane);
        TreejScrollPane.setBounds(0, 0, 540, 700);

        LogTextArea.setColumns(20);
        LogTextArea.setRows(5);
        LogjScrollPane.setViewportView(LogTextArea);

        desktopPane.add(LogjScrollPane);
        LogjScrollPane.setBounds(540, 30, 260, 260);

        LogoButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ofr/XBRL-Logo-2c-NoStrap-620x465web.png"))); // NOI18N
        LogoButton.setPreferredSize(new java.awt.Dimension(250, 130));
        LogoButtonScrollPane.setViewportView(LogoButton);

        desktopPane.add(LogoButtonScrollPane);
        LogoButtonScrollPane.setBounds(540, 560, 260, 140);

        saveInstanceFileButton.setText("Save Report");
        saveInstanceFileButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveInstanceFileButtonActionPerformed(evt);
            }
        });
        desktopPane.add(saveInstanceFileButton);
        saveInstanceFileButton.setBounds(540, 0, 130, 30);

        InconsistenciesLogTextArea.setColumns(20);
        InconsistenciesLogTextArea.setRows(5);
        InconsistenciesLogjScrollPane.setViewportView(InconsistenciesLogTextArea);

        desktopPane.add(InconsistenciesLogjScrollPane);
        InconsistenciesLogjScrollPane.setBounds(540, 290, 260, 270);

        closeButton.setText("Exit");
        closeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeButtonActionPerformed(evt);
            }
        });
        desktopPane.add(closeButton);
        closeButton.setBounds(670, 0, 130, 30);

        fileMenu.setMnemonic('f');
        fileMenu.setText("File");

        NewReport.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        NewReport.setText("New Report");
        NewReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NewReportActionPerformed(evt);
            }
        });
        fileMenu.add(NewReport);

        openMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        openMenuItem.setMnemonic('o');
        openMenuItem.setText("Open");
        openMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(openMenuItem);

        saveMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        saveMenuItem.setMnemonic('s');
        saveMenuItem.setText("Save");
        saveMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(saveMenuItem);

        exitMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        Taxonomy.setText("Taxonomy");

        LoadTaxonomySet.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.ALT_MASK));
        LoadTaxonomySet.setText("Load Taxonomy Set");
        LoadTaxonomySet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoadTaxonomySetActionPerformed(evt);
            }
        });
        Taxonomy.add(LoadTaxonomySet);

        menuBar.add(Taxonomy);

        AvailableReportModels.setText("Report Models");

        ReportModel0.setText("siconfi-rreo-consorciospublicos_2019-12-31");
        ReportModel0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReportModel0ActionPerformed(evt);
            }
        });
        AvailableReportModels.add(ReportModel0);

        ReportModel1.setText("siconfi-rreo-municipiossemestral_2019-12-31");
        ReportModel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReportModel1ActionPerformed(evt);
            }
        });
        AvailableReportModels.add(ReportModel1);

        menuBar.add(AvailableReportModels);

        InsertMenu.setText("Insert");

        InsertContextMenuItem.setText("Insert Context");
        InsertContextMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertContextMenuItemActionPerformed(evt);
            }
        });
        InsertMenu.add(InsertContextMenuItem);

        InsertUnitMenuItem.setText("Insert Unit");
        InsertUnitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertUnitMenuItemActionPerformed(evt);
            }
        });
        InsertMenu.add(InsertUnitMenuItem);

        InsertAccountMenuItem.setText("Insert Account");
        InsertAccountMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertAccountMenuItemActionPerformed(evt);
            }
        });
        InsertMenu.add(InsertAccountMenuItem);

        InsertNonNumericMenuItem.setText("Insert Non Numeric element");
        InsertNonNumericMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertNonNumericMenuItemActionPerformed(evt);
            }
        });
        InsertMenu.add(InsertNonNumericMenuItem);

        menuBar.add(InsertMenu);

        EditMenu.setText("Edit");

        EditContextMenuItem.setText("Edit Context");
        EditContextMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditContextMenuItemActionPerformed(evt);
            }
        });
        EditMenu.add(EditContextMenuItem);

        EditUnitMenuItem.setText("Edit Unit");
        EditUnitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditUnitMenuItemActionPerformed(evt);
            }
        });
        EditMenu.add(EditUnitMenuItem);

        EditAccountMenuItem.setText("Edit Account");
        EditAccountMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditAccountMenuItemActionPerformed(evt);
            }
        });
        EditMenu.add(EditAccountMenuItem);

        EditNonNumericMenuItem.setText("Edit Non Numeric element");
        EditNonNumericMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditNonNumericMenuItemActionPerformed(evt);
            }
        });
        EditMenu.add(EditNonNumericMenuItem);

        menuBar.add(EditMenu);

        RemoveMenu.setText("Remove");
        RemoveMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveMenuActionPerformed(evt);
            }
        });

        RemoveContextMenuItem.setText("Remove Context");
        RemoveContextMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveContextMenuItemActionPerformed(evt);
            }
        });
        RemoveMenu.add(RemoveContextMenuItem);

        RemoveUnitMenuItem.setText("Remove Unit");
        RemoveUnitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveUnitMenuItemActionPerformed(evt);
            }
        });
        RemoveMenu.add(RemoveUnitMenuItem);

        RemoveAccountMenuItem.setText("Remove Account");
        RemoveAccountMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveAccountMenuItemActionPerformed(evt);
            }
        });
        RemoveMenu.add(RemoveAccountMenuItem);

        RemoveNonNumericMenuItem.setText("Remove Non Numeric element");
        RemoveNonNumericMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RemoveNonNumericMenuItemActionPerformed(evt);
            }
        });
        RemoveMenu.add(RemoveNonNumericMenuItem);

        menuBar.add(RemoveMenu);

        InstanceValidation.setText("Instance Validation");

        FormulaValidation.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.ALT_MASK));
        FormulaValidation.setText("Formula Validation");
        FormulaValidation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FormulaValidationActionPerformed(evt);
            }
        });
        InstanceValidation.add(FormulaValidation);

        menuBar.add(InstanceValidation);

        LanguageSelectionMenu.setText("Language");

        EnglishMenuItem.setText("English");
        EnglishMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnglishMenuItemActionPerformed(evt);
            }
        });
        LanguageSelectionMenu.add(EnglishMenuItem);

        EspanolMenuItem.setText("Español");
        EspanolMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EspanolMenuItemActionPerformed(evt);
            }
        });
        LanguageSelectionMenu.add(EspanolMenuItem);

        PortuguesMenuItem.setText("Português");
        PortuguesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PortuguesMenuItemActionPerformed(evt);
            }
        });
        LanguageSelectionMenu.add(PortuguesMenuItem);

        menuBar.add(LanguageSelectionMenu);

        helpMenu.setMnemonic('h');
        helpMenu.setText("Help");

        HelpTipsMenuItem.setText("Help Tips");
        HelpTipsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HelpTipsMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(HelpTipsMenuItem);

        aboutMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_H, java.awt.event.InputEvent.CTRL_MASK));
        aboutMenuItem.setMnemonic('a');
        aboutMenuItem.setText("About");
        aboutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 710, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
            if(saveMenuItem.isVisible()){
                int userResponse = JOptionPane.showOptionDialog(desktopPane,M_Conf00,jopTitle,JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
                if(userResponse==JOptionPane.YES_OPTION){
                    saveMenuItem.doClick();
                }                
            }
            System.exit(0);
            
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void saveMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveMenuItemActionPerformed
        // TODO add your handling code here:        
        //This closes all open internal windows by disposing them
        for(JInternalFrame internalFrm:desktopPane.getAllFrames()){
            internalFrm.dispose();
        }
        try{
            //initializing th java file chooser
            saveJfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());            
            saveJfc.setDialogTitle(saveJfcTitle);
            //defining file extensions filters
            saveJfc.setAcceptAllFileFilterUsed(false);            
            FileNameExtensionFilter filter = new FileNameExtensionFilter("XML", "xml");
            saveJfc.addChoosableFileFilter(filter);
            //showing the save dialog box
            int returnValue = saveJfc.showSaveDialog(desktopPane);
            // reading the option button and getting the user input
            if (returnValue == JFileChooser.APPROVE_OPTION) {                
                File selectedFile = saveJfc.getSelectedFile();
                fileName=selectedFile.getAbsoluteFile()+"";
                if(!fileName.substring(fileName.length()-4).equals(".xml")){
                    fileName=fileName+".xml";
                }
             }
            //this converts the instance objtec lists into an XBRL instance file regarding the chosen name and path 
            try{AttachmentSetter(instanceReport,nonNumericElements);}catch (IOException e){}
            ReportComposer.writeFileUsingJDOM(instanceReport.statementList,instanceReport.contextList,instanceReport.unitList,instanceReport.noteList,fileName,reportOption);
            //updating the message log
            LogTextArea.setText(LogTextArea.getText()+"\n"+M_Suc10);
            }catch(Exception e) {
               //Console debug message for error generating the XBRL instance file
            System.out.println("Something went wrong.");
            }
    }//GEN-LAST:event_saveMenuItemActionPerformed

    private void NewReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NewReportActionPerformed
        // TODO add your handling code here:
        for(JInternalFrame internalFrm:desktopPane.getAllFrames()){
            internalFrm.dispose();
        }        
        //creating a list of financial statements that will compose the XBRL instance document
        statementList = new ArrayList<>();
        //creating a list of the contexts that the financial statements refer to
        contextList = new ArrayList<>();
        //creating a list of units to express the financial statements
        unitList = new ArrayList<>();
        //creating a list of footnotes regarding the financial statements
        noteList = new ArrayList<>();     
        //creating a new instanceReport object with the previously created lists
        instanceReport = new InstanceReport(statementList,contextList,unitList,noteList);
        InstanceDocTree.setRootVisible(true);
        //enabling options through the menus
        saveMenuItem.setVisible(true);
        InsertMenu.setVisible(true);
        EditMenu.setVisible(true);
        RemoveMenu.setVisible(true);        
        InstanceValidation.setVisible(true);
        saveInstanceFileButton.setEnabled(true);
        //cleaning the message log
        LogTextArea.setText("");
        //updating the tree
        UpdateTree();
    }//GEN-LAST:event_NewReportActionPerformed

    private void FormulaValidationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FormulaValidationActionPerformed
        // TODO add your handling code here:
        for(JInternalFrame internalFrm:desktopPane.getAllFrames()){
            internalFrm.dispose();
        }
        try{
        if(InconsistencyChecker(instanceReport)){
            JOptionPane.showMessageDialog(desktopPane,M_Error30,jopTitle,JOptionPane.WARNING_MESSAGE);
        }else{
            InstanceValidation(instanceReport);
        }
        }catch (IOException e){}
    }//GEN-LAST:event_FormulaValidationActionPerformed

    private void EnglishMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnglishMenuItemActionPerformed
        for(JInternalFrame internalFrm:desktopPane.getAllFrames()){
            internalFrm.setVisible(false);
        }         
        // TODO add your handling code here:
        fileMenu.setText("File");
        NewReport.setText("New Report");
        openMenuItem.setText("Open");
        saveMenuItem.setText("Save");
        exitMenuItem.setText("Exit");
        Taxonomy.setText("Taxonomy");
        LoadTaxonomySet.setText("Load Taxonomy Set");
        AvailableReportModels.setText("Report Models");
        InsertContextMenuItem.setText("Insert Context");
        InsertUnitMenuItem.setText("Insert Unit");
        InsertAccountMenuItem.setText("Insert Account");
        InsertNonNumericMenuItem.setText("Insert Non numeric element");
        EditContextMenuItem.setText("Edit Context");
        EditUnitMenuItem.setText("Edit Unit");
        EditAccountMenuItem.setText("Edit Account");
        EditNonNumericMenuItem.setText("Edit Non numeric element");
        RemoveContextMenuItem.setText("Remove Context");
        RemoveUnitMenuItem.setText("Remove Unit");
        RemoveAccountMenuItem.setText("Remove Account");
        RemoveNonNumericMenuItem.setText("Remove Non Numeric element");
        InsertMenu.setText("Insert");
        EditMenu.setText("Edit");
        RemoveMenu.setText("Remove");
        InstanceValidation.setText("Instance Validation");
        FormulaValidation.setText("Formula Validation");
        LanguageSelectionMenu.setText("Language");
        helpMenu.setText("Help");
        aboutMenuItem.setText("About");
        saveInstanceFileButton.setText("Save report");
        M_Error26="The instance document could not be validated."+"\n"+"There might be wrong values registered in the following accounts:"+"\n"+"ReceitasExcetoIntraOrcamentarias"+"\n"+"related to the following contexts:";
        M_Error32="The instance document could not be validated."+"\n"+" There might be some missing elements for validating the report.";
        M_Suc07="Instance file successfully validated.";
        M_Suc09="Instance document successfully loaded.";
        M_Suc10="Instance file successfully generated.";
        ChoosenLanguage="EN";
        saveJfcTitle="Save";
        openJfcTitle="Open";
        UIManager.put("FileChooser.lookInLabelText","Look In:");
        UIManager.put("FileChooser.fileNameLabelText","File Name:");
        UIManager.put("FileChooser.filesOfTypeLabelText","Files of Type:");
        UIManager.put("FileChooser.upFolderToolTipText","Up One Level");
        UIManager.put("FileChooser.upFolderAccessibleName","Up");
        UIManager.put("FileChooser.homeFolderToolTipText","Home");
        UIManager.put("FileChooser.homeFolderAccessibleName","Home");
        UIManager.put("FileChooser.newFolderToolTipText","Create New Folder");
        UIManager.put("FileChooser.newFolderAccessibleName","New Folder");
        UIManager.put("FileChooser.listViewButtonToolTipText","List");
        UIManager.put("FileChooser.listViewButtonAccessibleName","List");
        UIManager.put("FileChooser.detailsViewButtonToolTipText","Details");
        UIManager.put("FileChooser.detailsViewButtonAccessibleName","Details");
        UIManager.put("FileChooser.cancelButtonText","Cancel");
        UIManager.put("FileChooser.cancelButtonToolTipText","Abort file chooser dialog");
        UIManager.put("FileChooser.openButtonText","Open");
        UIManager.put("FileChooser.openButtonToolTipText","Open selected file");
        UIManager.put("FileChooser.saveButtonText","Save");
        UIManager.put("FileChooser.saveButtonToolTipText","Save selected file");
        UIManager.put("FileChooser.acceptAllFileFilterText","All Files");
        UIManager.put("FileChooser.homeFolderToolTipText","Home");
        UIManager.put("FileChooser.newFolderAccessibleName","New Folder");
        UIManager.put("FileChooser.viewMenuLabelText","View");
        UIManager.put("FileChooser.refreshActionLabelText","Refresh");
        UIManager.put("FileChooser.newFolderActionLabelText","New Folder");
        UIManager.put("FileChooser.listViewActionLabelText","List");
        UIManager.put("FileChooser.detailsViewActionLabelText","Details");
        rootNodeLabel="Report";
        M_Conf00="Do you wish to save the current report before quitting?";
        M_Error27="The file load process failed. Try it again, please";
        M_Conf01="Do you wish to save the current report before loading the new report model?";
        M_Suc14="There are no problems regarding the non-numeric elements.";
        M_Suc13="There are no problems regarding the accounts' axis declaration.";
        M_Suc12="There are no problems regarding the accounts' unit declaration.";
        M_Suc11="There are no problems regarding the accounts' context declaration.";
        M_Fault00="The following accounts are missing a valid context declaration:";
        M_Fault01="The following accounts are missing a valid unit declaration:";
        M_Fault02="The following accounts are missing a valid axis declaration:";
        M_Fault03="Non-numeric elements regarding the context list below need valid context references:";
        M_Fault04="Siconfi's reports use only two decimals to express account values. Please check such inconsistencies regarding the following accounts:";
        M_Suc15="There are no problems regarding the accounts' precision.";
        M_Suc16="Report model successfully loaded.";
        M_Error30="Please, remove the report's inconsistencies before trying to validate it.";
        jopTitle="MESSAGE";
        options[0] = "Yes";
        options[1] = "No";
        WIP = "This source will be available in another OFR's version...";
        M_Help="OFR prototype V1. "+"\n"+"Thanks for using the Open Financial Reporting software!"+"\n"+"If you got any trouble, access the link to the software's documentation:"+"\n"+"";
        closeButton.setText("Exit");
        M_Tip00 = "First, go to the Report Models menu and choose one among the available options.";
        M_Tip01 = "To crate a new report, go to the File menu and choose the option New Report.";
        M_Tip02 = "Your report is empty! Go to the Insert menu, choose the option Insert Context, and insert your data through the opened window.";
        M_Tip03 = "Try inserting a new context! Go to the Insert menu, choose the option Insert Context, and insert your data through the opened window.";
        M_Tip04 = "Try inserting a new Unit! Go to the Insert menu, choose the option Insert Unit, and insert your data through the opened window.";
        M_Tip05 = "Try inserting a new Account! Go to the Insert menu, choose the option Insert Account, and insert your data through the opened window.";
        M_Tip06 = "Try inserting a new Non Numeric element!"+"\n"+" Go to the Insert menu, choose the option Insert Non Numeric element, and insert your data through the opened window.";
        M_Tip07 = "You can edit elements through the options under the Edit menu whenever the report validation is unsuccessful."+"\n"+"You can also deal with inconsistent elements in that way."+"\n"+"You can also delete elements through the options under the Remove menu.";
        M_Tip08 = "In the Element Edition Manager window, use the blue boxes to choose the element you want to edit."+"\n"+"Then the OFR will fill up the remaining boxes with the information of that element for you to edit.";
        M_Tip09 = "In the Element Exclusion Manager window, use the boxes to choose the element you want to remove.";
        HelpTipsMenuItem.setText("Help Tips");
        if(saveMenuItem.isVisible()){UpdateTree();}
    }//GEN-LAST:event_EnglishMenuItemActionPerformed

    private void EspanolMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EspanolMenuItemActionPerformed
        for(JInternalFrame internalFrm:desktopPane.getAllFrames()){
            internalFrm.setVisible(false);
        }         
        // TODO add your handling code here:
        fileMenu.setText("Archivo");
        NewReport.setText("Nuevo reporte");
        openMenuItem.setText("Abrir");
        saveMenuItem.setText("Salvar");
        exitMenuItem.setText("Salir");
        Taxonomy.setText("Taxonomía");
        LoadTaxonomySet.setText("Cargar conjunto de taxonomía");
        AvailableReportModels.setText("Modelos de Informe");
        InsertContextMenuItem.setText("Insertar Contexto");
        InsertUnitMenuItem.setText("Insertar Unidad");
        InsertAccountMenuItem.setText("Insertar Cuenta");
        InsertNonNumericMenuItem.setText("Insertar elemento No Numérico");
        EditContextMenuItem.setText("Editar Contexto");
        EditUnitMenuItem.setText("Editar Unidad");
        EditAccountMenuItem.setText("Editar Cuenta");
        EditNonNumericMenuItem.setText("Editar No numérico");
        RemoveContextMenuItem.setText("Eliminar Contexto");
        RemoveUnitMenuItem.setText("Eliminar Unidad");
        RemoveAccountMenuItem.setText("Eliminar Cuenta");
        RemoveNonNumericMenuItem.setText("Eliminar elemento No Numérico");
        InsertMenu.setText("Insertar");
        EditMenu.setText("Editar");
        RemoveMenu.setText("Eliminar");        
        InstanceValidation.setText("Validación de instancias");
        FormulaValidation.setText("Validación de fórmulas");
        LanguageSelectionMenu.setText("Idioma");
        helpMenu.setText("Ayuda");
        aboutMenuItem.setText("Acerca");
        saveInstanceFileButton.setText("Salvar reporte");
        closeButton.setText("Salir");
        M_Error26="El documento de instancia no se pudo validar."+"\n"+"Puede haber valores incorrectos registrados en las siguientes cuentas:"+"\n"+"ReceitasExcetoIntraOrcamentarias"+"\n"+"relacionadas con los siguientes contextos:";
        M_Error32="El documento de instancia no se pudo validar."+"\n"+"Puede que falten algunos elementos para validar el informe.";
        M_Suc07="Archivo de instancia validado correctamente.";
        M_Suc09="El documento de instancia se cargó correctamente.";
        M_Suc10="Archivo de instancia generado correctamente.";        
        ChoosenLanguage="EP";
        saveJfcTitle="Salvar";
        openJfcTitle="Abrir";
        UIManager.put("FileChooser.lookInLabelText","Buscar en:");
        UIManager.put("FileChooser.fileNameLabelText","Nombre del archivo:");
        UIManager.put("FileChooser.filesOfTypeLabelText","Los archivos de tipo:");
        UIManager.put("FileChooser.upFolderToolTipText","Un nivel arriba");
        UIManager.put("FileChooser.upFolderAccessibleName","Arriba");
        UIManager.put("FileChooser.homeFolderToolTipText","Comienzo");
        UIManager.put("FileChooser.homeFolderAccessibleName","Comienzo");
        UIManager.put("FileChooser.newFolderToolTipText","Crear nueva carpeta");
        UIManager.put("FileChooser.newFolderAccessibleName","Nueva carpeta");
        UIManager.put("FileChooser.listViewButtonToolTipText","Lista");
        UIManager.put("FileChooser.listViewButtonAccessibleName","Lista");
        UIManager.put("FileChooser.detailsViewButtonToolTipText","Detalles");
        UIManager.put("FileChooser.detailsViewButtonAccessibleName","Detalles");
        UIManager.put("FileChooser.cancelButtonText","Cancelar");
        UIManager.put("FileChooser.cancelButtonToolTipText","Abortar el diálogo del selector de archivos");
        UIManager.put("FileChooser.openButtonText","Abierto");
        UIManager.put("FileChooser.openButtonToolTipText","Abrir archivo seleccionado");
        UIManager.put("FileChooser.saveButtonText","Salvar");
        UIManager.put("FileChooser.saveButtonToolTipText","Salvar archivo seleccionado");
        UIManager.put("FileChooser.acceptAllFileFilterText","Todos los archivos");
        UIManager.put("FileChooser.homeFolderToolTipText","Comienzo");
        UIManager.put("FileChooser.newFolderAccessibleName","Nueva carpeta");
        UIManager.put("FileChooser.viewMenuLabelText","Ver");
        UIManager.put("FileChooser.refreshActionLabelText","Actualizar");
        UIManager.put("FileChooser.newFolderActionLabelText","Nueva carpeta");
        UIManager.put("FileChooser.listViewActionLabelText","Lista");
        UIManager.put("FileChooser.detailsViewActionLabelText","Detalles");
        rootNodeLabel="Informe";
        M_Conf00="¿Desea guardar el informe actual antes de salir?";
        M_Error27="El proceso de carga del archivo falló. Inténtelo de nuevo, por favor.";
        M_Conf01="¿Desea guardar el informe actual antes de cargar el nuevo modelo de informe?";
        M_Suc16="Modelo de informe cargado correctamente.";
        M_Suc14="No hay problemas con los elementos no numéricos.";
        M_Suc13="No hay problemas con la declaración del eje de cuentas.";
        M_Suc12="No hay problemas con la declaración de unidades de las cuentas.";
        M_Suc11="No hay problemas con la declaración de contexto de las cuentas.";
        M_Fault00="A las siguientes cuentas les falta una declaración de contexto válida:";
        M_Fault01="A las siguientes cuentas les falta una declaración de unidad válida:";
        M_Fault02="A las siguientes cuentas les falta una declaración de eje válida:";
        M_Fault03="Los elementos no numéricos con respecto a la lista de contexto a continuación necesitan referencias de contexto válidas:";        
        M_Fault04="Los informes de Siconfi usan solo dos decimales para expresar los valores de las cuentas. Verifique dichas inconsistencias con respecto a las siguientes cuentas:";
        M_Suc15="No hay problemas con la precisión de las cuentas.";
        M_Error30="Elimine las inconsistencias del informe antes de intentar validarlo.";
        WIP = "esta fuente estará disponible en otra versión de OFR...";
        //JOptionPane
        jopTitle="MENSAJE";
        options[0] = "Sí";
        options[1] = "No"; 
        M_Help="Prototipo OFR V1."+"\n"+"¡Gracias por utilizar el software Open Financial Reporting!"+"\n"+"Si tiene algún problema, acceda al enlace a la documentación del software:"+"\n"+"";
        M_Tip00 = "Primero, vaya al menú Modelos de informes y elija una de las opciones disponibles.";
        M_Tip01 = "Para crear un nuevo informe, vaya al menú Archivo y elija la opción Nuevo informe.";
        M_Tip02 = "¡Tu informe está vacío! Vaya al menú Insertar, elija la opción Insertar contexto e inserte sus datos a través de la ventana abierta.";
        M_Tip03 = "¡Intente insertar un nuevo contexto! Vaya al menú Insertar, elija la opción Insertar contexto e inserte sus datos a través de la ventana abierta.";
        M_Tip04 = "¡Intente insertar una nueva unidad! Vaya al menú Insertar, elija la opción Insertar unidad e inserte sus datos a través de la ventana abierta.";
        M_Tip05 = "¡Intente insertar una nueva cuenta! Vaya al menú Insertar, elija la opción Insertar cuenta e inserte sus datos a través de la ventana abierta.";
        M_Tip06 = "¡Intente insertar un nuevo elemento no numérico!"+"\n"+"Vaya al menú Insertar, elija la opción Insertar elemento no numérico e inserte sus datos a través de la ventana abierta.";
        M_Tip07 = "Puede editar elementos a través de las opciones del menú Editar siempre que la validación del informe no sea satisfactoria."+"\n"+"También puede lidiar con elementos inconsistentes de esa manera."+"\n"+"También puede eliminar elementos a través de las opciones del menú Eliminar.";
        M_Tip08 = "En la ventana Administrador de edición de elementos, use los cuadros azules para elegir el elemento que desea editar."+"\n"+"Luego, el OFR llenará los cuadros restantes con la información de ese elemento para que usted la edite.";
        M_Tip09 = "En la ventana del Administrador de exclusión de elementos, utilice los cuadros para elegir el elemento que desea eliminar.";        
        HelpTipsMenuItem.setText("Tips de ayuda");        
        if(saveMenuItem.isVisible()){UpdateTree();}        
    }//GEN-LAST:event_EspanolMenuItemActionPerformed

    private void PortuguesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PortuguesMenuItemActionPerformed
        for(JInternalFrame internalFrm:desktopPane.getAllFrames()){
            internalFrm.setVisible(false);
        }         
        // TODO add your handling code here:
        fileMenu.setText("Arquivo");
        NewReport.setText("Novo relatório");
        openMenuItem.setText("Abrir");
        saveMenuItem.setText("Salvar");
        exitMenuItem.setText("Sair");
        Taxonomy.setText("Taxonomia");
        LoadTaxonomySet.setText("Carregar arquivos de taxonomia");
        AvailableReportModels.setText("Modelos de Relatório");
        InsertContextMenuItem.setText("Inserir Contexto");
        InsertUnitMenuItem.setText("Inserir Unidade");
        InsertAccountMenuItem.setText("Inserir Conta");
        InsertNonNumericMenuItem.setText("Inserir elemento Não numérico");
        EditContextMenuItem.setText("Editar Contexto");
        EditUnitMenuItem.setText("Editar Unidade");
        EditAccountMenuItem.setText("Editar Conta");
        EditNonNumericMenuItem.setText("Editar elemento Não Numérico");
        RemoveContextMenuItem.setText("Remover Contexto");
        RemoveUnitMenuItem.setText("Remover Unidade");
        RemoveAccountMenuItem.setText("Remover Conta");
        RemoveNonNumericMenuItem.setText("Remover elemento Não Numérico");
        InsertMenu.setText("Inserir");
        EditMenu.setText("Editar");
        RemoveMenu.setText("Remover");         
        RemoveNonNumericMenuItem.setText("Remover elemento Não Numérico");
        InstanceValidation.setText("Validação da instância");
        FormulaValidation.setText("Validação no Fórmula");
        LanguageSelectionMenu.setText("Idioma");
        helpMenu.setText("Ajuda");
        aboutMenuItem.setText("Sobre");
        saveInstanceFileButton.setText("Salvar relatório");
        M_Error26="O documento de instância não pôde ser validado."+"\n"+"Possivelmente existem valoes incorretos registrados nas sequintes contas:"+"\n"+"ReceitasExcetoIntraOrcamentarias"+"\n"+"relacionadas aos seguintes contextos:";
        M_Error32="O documento de instância não pôde ser validado."+"\n"+"Possivelemnte estão faltando alguns elementos para que o relatório possa ser validado.";
        M_Suc07="Arquivo de instância validado com sucesso.";
        M_Suc09="Documento de instância carregado com sucesso.";
        M_Suc10="Documento de instância gerado com sucesso.";        
        ChoosenLanguage="PT";
        saveJfcTitle="Salvar";
        openJfcTitle="Abrir";
        UIManager.put("FileChooser.lookInLabelText","Procurar em:");
        UIManager.put("FileChooser.fileNameLabelText","Nome do arquivo:");
        UIManager.put("FileChooser.filesOfTypeLabelText","Arquivos do tipo:");
        UIManager.put("FileChooser.upFolderToolTipText","Subir um nível");
        UIManager.put("FileChooser.upFolderAccessibleName","Acima");
        UIManager.put("FileChooser.homeFolderToolTipText","Início");
        UIManager.put("FileChooser.homeFolderAccessibleName","Início");
        UIManager.put("FileChooser.newFolderToolTipText","Criar nova pasta");
        UIManager.put("FileChooser.newFolderAccessibleName","Nova pasta");
        UIManager.put("FileChooser.listViewButtonToolTipText","Lista");
        UIManager.put("FileChooser.listViewButtonAccessibleName","Lista");
        UIManager.put("FileChooser.detailsViewButtonToolTipText","Detalhes");
        UIManager.put("FileChooser.detailsViewButtonAccessibleName","Detalhes");
        UIManager.put("FileChooser.cancelButtonText","Cancelar");
        UIManager.put("FileChooser.cancelButtonToolTipText","Abortar a caixa de diálogo do seletor de arquivos");
        UIManager.put("FileChooser.openButtonText","Abrir");
        UIManager.put("FileChooser.openButtonToolTipText","Abrir arquivo selecionado");
        UIManager.put("FileChooser.saveButtonText","Salvar");
        UIManager.put("FileChooser.saveButtonToolTipText","Salvar o arquivo selecionado");
        UIManager.put("FileChooser.acceptAllFileFilterText","Todos os arquivos");
        UIManager.put("FileChooser.homeFolderToolTipText","Início");
        UIManager.put("FileChooser.newFolderAccessibleName","Nova pasta");
        UIManager.put("FileChooser.viewMenuLabelText","Vista");
        UIManager.put("FileChooser.refreshActionLabelText","Atualizar");
        UIManager.put("FileChooser.newFolderActionLabelText","Nova pasta");
        UIManager.put("FileChooser.listViewActionLabelText","Listar");
        UIManager.put("FileChooser.detailsViewActionLabelText","Detalhes");
        rootNodeLabel="Relatório";
        M_Conf00="Deseja salvar o relatório atual antes de sair?";
        M_Error27="O processo de carga do arquivo falhou. Por favor, tente novamente.";
        M_Conf01="Deseja salvar o relatório atual antes de carregar o novo modelo de relatório?";
        M_Suc16="Modelo de relatório carregado com sucesso.";
        M_Suc14="Não existem problemas relacionados aos elementos não numéricos.";
        M_Suc13="Não existem problemas relacionados à declaração de eixos das contas.";
        M_Suc12="Não existem problemas relacionados à declaração de unidades das contas.";
        M_Suc11="Não existem problemas relacionados à declaração de contextos das contas.";
        M_Fault00="As contas a seguir estão sem declaração de contexto válido:";
        M_Fault01="As contas a seguir estão sem declaração de unidade válida:";
        M_Fault02="As contas a seguir estão sem declaração de eixo válido:";
        M_Fault03="Elementos não numéricos relacionados aos contextos a seguir precisam de uma declaração de referência de contexto válida:";        
        M_Fault04="Os relatórios do Siconfi usam apenas dois decimais para expressar os valores das contas. Verifique tais incosistências relacionadas às seguintes contas:";
        M_Suc15="Não existem problemas relacionados à precisão das contas.";
        M_Error30="Por favor, remova as inconsistências do relatório antes de tentar validá-lo";        
        WIP = "Este recurso estará disponível numa versão futura do OFR...";
        //JOptionPane
        jopTitle="MENSAGEM";
        options[0] = "Sim";
        options[1] = "Não";   
        M_Help="OFR protótipo V1."+"\n"+"Obrigado por usar o programa Open Financial Reporting!"+"\n"+"Se você está com algum problema, acesse o link da documentação do programa:"+"\n"+"";
        closeButton.setText("Sair");
        M_Tip00 = "Primeiro, vá ao menu Modelos de Relatório e selecione uma das opções disponíveis.";
        M_Tip01 = "Para criar um novo relatório, vá ao menu Arquivo e selecione a opção Novo Relatório.";
        M_Tip02 = "Seu relatório está vazio! Vá ao menu Inserir, selecione a opção Inserir Contexto e insira seus dados através da janela aberta.";
        M_Tip03 = "Tente inserir um contexto novo! Vá ao menu Inserir, selecione a opção Inserir Contexto e insira seus dados através da janela aberta.";        
        M_Tip04 = "Tente inserir uma unidade nova! Vá ao menu Inserir, selecione a opção Inserir Unidade e insira seus dados através da janela aberta.";
        M_Tip05 = "Tente inserir uma conta nova! Vá ao menu Inserir, selecione a opção Inserir Conta e insira seus dados através da janela aberta.";
        M_Tip06 = "Tente inserir um elemento Não Numérico novo!"+"\n"+"Vá ao menu Inserir, selecione a opção Inserir elemento Não Numérico e insira seus dados através da janela aberta.";
        M_Tip07 = "Você pode editar elementos através das opções sob o menu Editar toda vez que a validação não obtiver êxito."+"\n"+"Você també pode lidar com elementos inconsistentes desta forma."+"\n"+"Você pode deletar elementos através das opções sob o menu Remover.";                
        M_Tip08 = "Na janela do gerenciador de edição de elementos, use as caixas azuis para escolher o elemento que você quer editar."+"\n"+"Então o OFR irá preencher as caixas restantes com as informações do elemento para você editar.";
        M_Tip09 = "Na janela do gerenciador de exclusão de elementos, use as caixas para escolher o elemento que você quer remover.";        
        HelpTipsMenuItem.setText("Dicas de ajuda");
        if(saveMenuItem.isVisible()){UpdateTree();}
    }//GEN-LAST:event_PortuguesMenuItemActionPerformed

    private void openMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openMenuItemActionPerformed
        // TODO add your handling code here:
        for(JInternalFrame internalFrm:desktopPane.getAllFrames()){
            internalFrm.dispose();
        }        
        //System.out.println(UIManager.get("FileChooser.lookInLabelText")+"\n"+UIManager.get("FileChooser.lookInLabelMnemonic")+"\n"+UIManager.get("FileChooser.fileNameLabelText")+"\n"+UIManager.get("FileChooser.fileNameLabelMnemonic")+"\n"+UIManager.get("FileChooser.filesOfTypeLabelText")+"\n"+UIManager.get("FileChooser.filesOfTypeLabelMnemonic")+"\n"+UIManager.get("FileChooser.upFolderToolTipText")+"\n"+UIManager.get("FileChooser.upFolderAccessibleName")+"\n"+UIManager.get("FileChooser.homeFolderToolTipText")+"\n"+UIManager.get("FileChooser.homeFolderAccessibleName")+"\n"+UIManager.get("FileChooser.newFolderToolTipText")+"\n"+UIManager.get("FileChooser.newFolderAccessibleName")+"\n"+UIManager.get("FileChooser.listViewButtonToolTipText")+"\n"+UIManager.get("FileChooser.listViewButtonAccessibleName")+"\n"+UIManager.get("FileChooser.detailsViewButtonToolTipText")+"\n"+UIManager.get("FileChooser.detailsViewButtonAccessibleName")+"\n"+UIManager.get("FileChooser.cancelButtonText")+"\n"+UIManager.get("FileChooser.cancelButtonMnemonic")+"\n"+UIManager.get("FileChooser.cancelButtonToolTipText")+"\n"+UIManager.get("FileChooser.openButtonText")+"\n"+UIManager.get("FileChooser.openButtonMnemonic")+"\n"+UIManager.get("FileChooser.openButtonToolTipText")+"\n"+UIManager.get("FileChooser.saveButtonText")+"\n"+UIManager.get("FileChooser.saveButtonMnemonic")+"\n"+UIManager.get("FileChooser.saveButtonToolTipText")+"\n"+UIManager.get("FileChooser.acceptAllFileFilterText")+"\n"+UIManager.get("FileChooser.openDialogTitleText")+"\n"+UIManager.get("FileChooser.saveDialogTitleText")+"\n"+UIManager.get("FileChooser.homeFolderToolTipText")+"\n"+UIManager.get("FileChooser.newFolderAccessibleName")+"\n"+UIManager.get("FileChooser.viewMenuLabelText")+"\n"+UIManager.get("FileChooser.refreshActionLabelText")+"\n"+UIManager.get("FileChooser.newFolderActionLabelText")+"\n"+UIManager.get("FileChooser.goupFolderActionLabelText")+"\n"+UIManager.get("FileChooser.listViewActionLabelText")+"\n"+UIManager.get("FileChooser.detailsViewActionLabelText")+"\n"+UIManager.get("FileChooser.foldersLabelText")+"\n"+UIManager.get("FileChooser.viewMenuButtonToolTipText"));
        //initializing the java file chooser
        openJfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());            
        openJfc.setDialogTitle(openJfcTitle);        
        //defining file extensions filters
        openJfc.setAcceptAllFileFilterUsed(false);
        FileNameExtensionFilter filter = new FileNameExtensionFilter("XML", "xml");
        openJfc.addChoosableFileFilter(filter);
        //showing the save dialog box
        int returnValue = openJfc.showOpenDialog(desktopPane);
        // reading the option button, getting the user input and loafing the file
        if (returnValue == JFileChooser.APPROVE_OPTION) {                
        File xmlFile= openJfc.getSelectedFile();                        
        //creating a list of financial statements that will compose the XBRL instance document
        statementList = new ArrayList<>();
        //creating a list of the contexts that the financial statements refer to
        contextList = new ArrayList<>();
        //creating a list of units to express the financial statements
        unitList = new ArrayList<>();
        //creating a list of footnotes regarding the financial statements
        noteList = new ArrayList<>();     
        //creating a string variable to identify the imported element
        String elementIdentifier;
        //creating a list for storing the xml elements from the opened file
        List<Element> OpenedInstanceReport;        
        boolean attachmentIDFound;
        boolean multiAxisContext;
        //could not implement the report validation before oppening
        validReportOppening=true;
        //initializing Jdom2 Sax for reading xml files 
        SAXBuilder builder = new SAXBuilder();
        //storing the retrieved file        
        try{
        Document document = (Document) builder.build(xmlFile);
        Element rootNode = document.getRootElement();
        OpenedInstanceReport=rootNode.getChildren();
        
        //for some reason its not possible to get the value o href from the schemaRef element. It always returns null.
        /*for(Element element:OpenedInstanceReport){
            elementIdentifier=element.getName();
            if(elementIdentifier.equals("schemaRef")){
                System.out.println(element.getAttributeValue("href"));
                if(element.getAttributeValue("href").equals(reportOption)){
                    validReportOppening=true;
                }
            }
        }*/
        if(validReportOppening){        
        //going over the full list of elements
        for(Element element:OpenedInstanceReport){
            elementIdentifier=element.getName();
            //System.out.println(elementIdentifier);
            //identifying and importing explanatory notes
            attachmentIDFound=false;
            multiAxisContext=false;
            int noteIndex=0; 
            for(int j=0; j<nonNumericElements.size();j++){
               if(elementIdentifier.equals(nonNumericElements.elementAt(j))){
                   attachmentIDFound=true;
                   noteIndex=j;
               } 
            }
            if(attachmentIDFound){
                //variables to store the explanatore note items
                String contextRef = element.getAttributeValue("contextRef");
                String content = element.getText();
                // explanatory notes have order 1 and shall follow the order of the siconfi attachments they reffer to.
                //creating the note
                NonNumericDeclaration note = new NonNumericDeclaration(contextRef,content,nonNumericElementsComboBox.elementAt(0));
                note.setAttachment(elementIdentifier);
                note.setIndex(noteIndex);
                //adding the note to the list
                noteList.add(note);
            }else{
                //identifying and importing contexts
                if(elementIdentifier.equals("context")){
                  //variables to store the context items
                  Element entity,identifier,segment,explicitMember,period,startDate,endDate;                  
                  String id,entityIdentifier,entityScheme,explicitMemberDimension="",siconfiDimension="",secondaryExplicitMemberDimension="",secondarySiconfiDimension="",periodStartDate,periodEndDate;                  
                  id=element.getAttributeValue("id");
                  entity=element.getChild("entity",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
                  identifier=entity.getChild("identifier",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));                
                  entityIdentifier=identifier.getText();
                  entityScheme=identifier.getAttributeValue("scheme");
                  segment=entity.getChild("segment",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));                 
                  explicitMember=segment.getChild("explicitMember",Namespace.getNamespace("xbrldi","http://xbrl.org/2006/xbrldi"));
                  explicitMemberDimension=explicitMember.getAttributeValue("dimension");
                  siconfiDimension=explicitMember.getText();                   
                  if(segment.getChildren().size()==2){                      
                      multiAxisContext=true;
                      secondaryExplicitMemberDimension=segment.getChildren().get(1).getAttributeValue("dimension");
                      secondarySiconfiDimension=segment.getChildren().get(1).getText();
                  }                              
                  period=element.getChild("period",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
                  startDate=period.getChild("startDate",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
                  periodStartDate=startDate.getText();
                  endDate=period.getChild("endDate",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance")); 
                  periodEndDate=endDate.getText();
                  //variables to edit the axis and member dimensions retrieved texts.
                  int axisSubstringIndex=explicitMemberDimension.length();
                  int memberSubstringIndex=siconfiDimension.length();
                  explicitMemberDimension=explicitMemberDimension.substring(12,axisSubstringIndex-4);
                  siconfiDimension=siconfiDimension.substring(12,memberSubstringIndex-6);
                  if(multiAxisContext){
                      int secondaryAxisSubstringIndex=secondaryExplicitMemberDimension.length();
                      int secondaryMemberSubstringIndex=secondarySiconfiDimension.length();
                      secondaryExplicitMemberDimension=secondaryExplicitMemberDimension.substring(12,secondaryAxisSubstringIndex-4);
                      secondarySiconfiDimension=secondarySiconfiDimension.substring(12,secondaryMemberSubstringIndex-6);                  
                  }
                  //creating the context
                  ContextDeclaration context = new ContextDeclaration(ContextIndexCalc(siconfiDimension),id,entityIdentifier,entityScheme,explicitMemberDimension,siconfiDimension,periodStartDate,periodEndDate);
                  if(multiAxisContext){
                      context.setHasCoupledAxis(true);
                      context.setSecondaryExplicitMemberDimension(secondaryExplicitMemberDimension);
                      context.setSecondarySiconfiDimension(secondarySiconfiDimension);
                  }
                  //adding the context to the list                  
                  contextList.add(context);
                }else{
                    //identifying and importing units
                    if(elementIdentifier.equals("unit")){
                        //variable to store unit items
                        String unitID, isoCode;
                        Element measure;
                        unitID=element.getAttributeValue("id");
                        measure=element.getChild("measure",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
                        isoCode=measure.getText().substring(8);
                        // creating new unit
                        UnitDeclaration unit = new UnitDeclaration(unitID,isoCode);
                        //adding the unit to the list
                        unitList.add(unit);
                    }else{
                        //identifying and importing financial statements
                        if(!elementIdentifier.equals("schemaRef")){
                            //variables to store the financial statements items
                            String statementId,contextRef,decimals,unitRef,value;
                            statementId=element.getName();
                            contextRef=element.getAttributeValue("contextRef");
                            decimals=element.getAttributeValue("decimals");
                            unitRef=element.getAttributeValue("unitRef");
                            value=element.getText();
                            //creating new statement
                            StatementDeclaration statement= new StatementDeclaration(StatementIndexCalc(statementId),statementId,contextRef,decimals,unitRef,value);
                            //adding statement to thelist
                            statementList.add(statement);
                        }
                    }                    
                }                
            }
        }
        }else{
        System.out.println("Report invalid");
        }
        //creating a new instanceReport object with the previously created lists
        instanceReport = new InstanceReport(statementList,contextList,unitList,noteList);
        InconsistencyChecker(instanceReport);
        InstanceDocTree.setRootVisible(true);
        //enabling options through the menus
        saveMenuItem.setVisible(true);
        InsertMenu.setVisible(true);
        EditMenu.setVisible(true);
        RemoveMenu.setVisible(true);        
        InstanceValidation.setVisible(true);
        saveInstanceFileButton.setEnabled(true);
        //updating the message log
        LogTextArea.setText(LogTextArea.getText()+"\n"+M_Suc09);
        //updating the tree
        UpdateTree();
        }catch (JDOMException jdomex) {
        System.out.println(jdomex.getMessage());
        LogTextArea.setText(LogTextArea.getText()+"\n"+M_Error27);
        
        }catch (IOException io) {
        System.out.println(io.getMessage());
        LogTextArea.setText(LogTextArea.getText()+"\n"+M_Error27);
        }        
        }        
    }//GEN-LAST:event_openMenuItemActionPerformed

    private void saveInstanceFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveInstanceFileButtonActionPerformed
        // TODO add your handling code here:
        saveMenuItem.doClick();        
    }//GEN-LAST:event_saveInstanceFileButtonActionPerformed

    private void ReportModel0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReportModel0ActionPerformed
        // TODO add your handling code here: 
        if(saveMenuItem.isVisible()){
            int userResponse = JOptionPane.showOptionDialog(desktopPane,M_Conf01,jopTitle,JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
            if(userResponse==JOptionPane.YES_OPTION){
                saveMenuItem.doClick();
            }else{
                NewReport.doClick();
            }                
        }
        NewReport.setVisible(true);
        openMenuItem.setVisible(true);
        for(int i=0;i<entryPointsList.size();i++){
            if(entryPointsList.elementAt(i).equals(ReportModel0.getText())){
                reportOption=schemaRefList.elementAt(i);
                LogTextArea.setText(LogTextArea.getText()+"\n"+M_Suc16);
            }
        }
    }//GEN-LAST:event_ReportModel0ActionPerformed

    private void aboutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutMenuItemActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(desktopPane,M_Help+"bit.ly/ofrsupdoc",jopTitle,JOptionPane.WARNING_MESSAGE);
    }//GEN-LAST:event_aboutMenuItemActionPerformed

    private void ReportModel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReportModel1ActionPerformed
        // TODO add your handling code here:
        if(saveMenuItem.isVisible()){
            int userResponse = JOptionPane.showOptionDialog(desktopPane,M_Conf01,jopTitle,JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
            if(userResponse==JOptionPane.YES_OPTION){
                saveMenuItem.doClick();
            }else{
                NewReport.doClick();
            }                
        }
        NewReport.setVisible(true);
        openMenuItem.setVisible(true);
        for(int i=0;i<entryPointsList.size();i++){
            if(entryPointsList.elementAt(i).equals(ReportModel1.getText())){
                reportOption=schemaRefList.elementAt(i);
                LogTextArea.setText(LogTextArea.getText()+"\n"+M_Suc16);
            }
        }        
    }//GEN-LAST:event_ReportModel1ActionPerformed

    private void closeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeButtonActionPerformed
        // TODO add your handling code here:
        exitMenuItem.doClick();
    }//GEN-LAST:event_closeButtonActionPerformed

    private void InsertContextMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertContextMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=1;
        SummonAddElement(insertOption);
    }//GEN-LAST:event_InsertContextMenuItemActionPerformed

    private void InsertUnitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertUnitMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=2;
        SummonAddElement(insertOption);        
    }//GEN-LAST:event_InsertUnitMenuItemActionPerformed

    private void InsertAccountMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertAccountMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=3;
        SummonAddElement(insertOption);         
    }//GEN-LAST:event_InsertAccountMenuItemActionPerformed

    private void InsertNonNumericMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertNonNumericMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=4;
        SummonAddElement(insertOption);         
    }//GEN-LAST:event_InsertNonNumericMenuItemActionPerformed

    private void EditContextMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditContextMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=1;
        SummonEditElement(insertOption);        
    }//GEN-LAST:event_EditContextMenuItemActionPerformed

    private void EditUnitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditUnitMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=2;
        SummonEditElement(insertOption);         
    }//GEN-LAST:event_EditUnitMenuItemActionPerformed

    private void EditAccountMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditAccountMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=3;
        SummonEditElement(insertOption);         
    }//GEN-LAST:event_EditAccountMenuItemActionPerformed

    private void EditNonNumericMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditNonNumericMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=4;
        SummonEditElement(insertOption);         
    }//GEN-LAST:event_EditNonNumericMenuItemActionPerformed

    private void RemoveContextMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveContextMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=1;
        SummonDeleteElement(insertOption);         
    }//GEN-LAST:event_RemoveContextMenuItemActionPerformed

    private void RemoveUnitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveUnitMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=2;
        SummonDeleteElement(insertOption);         
    }//GEN-LAST:event_RemoveUnitMenuItemActionPerformed

    private void RemoveAccountMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveAccountMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=3;
        SummonDeleteElement(insertOption);        
    }//GEN-LAST:event_RemoveAccountMenuItemActionPerformed

    private void RemoveNonNumericMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveNonNumericMenuItemActionPerformed
        // TODO add your handling code here:
        insertOption=4;
        SummonDeleteElement(insertOption);         
    }//GEN-LAST:event_RemoveNonNumericMenuItemActionPerformed

    private void RemoveMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RemoveMenuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RemoveMenuActionPerformed

    private void LoadTaxonomySetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoadTaxonomySetActionPerformed
        // TODO add your handling code here:
        LogTextArea.setText(LogTextArea.getText()+"\n"+WIP);
    }//GEN-LAST:event_LoadTaxonomySetActionPerformed

    private void HelpTipsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HelpTipsMenuItemActionPerformed
        // TODO add your handling code here:
        if(reportOption.equals("")){
            JOptionPane.showMessageDialog(desktopPane,M_Tip00,jopTitle,JOptionPane.PLAIN_MESSAGE);
        }else{
            if(!InstanceDocTree.isRootVisible()){
                JOptionPane.showMessageDialog(desktopPane,M_Tip01,jopTitle,JOptionPane.PLAIN_MESSAGE);
            }else{
                if(instanceReport.contextList.isEmpty()&&instanceReport.statementList.isEmpty()&&instanceReport.noteList.isEmpty()&&instanceReport.unitList.isEmpty()){
                    JOptionPane.showMessageDialog(desktopPane,M_Tip02,jopTitle,JOptionPane.PLAIN_MESSAGE);
                }else{
                    if(instanceReport.contextList.isEmpty()){
                        JOptionPane.showMessageDialog(desktopPane,M_Tip03,jopTitle,JOptionPane.PLAIN_MESSAGE);
                    }else{
                        if(instanceReport.unitList.isEmpty()){
                            JOptionPane.showMessageDialog(desktopPane,M_Tip04,jopTitle,JOptionPane.PLAIN_MESSAGE);
                        }else{
                           if(instanceReport.statementList.isEmpty()){
                               JOptionPane.showMessageDialog(desktopPane,M_Tip05,jopTitle,JOptionPane.PLAIN_MESSAGE);
                           }else{
                               if(instanceReport.noteList.isEmpty()){
                                   JOptionPane.showMessageDialog(desktopPane,M_Tip06,jopTitle,JOptionPane.PLAIN_MESSAGE);
                               }else{
                                   if(editElement!=null&&editElement.isVisible()){                                      
                                            JOptionPane.showMessageDialog(desktopPane,M_Tip08,jopTitle,JOptionPane.PLAIN_MESSAGE);                                       
                                    }else{
                                       if(deleteElement!=null&&deleteElement.isVisible()){
                                                JOptionPane.showMessageDialog(desktopPane,M_Tip09,jopTitle,JOptionPane.PLAIN_MESSAGE);         
                                       }else{
                                           JOptionPane.showMessageDialog(desktopPane,M_Tip07,jopTitle,JOptionPane.PLAIN_MESSAGE);
                                       }
                                   }
                               }
                           } 
                        }
                    }
                }
            }
        }
    }//GEN-LAST:event_HelpTipsMenuItemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OpenFinancialReporting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OpenFinancialReporting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OpenFinancialReporting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OpenFinancialReporting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try{
                new OpenFinancialReporting().setVisible(true);
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu AvailableReportModels;
    private javax.swing.JMenuItem EditAccountMenuItem;
    private javax.swing.JMenuItem EditContextMenuItem;
    private javax.swing.JMenu EditMenu;
    private javax.swing.JMenuItem EditNonNumericMenuItem;
    private javax.swing.JMenuItem EditUnitMenuItem;
    private javax.swing.JMenuItem EnglishMenuItem;
    private javax.swing.JMenuItem EspanolMenuItem;
    private javax.swing.JMenuItem FormulaValidation;
    private javax.swing.JMenuItem HelpTipsMenuItem;
    private javax.swing.JTextArea InconsistenciesLogTextArea;
    private javax.swing.JScrollPane InconsistenciesLogjScrollPane;
    private javax.swing.JMenuItem InsertAccountMenuItem;
    private javax.swing.JMenuItem InsertContextMenuItem;
    private javax.swing.JMenu InsertMenu;
    private javax.swing.JMenuItem InsertNonNumericMenuItem;
    private javax.swing.JMenuItem InsertUnitMenuItem;
    private javax.swing.JTree InstanceDocTree;
    private javax.swing.JMenu InstanceValidation;
    private javax.swing.JMenu LanguageSelectionMenu;
    private javax.swing.JMenuItem LoadTaxonomySet;
    private javax.swing.JTextArea LogTextArea;
    private javax.swing.JScrollPane LogjScrollPane;
    private javax.swing.JButton LogoButton;
    private javax.swing.JScrollPane LogoButtonScrollPane;
    private javax.swing.JMenuItem NewReport;
    private javax.swing.JMenuItem PortuguesMenuItem;
    private javax.swing.JMenuItem RemoveAccountMenuItem;
    private javax.swing.JMenuItem RemoveContextMenuItem;
    private javax.swing.JMenu RemoveMenu;
    private javax.swing.JMenuItem RemoveNonNumericMenuItem;
    private javax.swing.JMenuItem RemoveUnitMenuItem;
    private javax.swing.JMenuItem ReportModel0;
    private javax.swing.JMenuItem ReportModel1;
    private javax.swing.JMenu Taxonomy;
    private javax.swing.JScrollPane TreejScrollPane;
    private javax.swing.JMenuItem aboutMenuItem;
    private javax.swing.JButton closeButton;
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem openMenuItem;
    private javax.swing.JButton saveInstanceFileButton;
    private javax.swing.JMenuItem saveMenuItem;
    // End of variables declaration//GEN-END:variables
    @Override
    public void internalFrameOpened(InternalFrameEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void internalFrameClosing(InternalFrameEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void internalFrameClosed(InternalFrameEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        //Whenever an editing window is disposed, it is necessary to grant the order among the instance elements according to the PresentationLink definitions.
        PresentationOrdering(instanceReport);
        //Whenever an editing window is disposed, it is necessary to update the tree view.
        UpdateTree();
        //Whenever an editing window is disposed, it is necessary to check for inconsitencies.
        try{InconsistencyChecker(instanceReport);}catch (IOException x){x.printStackTrace();}
    }

    @Override
    public void internalFrameIconified(InternalFrameEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void internalFrameDeiconified(InternalFrameEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void internalFrameActivated(InternalFrameEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void internalFrameDeactivated(InternalFrameEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
