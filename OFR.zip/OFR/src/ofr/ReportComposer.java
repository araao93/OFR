/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import java.util.Vector;
import org.jdom2.Attribute;
import org.jdom2.AttributeType;
import org.jdom2.CDATA;
import org.jdom2.Content;
import org.jdom2.DataConversionException;
import org.jdom2.DefaultJDOMFactory;
import org.jdom2.DocType;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.EntityRef;
import org.jdom2.IllegalAddException;
import org.jdom2.IllegalDataException;
import org.jdom2.IllegalNameException;
import org.jdom2.IllegalTargetException;
import org.jdom2.JDOMConstants;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.ProcessingInstruction;
import org.jdom2.SlimJDOMFactory;
import org.jdom2.TestIllegalAddExceptn;
import org.jdom2.TestIllegalNameExceptn;
import org.jdom2.TestIllegalTargetExceptn;
import org.jdom2.TestStringBin;
import org.jdom2.Text;
import org.jdom2.UncheckedJDOMFactory;
import org.jdom2.Verifier;
import org.jdom2.adapters.AbstractDOMAdapter;
import org.jdom2.adapters.JAXPDOMAdapter;
import org.jdom2.contrib.android.TranslateTests;
import org.jdom2.contrib.beans.BeanMapper;
import org.jdom2.contrib.beans.BeanMapperException;
import org.jdom2.contrib.beans.DateUtils;
import org.jdom2.contrib.beans.JDOMBean;
import org.jdom2.contrib.beans.StringConverter;
import org.jdom2.contrib.beans.TestBean;
import org.jdom2.contrib.beans.TestIndexed;
import org.jdom2.contrib.dom.DOM;
import org.jdom2.contrib.dtdaware.AttAwareXMLOutputProcessor;
import org.jdom2.contrib.dtdaware.AttFilter;
import org.jdom2.contrib.dtdaware.AttFilteredXMLOutputProcessor;
import org.jdom2.contrib.ids.IdAttribute;
import org.jdom2.contrib.ids.IdDocument;
import org.jdom2.contrib.ids.IdFactory;
import org.jdom2.contrib.input.LineNumberElement;
import org.jdom2.contrib.input.LineNumberSAXHandler;
import org.jdom2.contrib.input.ResultSetBuilder;
import org.jdom2.contrib.input.scanner.ElementListener;
import org.jdom2.contrib.input.scanner.ElementScanner;
import org.jdom2.contrib.input.scanner.XPathMatcher;
import org.jdom2.contrib.output.JTreeOutputter;
import org.jdom2.contrib.perf.PerfDoc;
import org.jdom2.contrib.perf.PerfTest;
import org.jdom2.contrib.perf.PerfVerifier;
import org.jdom2.contrib.perf.SavingVerifier;
import org.jdom2.contrib.schema.Schema;
import org.jdom2.contrib.schema.ValidationError;
import org.jdom2.contrib.verifier.VerifierBuilder;
import org.jdom2.contrib.xpath.java.JavaXPathFactory;
import org.jdom2.contrib.xpath.xalan.XalanXPathFactory;
import org.jdom2.filter.AbstractFilter;
import org.jdom2.filter.AttributeFilter;
import org.jdom2.filter.AttributeFilter;
import org.jdom2.filter.ContentFilter;
import org.jdom2.filter.ElementFilter;
import org.jdom2.filter.Filter;
import org.jdom2.filter.Filters;
import org.jdom2.input.DOMBuilder;
import org.jdom2.input.JDOMParseException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.input.StAXEventBuilder;
import org.jdom2.input.StAXStreamBuilder;
import org.jdom2.input.sax.AbstractReaderSchemaFactory;
import org.jdom2.input.sax.AbstractReaderXSDFactory;
import org.jdom2.input.sax.BuilderErrorHandler;
import org.jdom2.input.sax.DefaultSAXHandlerFactory;
import org.jdom2.input.sax.SAXBuilderEngine;
import org.jdom2.input.sax.SAXEngine;
import org.jdom2.input.sax.SAXHandler;
import org.jdom2.input.sax.SAXHandlerFactory;
import org.jdom2.input.sax.TestTextBuffer;
import org.jdom2.input.sax.XMLReaderJAXPFactory;
import org.jdom2.input.sax.XMLReaderJDOMFactory;
import org.jdom2.input.sax.XMLReaderSAX2Factory;
import org.jdom2.input.sax.XMLReaderSchemaFactory;
import org.jdom2.input.sax.XMLReaderXSDFactory;
import org.jdom2.input.sax.XMLReaders;
import org.jdom2.input.stax.DTDParser;
import org.jdom2.input.stax.DefaultStAXFilter;
import org.jdom2.input.stax.StAXFilter;
import org.jdom2.internal.ArrayCopy;
import org.jdom2.internal.ReflectionConstructor;
import org.jdom2.internal.SystemProperty;
import org.jdom2.located.Located;
import org.jdom2.located.LocatedCDATA;
import org.jdom2.located.LocatedComment;
import org.jdom2.located.LocatedDocType;
import org.jdom2.located.LocatedElement;
import org.jdom2.located.LocatedEntityRef;
import org.jdom2.located.LocatedJDOMFactory;
import org.jdom2.located.LocatedProcessingInstruction;
import org.jdom2.located.LocatedText;
import org.jdom2.output.DOMOutputter;
import org.jdom2.output.EscapeStrategy;
import org.jdom2.output.Format;
import org.jdom2.output.JDOMLocator;
import org.jdom2.output.LineSeparator;
import org.jdom2.output.SAXOutputter;
import org.jdom2.output.StAXEventOutputter;
import org.jdom2.output.XMLOutputter;
import org.jdom2.output.support.AbstractDOMOutputProcessor;
import org.jdom2.output.support.AbstractFormattedWalker;
import org.jdom2.output.support.AbstractOutputProcessor;
import org.jdom2.output.support.AbstractSAXOutputProcessor;
import org.jdom2.output.support.AbstractStAXEventProcessor;
import org.jdom2.output.support.AbstractStAXStreamProcessor;
import org.jdom2.output.support.AbstractXMLOutputProcessor;
import org.jdom2.output.support.DOMOutputProcessor;
import org.jdom2.output.support.FormatStack;
import org.jdom2.output.support.SAXOutputProcessor;
import org.jdom2.output.support.SAXTarget;
import org.jdom2.output.support.StAXEventProcessor;
import org.jdom2.output.support.StAXStreamProcessor;
import org.jdom2.output.support.Walker;
import org.jdom2.output.support.WalkerNORMALIZE;
import org.jdom2.output.support.WalkerPRESERVE;
import org.jdom2.output.support.WalkerTRIM;
import org.jdom2.output.support.WalkerTRIM_FULL_WHITE;
import org.jdom2.output.support.XMLOutputProcessor;
import org.jdom2.test.cases.AbstractTestJDOMFactory;
import org.jdom2.test.cases.TestAttribute;
import org.jdom2.test.cases.TestAttributeList;
import org.jdom2.test.cases.TestBridgeMethods;
import org.jdom2.test.cases.TestCDATA;
import org.jdom2.test.cases.TestComment;
import org.jdom2.test.cases.TestContentList;
import org.jdom2.test.cases.TestDefaultJDOMFactory;
import org.jdom2.test.cases.TestDescendantFilterIterator;
import org.jdom2.test.cases.TestDescendantIterator;
import org.jdom2.test.cases.TestDocType;
import org.jdom2.test.cases.TestDocument;
import org.jdom2.test.cases.TestElement;
import org.jdom2.test.cases.TestElementFilterList;
import org.jdom2.test.cases.TestEntityRef;
import org.jdom2.test.cases.TestFilterList;
import org.jdom2.test.cases.TestFilterListElement;
import org.jdom2.test.cases.TestFilterListText;
import org.jdom2.test.cases.TestJDOMExceptn;
import org.jdom2.test.cases.TestNamespace;
import org.jdom2.test.cases.TestNamespaceAware;
import org.jdom2.test.cases.TestProcessingInstruction;
import org.jdom2.test.cases.TestSerialization;
import org.jdom2.test.cases.TestSlimJDOMFactory;
import org.jdom2.test.cases.TestSlimJDOMFactoryNoText;
import org.jdom2.test.cases.TestText;
import org.jdom2.test.cases.TestUncheckedJDOMFactory;
import org.jdom2.test.cases.TestVerifier;
import org.jdom2.test.cases.TestVerifierCharacters;
import org.jdom2.test.cases.adapters.TestJAXPDOMAdapter;
import org.jdom2.test.cases.filter.AbstractTestFilter;
import org.jdom2.test.cases.filter.TestAtributeFilter;
import org.jdom2.test.cases.filter.TestContentFilter;
import org.jdom2.test.cases.filter.TestElementFilter;
import org.jdom2.test.cases.filter.TestFilters;
import org.jdom2.test.cases.filter.TestPassThroughFilter;
import org.jdom2.test.cases.input.HelpTestDOMBuilder;
import org.jdom2.test.cases.input.TestBuilderErrorHandler;
import org.jdom2.test.cases.input.TestDOMBuilder;
import org.jdom2.test.cases.input.TestDTDParser;
import org.jdom2.test.cases.input.TestJDOMParseExceptn;
import org.jdom2.test.cases.input.TestSAXBuilder;
import org.jdom2.test.cases.input.TestSAXComplexSchema;
import org.jdom2.test.cases.input.TestSAXHandler;
import org.jdom2.test.cases.input.TestStAXEventBuilder;
import org.jdom2.test.cases.input.TestStAXStreamBuilder;
import org.jdom2.test.cases.input.sax.TestXMLReaderJAXPFactory;
import org.jdom2.test.cases.input.sax.TestXMLReaderSAX2Factory;
import org.jdom2.test.cases.input.sax.TestXMLReaderSchemaFactory;
import org.jdom2.test.cases.input.sax.TestXMLReaderSingletons;
import org.jdom2.test.cases.input.sax.TestXMLReaderXSDFactory;
import org.jdom2.test.cases.located.TestLocatedJDOMFactory;
import org.jdom2.test.cases.output.AbstractTestOutputter;
import org.jdom2.test.cases.output.TestDOMOutputter;
import org.jdom2.test.cases.output.TestDOMOutputterXmlnsNamespaces;
import org.jdom2.test.cases.output.TestFormat;
import org.jdom2.test.cases.output.TestSAXOutputter;
import org.jdom2.test.cases.output.TestStAXEventOutputter;
import org.jdom2.test.cases.output.TestStAXStreamOutputter;
import org.jdom2.test.cases.output.TestXMLOutputProcessor;
import org.jdom2.test.cases.output.TestXMLOutputter;
import org.jdom2.test.cases.serialize.SAttribute;
import org.jdom2.test.cases.serialize.SCDATA;
import org.jdom2.test.cases.serialize.SComment;
import org.jdom2.test.cases.serialize.SDocType;
import org.jdom2.test.cases.serialize.SElement;
import org.jdom2.test.cases.serialize.SEntityRef;
import org.jdom2.test.cases.serialize.SFilter;
import org.jdom2.test.cases.serialize.SProcessingInstruction;
import org.jdom2.test.cases.serialize.SText;
import org.jdom2.test.cases.serialize.TestSubclassSerializables;
import org.jdom2.test.cases.special.TestIssue008ExpandEntity;
import org.jdom2.test.cases.transform.TestJDOMResult;
import org.jdom2.test.cases.transform.TestJDOMSource;
import org.jdom2.test.cases.transform.TestJDOMTransform;
import org.jdom2.test.cases.transform.TestXSLTransformExceptn;
import org.jdom2.test.cases.transform.TestXSLTransformer;
import org.jdom2.test.cases.util.TestArrayCopy;
import org.jdom2.test.cases.util.TestNamespaceStack;
import org.jdom2.test.cases.util.TestReflectionConstructor;
import org.jdom2.test.cases.xpath.AbstractTestXPathCompiled;
import org.jdom2.test.cases.xpath.AbstractTestXPathHepler;
import org.jdom2.test.cases.xpath.TestDefaultXPathHelper;
import org.jdom2.test.cases.xpath.TestJavaCompiled;
import org.jdom2.test.cases.xpath.TestJaxenCompiled;
import org.jdom2.test.cases.xpath.TestJaxenXPathHelper;
import org.jdom2.test.cases.xpath.TestXPathBuilder;
import org.jdom2.test.cases.xpath.TestXPathFactory;
import org.jdom2.test.cases.xpath.TestXalanCompiled;
import org.jdom2.test.util.AbstractTestList;
import org.jdom2.test.util.FidoFetch;
import org.jdom2.test.util.ListTest;
import org.jdom2.test.util.UnitTestUtil;
import org.jdom2.test.util.VerifierTestBuilder;
import org.jdom2.transform.JDOMResult;
import org.jdom2.transform.JDOMSource;
import org.jdom2.transform.XSLTransformException;
import org.jdom2.transform.XSLTransformer;
import org.jdom2.util.IteratorIterable;
import org.jdom2.util.NamespaceStack;
import org.jdom2.xpath.XPathBuilder;
import org.jdom2.xpath.XPathDiagnostic;
import org.jdom2.xpath.XPathExpression;
import org.jdom2.xpath.XPathFactory;
import org.jdom2.xpath.XPathHelper;
import org.jdom2.xpath.jaxen.JaxenXPathFactory;
import org.jdom2.xpath.util.AbstractXPathCompiled;
import org.jdom2.xpath.util.XPathDiagnosticImpl;

/**
 *
 * @author Antônio Ricardo d' Araujo Amâncio Oliveira
 */
public class ReportComposer {

    /**
     * @param args the command line arguments
     */
   
     public static void writeFileUsingJDOM(List<StatementDeclaration> elementList,List<ContextDeclaration> contextList, List<UnitDeclaration> unitList,List<NonNumericDeclaration> noteList, String fileName,String reportOption) throws IOException, IllegalNameException{        
                       
        //creating a new document
        Document doc = new Document();
        //creating root element and adding the DTS namespaces
        doc.setRootElement(new Element("xbrl",  Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance")));
        doc.getRootElement().addNamespaceDeclaration(Namespace.getNamespace("iso4217","http://www.xbrl.org/2003/iso4217"));
        doc.getRootElement().addNamespaceDeclaration(Namespace.getNamespace("link","http://www.xbrl.org/2003/linkbase"));
        doc.getRootElement().addNamespaceDeclaration(Namespace.getNamespace("siconfi-cor","http://fazenda.gov.br/siconfi/cor/ic/siconfi-cor_2019-12-31"));
        doc.getRootElement().addNamespaceDeclaration(Namespace.getNamespace("siconfi-dim","http://fazenda.gov.br/siconfi/cor/dim/siconfi-dim_2019-12-31"));
        doc.getRootElement().addNamespaceDeclaration(Namespace.getNamespace("xbrldi","http://xbrl.org/2006/xbrldi"));
        doc.getRootElement().addNamespaceDeclaration(Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
        doc.getRootElement().addNamespaceDeclaration(Namespace.getNamespace("xsi","http://www.w3.org/2001/XMLSchema-instance"));
        doc.getRootElement().setAttribute("schemaLocation", "http://xbrl.org/2006/xbrldi http://www.xbrl.org/2006/xbrldi-2006.xsd", Namespace.getNamespace("xsi","http://www.w3.org/2001/XMLSchema-instance"));
        //adding taxonomy xsd schema reference
        Element schemaRef = new Element("schemaRef",Namespace.getNamespace("link","http://www.xbrl.org/2003/linkbase"));        
        schemaRef.setAttribute("href",reportOption,Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));        
        schemaRef.setAttribute("type","simple",Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
        doc.getRootElement().addContent(schemaRef);
        // every explanatory note added to the noteList will undergo the following process 
        for(NonNumericDeclaration noteItem : noteList){
            //Defining to which attachment the note refers to
            //XBRL element's definition            
            Element note = new Element(noteItem.getAttachment(),Namespace.getNamespace("siconfi-cor","http://fazenda.gov.br/siconfi/cor/ic/siconfi-cor_2019-12-31"));
            //defining element's hierarchy and content 
            note.setAttribute("contextRef",""+noteItem.getContextRef());
            note.addContent(noteItem.getContent());            
            //adding the financial statement to the XBRL file
            doc.getRootElement().addContent(note);
        }
        //every context added to the conetxtList will undergo the following process        
        for(ContextDeclaration context : contextList){
            //XBRL elements' definition
            Element financialContext = new Element("context",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
            Element entity = new Element("entity",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
            Element entityIdentifier = new Element("identifier",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
            Element entitySegment = new Element("segment",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
            Element explicitMember = new Element("explicitMember",Namespace.getNamespace("xbrldi","http://xbrl.org/2006/xbrldi"));
            Element period = new Element ("period",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
            Element periodStartDate = new Element ("startDate",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
            Element periodEndDate = new Element ("endDate",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
            Element secondaryExplicitMember = new Element("explicitMember",Namespace.getNamespace("xbrldi","http://xbrl.org/2006/xbrldi"));
            //defining elements' hierarchy and content 
            financialContext.setAttribute("id",""+context.getId());
            entityIdentifier.setAttribute("scheme",""+context.getEntityScheme());
            explicitMember.setAttribute("dimension",""+context.getExplicitMemberDimension());
            if(context.getHasCoupledAxis()){
                secondaryExplicitMember.setAttribute("dimension",""+context.getSecondaryExplicitMemberDimension());
                secondaryExplicitMember.addContent(context.getSecondarySiconfiDimension());
            }                     
            entityIdentifier.addContent(context.getEntityIdentifier());
            explicitMember.addContent(context.getSiconfiDimension());
            entity.addContent(entityIdentifier);
            entity.addContent(entitySegment);
            entitySegment.addContent(explicitMember);
            if(context.getHasCoupledAxis()){
                entitySegment.addContent(secondaryExplicitMember);
            }
            periodStartDate.addContent(context.getPeriodStartDate());
            periodEndDate.addContent(context.getPeriodEndDate());
            period.addContent(periodStartDate);
            period.addContent(periodEndDate);
            financialContext.addContent(entity);
            financialContext.addContent(period);
            //adding the context to the XBRL file
            doc.getRootElement().addContent(financialContext);
        }
        //every unit added to the elementList will undergo the following process
        for(UnitDeclaration unit : unitList){
            //XBRL element's definition
            Element unitElement = new Element("unit",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
            Element measureElement = new Element("measure",Namespace.getNamespace("xbrli","http://www.xbrl.org/2003/instance"));
            measureElement.addNamespaceDeclaration(Namespace.getNamespace("iso4217","http://www.xbrl.org/2003/iso4217"));
            //defining element's hierarchy and content 
            unitElement.setAttribute("id",""+unit.getId());
            measureElement.addContent(unit.getISOIdentifier());
            unitElement.addContent(measureElement);
            //adding the financial statement to the XBRL file
            doc.getRootElement().addContent(unitElement);
        }        
        //every financial statement added to the elementList will undergo the following process
        for(StatementDeclaration element : elementList){
            //XBRL element's definition
            Element financialStatement = new Element(""+element.getId(),Namespace.getNamespace("siconfi-cor","http://fazenda.gov.br/siconfi/cor/ic/siconfi-cor_2019-12-31"));
            //defining element's hierarchy and content 
            financialStatement.setAttribute("contextRef",""+element.getContextRef());
            financialStatement.setAttribute("decimals",""+element.getDecimals());            
            financialStatement.setAttribute("unitRef",""+element.getUnitRef());
            financialStatement.addContent(String.valueOf(element.getValue()));
            //adding the financial statement to the XBRL file
            doc.getRootElement().addContent(financialStatement);
        }
        //for(FootnoteDeclaration footnoteItem : footnoteList){
            //XBRL element's definition
        //    Element footnoteLink = new Element("footnoteLink",Namespace.getNamespace("link","http://www.xbrl.org/2003/linkbase"));
        //    Element loc = new Element("loc",Namespace.getNamespace("link","http://www.xbrl.org/2003/linkbase"));
//            Element footnote = new Element("footnote",Namespace.getNamespace("link","http://www.xbrl.org/2003/linkbase"));
//            Element footnoteArc = new Element("footnoteArc",Namespace.getNamespace("link","http://www.xbrl.org/2003/linkbase"));
            //defining element's hierarchy and content 
//            footnoteLink.setAttribute("type",""+footnoteItem.getFootnoteLinkType(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            footnoteLink.setAttribute("role",""+footnoteItem.getFootnoteLinkRole(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            loc.setAttribute("type",""+footnoteItem.getLocType(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            loc.setAttribute("href",""+footnoteItem.getLocRef(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            loc.setAttribute("label",""+footnoteItem.getLocLabel(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            loc.setAttribute("label",""+footnoteItem.getLocLabel(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            footnote.setAttribute("type",""+footnoteItem.getFootnoteType(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            footnote.setAttribute("label",""+footnoteItem.getFootnoteLabel(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            footnote.setAttribute("role",""+footnoteItem.getFootnoteRole(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            footnote.setAttribute("lang",""+footnoteItem.getFootnoteXMLlang(),Namespace.getNamespace("xml","http://www.w3.org/XML/1998/namespace"));
//            footnote.addContent(footnoteItem.getFootnoteContent());            
//            footnoteArc.setAttribute("type",""+footnoteItem.getFootnoteArcType(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            footnoteArc.setAttribute("arcrole",""+footnoteItem.getFootnoteArcArcrole(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            footnoteArc.setAttribute("from",""+footnoteItem.getFootnoteArcFrom(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            footnoteArc.setAttribute("to",""+footnoteItem.getFootnoteArcTo(),Namespace.getNamespace("xlink","http://www.w3.org/1999/xlink"));
//            footnoteLink.addContent(loc);
//            footnoteLink.addContent(footnote);
//            footnoteLink.addContent(footnoteArc);
            //adding the financial statement to the XBRL file
//            doc.getRootElement().addContent(footnoteLink);
//        }
        //organizing the instance file
        XMLOutputter xmlOutputter = new XMLOutputter(Format.getPrettyFormat());
        //output xml to console for debugging
        //xmlOutputter.output(doc, System.out);
        //generating the instance file
        xmlOutputter.output(doc, new FileOutputStream(fileName));
    }
}
