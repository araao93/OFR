/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;

/**
 *
 * @author anton
 */
public class StatementDeclaration {
    private Integer index;
    private String id;
    private String contextRef;    
    private String decimals;
    private String unitRef;
    private String value;
    
    public StatementDeclaration (int index, String id, String contextRef, String decimals, String unitRef, String value){
        this.index=index;
        this.id=id;
        this.contextRef=contextRef;
        this.decimals=decimals;
        this.unitRef=unitRef;
        this.value=value;
    }
    public int getIndex() {
        return index;
    }
    public void setIndex(int index) {
        this.index = index;
    }    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getDecimals() {
        return decimals;
    }
    public void setDecimals(String decimals) {
        this.decimals = decimals;
    }
    public String getContextRef() {
        return contextRef;
    }
    public void setContextRef(String contextRef) {
        this.contextRef = contextRef;
    }
    public String getUnitRef() {
        return unitRef;
    }
    public void setUnitRef(String unitRef) {
        this.unitRef = unitRef;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public String toString() {
        return id;
    }
}
