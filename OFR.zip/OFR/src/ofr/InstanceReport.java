/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;
import java.util.*;
import java.util.List;

/**
 *
 * @author anton
 */
public class InstanceReport {
     //It defines a list to store the financial statements that will compose the XBRL instance document
        List<StatementDeclaration> statementList;
        //It defines a list to store the contexts that the financial statements refer to
        List<ContextDeclaration> contextList;
        //It defines a list to store the units to express the financial statements
        List<UnitDeclaration> unitList;
        //It defines a list to store the explanatory notes regarding contexts
        List<NonNumericDeclaration> noteList;
        //It defines a list to store the footnotes regarding the financial statements
/*        List<FootnoteDeclaration> footnoteList;*/     
        public InstanceReport(List<StatementDeclaration> statementList,List<ContextDeclaration> contextList, List<UnitDeclaration> unitList,List<NonNumericDeclaration> noteList){
        this.statementList=statementList;
        this.contextList=contextList;
        this.unitList=unitList;
        this.noteList=noteList;
        }
        Comparator<StatementDeclaration> compareByIndexS = new Comparator<StatementDeclaration>() {
            @Override
            public int compare(StatementDeclaration o1, StatementDeclaration o2) {
            return o1.getIndex()-o2.getIndex();
            }
        };
        Comparator<ContextDeclaration> compareByIndexC = new Comparator<ContextDeclaration>() {
            @Override
            public int compare(ContextDeclaration o1, ContextDeclaration o2) {
            return o1.getIndex()-o2.getIndex();
            }
        };
        Comparator<NonNumericDeclaration> compareByIndexN = new Comparator<NonNumericDeclaration>() {
            @Override
            public int compare(NonNumericDeclaration o1, NonNumericDeclaration o2) {
            return o1.getIndex()-o2.getIndex();
            }
        };        
        public List<StatementDeclaration> getStatementList() {
            return statementList;
        }
        public void setStatementList(List<StatementDeclaration> statementList) {
            this.statementList = statementList;
        }
        public void sortStatementList() {
            Collections.sort(this.statementList,compareByIndexS);
        }
        public List<ContextDeclaration> getContextList() {
            return contextList;
        }
        public void setContextList(List<ContextDeclaration> contextList) {
            this.contextList = contextList;
        }
        public List<UnitDeclaration> getUnitList() {
            return unitList;
        }
        public void sortContextList() {
            Collections.sort(this.contextList,compareByIndexC);
        }
        public void setUnitList(List<UnitDeclaration> unitList) {
            this.unitList = unitList;
        }
        //In future versions its necessary to implement sortUnitList and sortNotesList methods
        public List<NonNumericDeclaration> getNoteList() {
            return noteList;
        }
        public void setNoteList(List<NonNumericDeclaration> noteList) {
            this.noteList = noteList;
        }
        public void sortNoteList() {
            Collections.sort(this.noteList,compareByIndexN);
        }        
        public void addStatement(StatementDeclaration statement){
            this.statementList.add(statement);
        }
        public void addContext(ContextDeclaration context){
            this.contextList.add(context);
        }
        public void addUnit(UnitDeclaration unit){
            this.unitList.add(unit);
        }
        public void addNote(NonNumericDeclaration note){
            this.noteList.add(note);
        }
/*        public void deleteStatement(StatementDeclaration statement){
            this.statementList.remove(statement);
        }
        public void deleteContext(ContextDeclaration context){
            this.contextList.remove(context);
        }
        public void deleteUnit(UnitDeclaration unit){
            this.unitList.remove(unit);
        }
        public void deleteNote(NonNumericDeclaration note){
            this.noteList.remove(note);
        }
*/
}
