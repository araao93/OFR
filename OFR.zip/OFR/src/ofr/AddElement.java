/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;

import java.awt.Font;
import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.util.Vector;
/**
 *
 * @author anton
 */
public class AddElement extends javax.swing.JInternalFrame{
    InstanceReport instanceReport;
    //initializing string arrays with the comboboxes items                              
        Vector<String> contextAxisComboBox = new Vector<String>();
        Vector<String> schemaComboBox = new Vector<String>();
        Vector<String> isoCodeComboBox = new Vector<String>();
        Vector<String> statementIdComboBox = new Vector<String>();
        Vector<String> contextMemberComboBox = new Vector<String>();        
        Vector<String> nonNumericElementsComboBox = new Vector<String>();
        Vector<String> coupledAxisList = new Vector<String>();
        Vector<String> secondaryAxisComboBox = new Vector<String>();
        Vector<String> startDateComboBox=new Vector<String>();
        Vector<String> endDateComboBox=new Vector<String>();
    //initializing strings to store the error messages text
    String M_Error00,M_Error01,M_Error02,M_Error03,M_Error04,M_Error05,M_Error06,M_Error07,M_Error18,M_Error28,M_Error29,M_Error30,M_Error31;
    //initializing strings to store the success messages text
    String M_Suc01;
    //String for JOprionPane Boxes Title
    String jopTitle;
    //initializing log text area    
    JTextArea LogTextArea;
    int InsertOption;
    /**
     * Creates new form AddElement
     */
    public AddElement()throws IOException {
        LoadAuxiliarFiles();
        //initializing all JFrame components
        initComponents();
        StaticComboBoxInitializer();
        SecondaryContextAxisComboBox.setEnabled(false);
        SecondaryContextDimensionComboBox.setEnabled(false);
        Font newCheckBoxFont=new Font(ContextCheckBox.getFont().getName(),Font.ITALIC+Font.BOLD,ContextCheckBox.getFont().getSize());
        StatementCheckBox.setFont(newCheckBoxFont);
        ContextCheckBox.setFont(newCheckBoxFont);
        UnitCheckBox.setFont(newCheckBoxFont);
        NoteCheckBox.setFont(newCheckBoxFont);
    }
    public void StaticComboBoxInitializer (){
        //cleaning the existing comboboxes
        availableUnitsComboBox.removeAllItems();
        availableContextsComboBox.removeAllItems();
        NoteContextRefComboBox.removeAllItems(); 
        StatementIdComboBox.removeAllItems();
        ContextAxisComboBox.removeAllItems();
        SchemaComboBox.removeAllItems();
        ContextMemberComboBox.removeAllItems();
        ISOCodeComboBox.removeAllItems();
        NonNumericElementsComboBox.removeAllItems();
        StartDate.removeAllItems();
        EndDate.removeAllItems();
        //creating a counter
        int i;  
        //loading comboboxes items
            for(i=0;i<isoCodeComboBox.size();i++){
                ISOCodeComboBox.addItem(isoCodeComboBox.elementAt(i));
            }             
            for(i=0;i<schemaComboBox.size();i++){
                SchemaComboBox.addItem(schemaComboBox.elementAt(i));
            }          
            //imposible to implement because NetBeans runs out of memory
            //for(i=0;i<siconfiCodeComboBox.length;i++){
            //     SiconfiCodeComboBox.addItem(siconfiCodeComboBox[i]);
            //}
            for(i=0;i<contextAxisComboBox.size();i++){
                ContextAxisComboBox.addItem(contextAxisComboBox.elementAt(i));
            }
            for(i=0;i<nonNumericElementsComboBox.size();i++){
                NonNumericElementsComboBox.addItem(nonNumericElementsComboBox.elementAt(i));
            }
            for(i=0;i<startDateComboBox.size();i++){
                StartDate.addItem(startDateComboBox.elementAt(i));
            } 
            for(i=0;i<endDateComboBox.size();i++){
                EndDate.addItem(endDateComboBox.elementAt(i));
            }             
    }
    public void updateReport (InstanceReport instanceReport){       
        this.instanceReport=instanceReport;
        //adding each report item to its proper combobox
        if(!this.instanceReport.contextList.isEmpty()){
            for(ContextDeclaration context : instanceReport.contextList){
                if(availableContextsComboBox.getItemCount()==0){
                    availableContextsComboBox.addItem(context.getId());
                    NoteContextRefComboBox.addItem(context.getId());
                }else{
                    boolean exist=false;
                    for(int j=0;j<availableContextsComboBox.getItemCount();j++){
                        if(context.getId().equals(availableContextsComboBox.getItemAt(j))){
                            exist=true;
                        }
                    }
                    if(!exist){
                        availableContextsComboBox.addItem(context.getId());
                        NoteContextRefComboBox.addItem(context.getId());
                    }
                }
            }
        }
        if(!this.instanceReport.unitList.isEmpty()){
            availableUnitsComboBox.removeAllItems();
            for(UnitDeclaration unit : instanceReport.unitList){            
                availableUnitsComboBox.addItem(unit.getId());
            }
        }
    }
    public void LoadAuxiliarFiles()throws IOException{
                //initializing a Buffered Reader so its possible to use the method readLine() to get the codes from the text file and to compare them with the inted one                 
                InputStream reader = getClass().getResourceAsStream("SiconfiAxis.txt");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes
                String CodeLine;                
                // loop for checking all codes within the text file                
                while ((CodeLine = bufferedReader.readLine()) != null) {
                    contextAxisComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close();
                reader = getClass().getResourceAsStream("SiconfiSchema.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                   schemaComboBox.add(CodeLine);
                }
                //closing the file reader
                reader.close();      
                reader = getClass().getResourceAsStream("IsoCode.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    isoCodeComboBox.add(CodeLine);
                }
                //closing the file reader
                reader.close(); 
                reader = getClass().getResourceAsStream("SiconfiStatementId.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    statementIdComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close(); 
                reader = getClass().getResourceAsStream("SiconfiDimension.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    contextMemberComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close();
                reader = getClass().getResourceAsStream("SiconfiNonNumeric.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    nonNumericElementsComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close();
                reader = getClass().getResourceAsStream("CoupledAxisList.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    coupledAxisList.add(CodeLine);
                }                
                //closing the file reader
                reader.close();                 
                reader = getClass().getResourceAsStream("StartDateList.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    startDateComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close();   
                reader = getClass().getResourceAsStream("EndDateList.txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes                
                // loop for checking all codes within the text file
                while ((CodeLine = bufferedReader.readLine()) != null) {                
                    endDateComboBox.add(CodeLine);
                }                
                //closing the file reader
                reader.close();                  
    }
    public void Logloader(JTextArea LogTextArea){
        this.LogTextArea = LogTextArea;        
    }
    public void CheckBoxReset () {
        if(StatementCheckBox.isSelected()){StatementCheckBox.doClick();}
        if(ContextCheckBox.isSelected()){ContextCheckBox.doClick();}
        if(UnitCheckBox.isSelected()){UnitCheckBox.doClick();}
        if(NoteCheckBox.isSelected()){NoteCheckBox.doClick();}    
    }
    public void InsertOptionUpdate(int x){
        this.InsertOption=x;        
        if (this.InsertOption==1){
            ContextCheckBox.doClick();
        }else{
            if(this.InsertOption==2){
                UnitCheckBox.doClick();
            }else{
                if(this.InsertOption==3){
                    StatementCheckBox.doClick();
                }else{
                    if(this.InsertOption==4){
                        NoteCheckBox.doClick();
                    }
                }
            }
        }
    }
    public void ContextDimensionComboBoxFiller(Vector<String> contextAxisComboBox,Vector<String> contextMemberComboBox)throws IOException{
        //each axis has a number of members dimensions so, it was necessary to implement this function to fill up the member combobox with the proper options fo each axis
        String SiconfiAxis;
        int i;
        InputStream reader;
        BufferedReader bufferedReader;
        String CodeLine;        
        if(ContextAxisComboBox.getSelectedItem()!=null){
        SiconfiAxis = ContextAxisComboBox.getSelectedItem().toString();
        for(i=0;i<contextAxisComboBox.size();i++){
            if(SiconfiAxis.equals(contextAxisComboBox.elementAt(i))){
                reader = getClass().getResourceAsStream("ContextMemberAxis"+String.valueOf(i)+".txt");
                bufferedReader = new BufferedReader(new InputStreamReader(reader));
                while ((CodeLine = bufferedReader.readLine()) != null) {
                    ContextMemberComboBox.addItem(CodeLine);
                }
                reader.close();
            }
        }
        }        
    }
    public void StatementIdComboBoxFiller(Vector<String> contextAxisComboBox,Vector<String> statementIdComboBox,InstanceReport instanceReport)throws IOException{
        this.instanceReport=instanceReport;
        //each axis has a number of members dimensions so, it was necessary to implement this function to fill up the member combobox with the proper options fo each axis
        String SiconfiAxis="";
        int i;
        InputStream reader;
        BufferedReader bufferedReader;
        String CodeLine;          
        if(availableContextsComboBox.getItemCount() != 0){
            for(ContextDeclaration context : this.instanceReport.contextList){
                if (context.getId().equals(availableContextsComboBox.getSelectedItem().toString()))
                    for(i=12;i<context.getExplicitMemberDimension().length()-4;i++){
                        SiconfiAxis=SiconfiAxis+context.getExplicitMemberDimension().charAt(i);
                    }                
            }        
        if(!SiconfiAxis.equals("")){
            for(i=0;i<contextAxisComboBox.size();i++){
                if(SiconfiAxis.equals(contextAxisComboBox.elementAt(i))){
                    reader = getClass().getResourceAsStream("StatementAxis"+String.valueOf(i)+".txt");
                    bufferedReader = new BufferedReader(new InputStreamReader(reader));
                    while ((CodeLine = bufferedReader.readLine()) != null) {
                        StatementIdComboBox.addItem(CodeLine);
                    }
                    reader.close();
                }
            }
        }
        }
    }
    
    public int ContextIndexCalc(String Id){
    int index=0;
    for(int i=0;i<contextMemberComboBox.size();i++){
        if(Id.equals(contextMemberComboBox.elementAt(i))){
            index=i;
        }
    }
    return index;
    }
    public int StatementIndexCalc(String Id){
    int index=0;
    for(int i=0;i<statementIdComboBox.size();i++){
        if(Id.equals(statementIdComboBox.elementAt(i))){
            index=i;
        }
    }
    return index;
    }
        public void LanguageSelection(String language){
        if(language.equals("EN")){
            //frame title
            this.setTitle("Element insertion manager");
            //labels
            StatementTagLabel.setText("Account tag");
            StatementCheckBox.setText("Account");
            StatementValueLabel.setText("Value");
            StatementDecimalsLabel.setText("Decimals");
            StatementUnitLabel.setText("Unit");
            StatementContextLabel.setText("Context");
            ContextIdLabel.setText("Context name");
            ContextCheckBox.setText("Context");
            SiconfiCodeLabel.setText("Institution's code");
            ContextAxisLabel.setText("Context axis");
            StartDateLabel.setText("Start date");
            EndDateLabel.setText("End date");
            SchemaLabel.setText("Schema");
            ContextDimensionLabel.setText("Context dimension");
            StartDateFormatLabel.setText("YYYY-MM-DD");
            EndDateFormatLabel.setText("YYYY-MM-DD");
            UnitNameLabel.setText("Unit name");
            ISOCodeLabel.setText("ISO code");
            UnitCheckBox.setText("Unit");
            NoteContentLabel.setText("Description");
            NoteContextRefLabel.setText("Context");
            NoteCheckBox.setText("Non numeric");
            StatementValue.setToolTipText("Do not add decimals' separators. Write 1,123.45 as 112345, for example.");
            NonNumericElementsComboBoxLabel.setText("Non numeric element tag");
            SecondaryContextAxisLabel.setText("Secondary Context Axis");
            SecondaryContextDimensionLabel.setText("Secondary Context Dimension");
            //buttons
            AddButton.setText("Add");
            CancelButton.setText("Cancel");
            //error messages
            M_Error00="This report only supports one active unit at a time.";
            M_Error01="Please, make sure to fill up all the required fields before adding an element.";
            M_Error02="Please, make sure to add a context and a unit before adding accounts.";
            M_Error03="Please, make sure to insert a valid institutional code.";
            M_Error04="Please, make sure to insert a valid period.";
            M_Error05="Please, make sure to insert a valid context name.";          
            M_Error06="Please, make sure to add a context before adding explanatory notes.";
            M_Error07="Please, also make sure you are not incurring one of the following situations: \n" +
            "1 - You tried to add an element without marking the appropriate Element type Checkbox. \n" +
            "2 - You forgot to properly fill up any field.\n" +
            "";
            M_Error18="Please, make sure to insert a valid context name.";            
            M_Error28="The Value field and the Decimals field only accepts integer numbers."+"\n"+"Please, also make sure you did not type something else in those fields."+"\n"+"Please, also make sure you are not trying to add an existing element.";
            M_Error29="The context name must be unique."+"\n"+"The Institution's code field must be a valid Siconfi's code."+"\n"+"The End date must always be ulterior to the Start date."+"\n"+"Please, also make sure you did not type something invalid in those fields."+"\n"+"Please, also make sure you are not trying to add an existing element.";            
            M_Error31="This element already exists. You can edit it through the option Edit under the Elements menu.";
            //success messages
            M_Suc01="Element successfully added.";
            //JOptionPane
            jopTitle="WARN";
        }else{
            if(language.equals("PT")){
                //frame title
                this.setTitle("Gerenciador de inserção de elementos");
                //labels
                StatementTagLabel.setText("Tag da conta");
                StatementCheckBox.setText("Conta");
                StatementValueLabel.setText("Valor");
                StatementDecimalsLabel.setText("Decimais");
                StatementUnitLabel.setText("Unidade");
                StatementContextLabel.setText("Contexto");
                ContextIdLabel.setText("Nome do contexto");
                ContextCheckBox.setText("Contexto");
                SiconfiCodeLabel.setText("Código da Instituição");
                ContextAxisLabel.setText("Eixo do contexto");
                StartDateLabel.setText("Início");
                EndDateLabel.setText("Término");
                SchemaLabel.setText("Schema");
                ContextDimensionLabel.setText("Dimensão do contexto");
                StartDateFormatLabel.setText("AAAA-MM-DD");
                EndDateFormatLabel.setText("AAAA-MM-DD");
                UnitNameLabel.setText("Nome da unidade");
                ISOCodeLabel.setText("Código ISO");
                UnitCheckBox.setText("Unidade");
                NoteContentLabel.setText("Descrição");
                NoteContextRefLabel.setText("Contexto");
                NoteCheckBox.setText("Não numérico");
                StatementValue.setToolTipText("Não adicione separadores decimais. Escreva 1.123,45 como 112345, por exemplo.");
                NonNumericElementsComboBoxLabel.setText("Tag do elemento não numérico");
                SecondaryContextAxisLabel.setText("Eixo secundário do contexto");
                SecondaryContextDimensionLabel.setText("Dimensão secundária do contexto");                
                //buttons
                AddButton.setText("Adicionar");
                CancelButton.setText("Cancelar");
                //error messages
                M_Error00="Este relatório suporta apenas uma unidade ativa por vez.";
                M_Error01="Por favor, certifique-se de ter preenchido todos os compos requeridos antes de adicionar um elemento.";
                M_Error02="Por favor, certifique-se de adicionar um contexto e uma unidade antes de adicionar uma conta.";
                M_Error03="Por favor, certifique-se de inserir um código institucional válido.";
                M_Error04="Por favor, certifique-se de inserir um período válido.";
                M_Error05="Por favor, certifique-se de inserir um nome de contexto válido.";                
                M_Error06="Por favor, certifique-se de inserir um contexto antes de adicionar uma nota explicativa.";
                M_Error07="Por favor, também certifique-se que nenhuma das seguintes situações está ocorrendo: \n" +
                "1 - Você tentou adicionar um elemento sem marcar a checkbox apropriada ao tipo de elemento. \n" +
                "2 - Você preencheu algum campo inadequadamente.\n" +
                "";
                M_Error18="Por favor, certifique-se de inserir um nome de contexto válido.";
                M_Error28="Os campos Valor e Decimais aceitam apenas números inteiros."+"\n"+"Por favor, certifique-se de não ter digitado algo mais nesses campos"+"\n"+"Por favor, também certifique-se de não estar tentando inserir um elemento existente.";
                M_Error29="O nome de um contexto de ve ser único"+"\n"+"O campo Código da instituição deve ser válido de acordo com a relação de códigos do Siconfi."+"\n"+"O término do período deve ser sempre ulterior ao seu início."+"\n"+"Por favor, certifique-se de não ter digitado algo inválido nesses campos."+"\n"+"Por favor, também certifique-se de não estar tentando inserir um elemento existente.";                            
                M_Error31="Este elemento já existe. Você pode editá-lo através da opção Editar no menu Elementos.";
                //success messages
                M_Suc01="Elemento adicionado com sucesso.";
                //JOptionPane
                jopTitle="AVISO";
            }else{
                //frame title
                this.setTitle("Gestor de inserción de elementos");
                //labels
                StatementTagLabel.setText("Etiqueta de cuenta");
                StatementCheckBox.setText("Cuenta");
                StatementValueLabel.setText("Valor");
                StatementDecimalsLabel.setText("Decimales");
                StatementUnitLabel.setText("Unidad de valor");
                StatementContextLabel.setText("Contexto");
                ContextIdLabel.setText("Nombre de contexto");
                ContextCheckBox.setText("Contexto");
                SiconfiCodeLabel.setText("Código de la institución");
                ContextAxisLabel.setText("Eje de contexto");
                StartDateLabel.setText("Fecha de inicio");
                EndDateLabel.setText("Fecha final");
                SchemaLabel.setText("Schema");
                ContextDimensionLabel.setText("Dimensión de contexto");
                StartDateFormatLabel.setText("AAAA-MM-DD");
                EndDateFormatLabel.setText("AAAA-MM-DD");
                UnitNameLabel.setText("Código de la unidad de valor");
                ISOCodeLabel.setText("Código ISO");
                UnitCheckBox.setText("Unidad de valor");
                NoteContentLabel.setText("Descripción");
                NoteContextRefLabel.setText("Contexto");
                NoteCheckBox.setText("No numérico");
                StatementValue.setToolTipText("No agregue separadores de decimales. Escriba 1,123.45 como 112345, por ejemplo.");
                NonNumericElementsComboBoxLabel.setText("Etiqueta de elemento no numérico");
                SecondaryContextAxisLabel.setText("Eje de contexto secundario");
                SecondaryContextDimensionLabel.setText("Dimensión de contexto secundaria");                
                //buttons
                AddButton.setText("Añadir");
                CancelButton.setText("Cancelar");
                //error messages
                M_Error00="Este informe solo admite una unidad de valor activa a la vez.";
                M_Error01="Por favor, asegúrese de completar todos los campos obligatorios antes de agregar un elemento.";
                M_Error02="Por favor, asegúrese de agregar un contexto y una unidad antes de agregar estados financieros.";
                M_Error03="Por favor, asegúrese de insertar un código institucional válido.";
                M_Error04="Por favor, asegúrese de insertar un período válido.";
                M_Error05="Por favor, asegúrese de insertar un nombre de contexto válido.";          
                M_Error06="Por favor, asegúrese de agregar un contexto antes de agregar notas explicativas.";
                M_Error07="Por favor, asegúrese también de no estar incurriendo en una de las siguientes situaciones: \n" +
                "1 - Intentó agregar un elemento sin marcar la casilla de verificación del tipo de elemento correspondiente. \n" +
                "2 - Olvidó completar correctamente cualquier campo.\n" +
                "";
                M_Error18="Por favor, asegúrese de insertar un nombre de contexto válido.";
                M_Error28="El campo Valor y el campo Decimales solo aceptan números enteros."+"\n"+"Por favor, asegúrese de no escribir nada más en esos campos."+"\n"+"Por favor, asegúrese también de que no está intentando agregar un elemento existente.";
                M_Error29="El nombre del contexto debe ser exclusivo."+"\n"+"El campo del código de la institución debe ser un código válido de Siconfi."+"\n"+"La fecha de finalización siempre debe ser posterior a la fecha de inicio."+"\n"+"Por favor, asegúrese de no escribir algo no válido en esos campos."+"\n"+"Por favor, asegúrese también de que no está intentando agregar un elemento existente.";                                            
                M_Error31="Este elemento ya existe. Puede editarlo a través de la opción Editar en el menú Elementos.";
                //success messages
                M_Suc01="Elemento agregado correctamente.";
                //JOptionPane
                jopTitle="ADVERTENCIA";
            }            
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AddButton = new javax.swing.JButton();
        StatementCheckBox = new javax.swing.JCheckBox();
        ContextCheckBox = new javax.swing.JCheckBox();
        UnitCheckBox = new javax.swing.JCheckBox();
        NoteCheckBox = new javax.swing.JCheckBox();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        StatementValueLabel = new javax.swing.JLabel();
        CancelButton = new javax.swing.JButton();
        ISOCodeComboBox = new javax.swing.JComboBox<>();
        UnitId = new javax.swing.JTextField();
        UnitNameLabel = new javax.swing.JLabel();
        ISOCodeLabel = new javax.swing.JLabel();
        StatementIdComboBox = new javax.swing.JComboBox<>();
        availableUnitsComboBox = new javax.swing.JComboBox<>();
        availableContextsComboBox = new javax.swing.JComboBox<>();
        StatementTagLabel = new javax.swing.JLabel();
        StatementDecimalsLabel = new javax.swing.JLabel();
        StatementUnitLabel = new javax.swing.JLabel();
        StatementContextLabel = new javax.swing.JLabel();
        ContextIdLabel = new javax.swing.JLabel();
        ContextId = new javax.swing.JTextField();
        ContextAxisComboBox = new javax.swing.JComboBox<>();
        ContextMemberComboBox = new javax.swing.JComboBox<>();
        SchemaComboBox = new javax.swing.JComboBox<>();
        SiconfiCodeLabel = new javax.swing.JLabel();
        ContextDimensionLabel = new javax.swing.JLabel();
        ContextAxisLabel = new javax.swing.JLabel();
        SchemaLabel = new javax.swing.JLabel();
        StartDateLabel = new javax.swing.JLabel();
        EndDateLabel = new javax.swing.JLabel();
        StartDateFormatLabel = new javax.swing.JLabel();
        EndDateFormatLabel = new javax.swing.JLabel();
        NoteContentLabel = new javax.swing.JLabel();
        NoteContextRefLabel = new javax.swing.JLabel();
        NoteContextRefComboBox = new javax.swing.JComboBox<>();
        SiconfiCodeTextBox = new javax.swing.JTextField();
        StatementValue = new javax.swing.JTextField();
        StatementDecimals = new javax.swing.JTextField();
        NonNumericElementsComboBox = new javax.swing.JComboBox<>();
        NonNumericElementsComboBoxLabel = new javax.swing.JLabel();
        NoteContent = new javax.swing.JTextField();
        SecondaryContextAxisLabel = new javax.swing.JLabel();
        SecondaryContextAxisComboBox = new javax.swing.JComboBox<>();
        SecondaryContextDimensionLabel = new javax.swing.JLabel();
        SecondaryContextDimensionComboBox = new javax.swing.JComboBox<>();
        StartDate = new javax.swing.JComboBox<>();
        EndDate = new javax.swing.JComboBox<>();

        setTitle("Element insertion manager");
        setPreferredSize(new java.awt.Dimension(765, 620));

        AddButton.setText("Add");
        AddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddButtonActionPerformed(evt);
            }
        });

        StatementCheckBox.setText("Statement");
        StatementCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StatementCheckBoxActionPerformed(evt);
            }
        });

        ContextCheckBox.setText("Context");
        ContextCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContextCheckBoxActionPerformed(evt);
            }
        });

        UnitCheckBox.setText("Unit");
        UnitCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UnitCheckBoxActionPerformed(evt);
            }
        });

        NoteCheckBox.setText("Explanatory note");
        NoteCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoteCheckBoxActionPerformed(evt);
            }
        });

        StatementValueLabel.setText("Value");

        CancelButton.setText("Cancel");
        CancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });

        ISOCodeComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        UnitNameLabel.setText("Unit name");

        ISOCodeLabel.setText("ISO code");

        StatementIdComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        availableUnitsComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        availableContextsComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        availableContextsComboBox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                availableContextsComboBoxMouseClicked(evt);
            }
        });
        availableContextsComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                availableContextsComboBoxActionPerformed(evt);
            }
        });

        StatementTagLabel.setText("Statement tag");

        StatementDecimalsLabel.setText("Decimals");

        StatementUnitLabel.setText("Unit");

        StatementContextLabel.setText("Context");

        ContextIdLabel.setText("Context name");

        ContextAxisComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ContextAxisComboBox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ContextAxisComboBoxMouseClicked(evt);
            }
        });
        ContextAxisComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContextAxisComboBoxActionPerformed(evt);
            }
        });

        ContextMemberComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ContextMemberComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContextMemberComboBoxActionPerformed(evt);
            }
        });

        SchemaComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        SiconfiCodeLabel.setText("Institution's code");

        ContextDimensionLabel.setText("Context Dimension");

        ContextAxisLabel.setText("Context Axis");

        SchemaLabel.setText("Schema");

        StartDateLabel.setText("Start date");

        EndDateLabel.setText("End date");

        StartDateFormatLabel.setText("YYYY-MM-DD");

        EndDateFormatLabel.setText("YYYY-MM-DD");

        NoteContentLabel.setText("Note");

        NoteContextRefLabel.setText("Context");

        NoteContextRefComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        NonNumericElementsComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        NonNumericElementsComboBoxLabel.setText("Non numeric element tag");

        SecondaryContextAxisLabel.setText("Secondary Context Axis");

        SecondaryContextAxisComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        SecondaryContextDimensionLabel.setText("Secondary Context Dimension");

        SecondaryContextDimensionComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        StartDate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        EndDate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(CancelButton)
                .addGap(18, 18, 18)
                .addComponent(AddButton)
                .addGap(49, 49, 49))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator3))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(StatementCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(StatementTagLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 569, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(StatementIdComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(StatementValueLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(StatementValue, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(StatementDecimalsLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(StatementDecimals, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(StatementUnitLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(availableUnitsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(StatementContextLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(availableContextsComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(NoteCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(NoteContextRefComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(NoteContextRefLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NonNumericElementsComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(NoteContent)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(NoteContentLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(NonNumericElementsComboBoxLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(UnitCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(UnitId, javax.swing.GroupLayout.PREFERRED_SIZE, 408, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(UnitNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(ISOCodeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ISOCodeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jSeparator2)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 724, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1)))))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(SecondaryContextAxisComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(ContextCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(ContextIdLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(ContextId)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(StartDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(StartDate, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(EndDateFormatLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(EndDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(EndDate, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(StartDateFormatLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(16, 16, 16)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(SchemaComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(SchemaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(SiconfiCodeLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(SiconfiCodeTextBox, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(SecondaryContextAxisLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ContextAxisLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(ContextDimensionLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(SecondaryContextDimensionLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(ContextMemberComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, 311, Short.MAX_VALUE)
                                        .addComponent(SecondaryContextDimensionComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(ContextAxisComboBox, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ContextCheckBox, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SiconfiCodeLabel)
                            .addComponent(ContextAxisLabel)
                            .addComponent(ContextIdLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ContextId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ContextAxisComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SiconfiCodeTextBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ContextDimensionLabel)
                    .addComponent(SchemaLabel)
                    .addComponent(StartDateLabel)
                    .addComponent(EndDateLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ContextMemberComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SchemaComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StartDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EndDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StartDateFormatLabel)
                    .addComponent(EndDateFormatLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SecondaryContextAxisLabel)
                    .addComponent(SecondaryContextDimensionLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SecondaryContextAxisComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SecondaryContextDimensionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ISOCodeLabel)
                    .addComponent(UnitNameLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(UnitCheckBox)
                    .addComponent(UnitId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ISOCodeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(StatementTagLabel)
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StatementIdComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StatementCheckBox))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StatementValueLabel)
                    .addComponent(StatementDecimalsLabel)
                    .addComponent(StatementUnitLabel)
                    .addComponent(StatementContextLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(availableUnitsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(availableContextsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StatementValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StatementDecimals, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(NonNumericElementsComboBoxLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NoteCheckBox)
                    .addComponent(NonNumericElementsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NoteContextRefLabel)
                    .addComponent(NoteContentLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NoteContextRefComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NoteContent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddButton)
                    .addComponent(CancelButton))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddButtonActionPerformed
        // TODO add your handling code here:
        //This button adds instance elements to the report, as long as they sucessfuly go through the validation steps below
        //Boolean variable to verify if the element is valid and if the app shall dispose the window
        boolean IsElementValid = false;
        boolean fault=false;
        boolean repeated = false;
        boolean alreadyExistis = false;
        int repetitionCheckerIndex=0-5;
        char valueComparator;
        //Checking for financial statement insertion validity
        if(StatementCheckBox.isSelected()){
            //Checking for previously added context and unit
            if(!instanceReport.contextList.isEmpty()&&!instanceReport.unitList.isEmpty()){
                
                for(int j=0;j<StatementValue.getText().length();j++){
                    valueComparator=StatementValue.getText().charAt(j);                    
                    if((((((((((valueComparator!='0')&&(valueComparator!='1'))&&(valueComparator!='2'))&&(valueComparator!='3'))&&(valueComparator!='4'))&&(valueComparator!='5'))&&(valueComparator!='6'))&&(valueComparator!='7'))&&(valueComparator!='8'))&&(valueComparator!='9')){
                         fault=true;
                    }
                }
                if(!fault){
                    String statementId = StatementIdComboBox.getSelectedItem().toString();
                    String statementContextReference = availableContextsComboBox.getSelectedItem().toString();
                    String statementUnitReference = availableUnitsComboBox.getSelectedItem().toString();
                    String statementValue =StatementValue.getText();
                    String statementDecimals =StatementDecimals.getText();
                    if(statementValue.length()<=Integer.valueOf(statementDecimals)){
                        int j = statementValue.length();
                        for(int k = j;k<=Integer.valueOf(statementDecimals);k++){
                            statementValue="0"+statementValue;
                        }
                        System.out.println(statementValue);
                    }
                    StatementDeclaration statement= new StatementDeclaration(StatementIndexCalc(statementId),statementId,statementContextReference,statementDecimals,statementUnitReference,statementValue.substring(0, statementValue.length()-Integer.valueOf(statementDecimals))+"."+statementValue.substring(statementValue.length()-Integer.valueOf(statementDecimals)));
                    //Checking for blank value and decimal precision
                    if(StatementDecimals.getText().equals("")||StatementValue.getText().equals("")){
                        JOptionPane.showMessageDialog(this,M_Error01,jopTitle,JOptionPane.WARNING_MESSAGE);
                    }else{                        
                        if(instanceReport.statementList.isEmpty()){
                            //then it is a valid statement
                            instanceReport.addStatement(statement);
                            IsElementValid = true;
                        }else{
                            for(StatementDeclaration s : instanceReport.statementList){
                                if((s.getContextRef().equals(statement.getContextRef())&&s.getId().equals(statement.getId()))&&s.getUnitRef().equals(statement.getUnitRef())){
                                    repeated = true;
                                }
                            }
                            if(!repeated){
                                //then it is a valid statement
                                instanceReport.addStatement(statement);
                                IsElementValid = true;
                            }else{
                                //JOptionPane.showMessageDialog(null,M_Error31,jopTitle,JOptionPane.WARNING_MESSAGE);
                            }
                        }
                    }                   
                }                                
            }else{
                JOptionPane.showMessageDialog(this,M_Error02,jopTitle,JOptionPane.WARNING_MESSAGE);
            }            
        }
        //Checking for context insertion validity
        if(ContextCheckBox.isSelected()){
            //Gathering context elements
            String SiconfiCode = SiconfiCodeTextBox.getText().toUpperCase();
            String ContextSchema = SchemaComboBox.getSelectedItem().toString();
            String SiconfiAxis = ContextAxisComboBox.getSelectedItem().toString();
            String SiconfiDimension = ContextMemberComboBox.getSelectedItem().toString();      
            ContextDeclaration context = new ContextDeclaration(ContextIndexCalc(SiconfiDimension),ContextId.getText().toUpperCase().replace(" ",""),SiconfiCode,ContextSchema,SiconfiAxis,SiconfiDimension,StartDate.getSelectedItem().toString(),EndDate.getSelectedItem().toString());
            if(SecondaryContextAxisComboBox.isEnabled()){
                context.setHasCoupledAxis(true);
                context.setSecondaryExplicitMemberDimension(SecondaryContextAxisComboBox.getSelectedItem().toString());
                context.setSecondarySiconfiDimension(SecondaryContextDimensionComboBox.getSelectedItem().toString());
            } 
            //It was not possible to load the 11000 codes as an array for a combobox, so I had to put them into a text file and serach for them every time the user adds a context.
            
            //creating a boolean variable to check if the inserted context's institution belongs to Siconfi's table 
            boolean ContextInstitutionIndexFound=false;           
            try {
                //initializing a Buffered Reader so its possible to use the method readLine() to get the codes from the text file and to compare them with the inted one  
                InputStream reader = getClass().getResourceAsStream("SiconfiEntityCode.txt");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(reader));               
                // variable for storing the retrived codes
                String CodeLine;                
                // loop for checking all codes within the text file 
                while ((CodeLine = bufferedReader.readLine()) != null) {
                    // checking if there is an equivalent code...
                    if(SiconfiCode.equals(CodeLine)){
                        ContextInstitutionIndexFound=true;
                    }
                }
                //closing the file reader
                reader.close();
                
                //creating a boolean variable to check if the inserted context's period is valid
                boolean ContextPeriodValid=false;
                if(!EndDate.getSelectedItem().toString().equals("")&&!StartDate.getSelectedItem().toString().equals("")){
                    // creating two string to sore and process the dates the user typed in
                    String OlderDate,NewerDate;
                    OlderDate=EndDate.getSelectedItem().toString().substring(0,4)+EndDate.getSelectedItem().toString().substring(5,7)+EndDate.getSelectedItem().toString().substring(8,10);
                    NewerDate=StartDate.getSelectedItem().toString().substring(0,4)+StartDate.getSelectedItem().toString().substring(5,7)+StartDate.getSelectedItem().toString().substring(8,10);
                    //check if the informed dates describe a valid period
                    if(Integer.valueOf(OlderDate)>Integer.valueOf(NewerDate)){
                        ContextPeriodValid=true;                    
                    }
                }
                //Overall context validity check
                if(!ContextInstitutionIndexFound){
                    // if there is no equivalent code...
                    JOptionPane.showMessageDialog(this,M_Error03,jopTitle,JOptionPane.WARNING_MESSAGE);                    
                }else{
                    //if the period is valid...
                    if(!ContextPeriodValid){
                        JOptionPane.showMessageDialog(this,M_Error04,jopTitle,JOptionPane.WARNING_MESSAGE);
                    }else{
                       //if the context id is not blank
                       if(ContextId.getText().equals("")){
                           //JOptionPane.showMessageDialog(null,M_Error05,jopTitle,JOptionPane.WARNING_MESSAGE);
                       }else{
                           if(instanceReport.contextList.isEmpty()){
                               //then it is a valid context
                               //adding context element
                               instanceReport.addContext(context);
                               IsElementValid = true;                               
                           }else{
                               boolean exist=false;
                               for(ContextDeclaration contextElement:instanceReport.contextList){
                                   if(contextElement.getId().equals(context.getId())){
                                       exist=true;
                                   }
                                   if(contextElement.getEntityIdentifier().equals(context.getEntityIdentifier())){
                                        if(contextElement.getExplicitMemberDimension().equals(context.getExplicitMemberDimension())){
                                           if(contextElement.getSiconfiDimension().equals(context.getSiconfiDimension())){
                                             if(contextElement.getHasCoupledAxis()){
                                                 if(contextElement.getSecondaryExplicitMemberDimension().equals(context.getSecondaryExplicitMemberDimension())){
                                                     if(contextElement.getSecondarySiconfiDimension().equals(context.getSecondarySiconfiDimension())){
                                                         if(contextElement.getPeriodStartDate().equals(context.getPeriodStartDate())){
                                                              if(contextElement.getPeriodEndDate().equals(context.getPeriodEndDate())){
                                                                  if(repetitionCheckerIndex!=instanceReport.contextList.indexOf(context)){
                                                                      alreadyExistis=true;
                                                                    }
                                                                }
                                                            }                                                     
                                                        }
                                                    }
                                                }else{
                                                  if(contextElement.getPeriodStartDate().equals(context.getPeriodStartDate())){
                                                      if(contextElement.getPeriodEndDate().equals(context.getPeriodEndDate())){
                                                          if(repetitionCheckerIndex!=instanceReport.contextList.indexOf(context)){
                                                              alreadyExistis=true;
                                                            }
                                                        }
                                                    }
                                                }  
                                            }    
                                        }
                                    }                                    
                               }
                               if(exist||alreadyExistis){
                                   //JOptionPane.showMessageDialog(null,M_Error18,jopTitle,JOptionPane.WARNING_MESSAGE);
                               }else{                                 
                                   //then it is a valid context
                                   //adding context element
                                   instanceReport.addContext(context);
                                   IsElementValid = true;                                
                               }
                           }
                       }
                    }
                }                
            } catch (IOException e) {
                e.printStackTrace();
            }                        
        }         
        //Checking for unit insertion validity
        if(UnitCheckBox.isSelected()){            
            //Gathering context elements
            String IsoCode = ISOCodeComboBox.getSelectedItem().toString();
            UnitDeclaration unit = new UnitDeclaration(UnitId.getText().toUpperCase().replace(" ",""),IsoCode);
            //cheking for blank unit id
            if(!UnitId.getText().equals("")){
                if(instanceReport.unitList.isEmpty()){
                    //then it is a valid unit
                    //adding unit element 
                    instanceReport.addUnit(unit);
                    IsElementValid = true;                
                }else{
                    JOptionPane.showMessageDialog(this,M_Error00,jopTitle,JOptionPane.WARNING_MESSAGE);
                }                
            }else{
                JOptionPane.showMessageDialog(this,M_Error01,jopTitle,JOptionPane.WARNING_MESSAGE);
            }            
        }
        //Checking for explanatory note insertion validity
        if(NoteCheckBox.isSelected()){            
            for(int k=0;k<nonNumericElementsComboBox.size();k++){
                if(NonNumericElementsComboBox.getSelectedItem().toString().equals(nonNumericElementsComboBox.elementAt(k))){
                //Checking for previously added context
                if(!instanceReport.contextList.isEmpty()){
                    //cheking for blank note content
                    if(!NoteContent.getText().equals("")){
                        //Gathering explanatory note elements
                        String noteContextRef = NoteContextRefComboBox.getSelectedItem().toString();                     
                        //adding explanatory note element                  
                        instanceReport.addNote(new NonNumericDeclaration(noteContextRef,NoteContent.getText(),NonNumericElementsComboBox.getSelectedItem().toString()));
                        IsElementValid = true;
                    }
                }else{
                JOptionPane.showMessageDialog(this,M_Error06,jopTitle,JOptionPane.WARNING_MESSAGE);
                }
                }
            }
        }
        // If somehow the user did not provide a valid input...
        if(!IsElementValid){
            if(StatementCheckBox.isSelected()){
                JOptionPane.showMessageDialog(this,M_Error28,jopTitle,JOptionPane.WARNING_MESSAGE);
            }else{
                if(ContextCheckBox.isSelected()){                
                    JOptionPane.showMessageDialog(this,M_Error29,jopTitle,JOptionPane.WARNING_MESSAGE);
                }else{
                    JOptionPane.showMessageDialog(this,M_Error07,jopTitle,JOptionPane.WARNING_MESSAGE);
                }
            }            
        }        
        // This window is only disposed after a successful element insertion        
        if(IsElementValid){
            LogTextArea.setText(LogTextArea.getText()+"\n"+M_Suc01);
            this.dispose();            
        }                                    
    }//GEN-LAST:event_AddButtonActionPerformed

    private void CancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelButtonActionPerformed
        // TODO add your handling code here:
        InsertOptionUpdate(InsertOption);
        this.setVisible(false);
        if(StatementCheckBox.isSelected()){StatementCheckBox.doClick();}
        if(ContextCheckBox.isSelected()){ContextCheckBox.doClick();}
        if(UnitCheckBox.isSelected()){UnitCheckBox.doClick();}
        if(NoteCheckBox.isSelected()){NoteCheckBox.doClick();}
    }//GEN-LAST:event_CancelButtonActionPerformed

    private void StatementCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StatementCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(StatementCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        ContextCheckBox.setEnabled(state);
        ContextId.setEnabled(state);
        SiconfiCodeTextBox.setEnabled(state);
        ContextAxisComboBox.setEnabled(state);
        StartDate.setEnabled(state);
        EndDate.setEnabled(state);
        SchemaComboBox.setEnabled(state);
        ContextMemberComboBox.setEnabled(state);
        UnitCheckBox.setEnabled(state);
        UnitId.setEnabled(state);
        ISOCodeComboBox.setEnabled(state);
        NoteCheckBox.setEnabled(state);
        NoteContextRefComboBox.setEnabled(state);
        NoteContent.setEnabled(state);
        NonNumericElementsComboBox.setEnabled(state);
        SecondaryContextAxisComboBox.setEnabled(false);
        SecondaryContextDimensionComboBox.setEnabled(false);
    }//GEN-LAST:event_StatementCheckBoxActionPerformed

    private void ContextCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContextCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(ContextCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        StatementCheckBox.setEnabled(state);
        StatementIdComboBox.setEnabled(state);
        StatementValue.setEnabled(state);
        StatementDecimals.setEnabled(state);
        availableUnitsComboBox.setEnabled(state);
        availableContextsComboBox.setEnabled(state);
        UnitCheckBox.setEnabled(state);
        UnitId.setEnabled(state);
        ISOCodeComboBox.setEnabled(state);
        NoteCheckBox.setEnabled(state);
        NoteContextRefComboBox.setEnabled(state);
        NoteContent.setEnabled(state);
        NonNumericElementsComboBox.setEnabled(state);
    }//GEN-LAST:event_ContextCheckBoxActionPerformed

    private void UnitCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UnitCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(UnitCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        StatementCheckBox.setEnabled(state);
        StatementIdComboBox.setEnabled(state);
        StatementValue.setEnabled(state);
        StatementDecimals.setEnabled(state);
        availableUnitsComboBox.setEnabled(state);
        availableContextsComboBox.setEnabled(state);
        ContextCheckBox.setEnabled(state);
        ContextId.setEnabled(state);
        SiconfiCodeTextBox.setEnabled(state);
        ContextAxisComboBox.setEnabled(state);
        StartDate.setEnabled(state);
        EndDate.setEnabled(state);
        SchemaComboBox.setEnabled(state);
        ContextMemberComboBox.setEnabled(state);
        NoteCheckBox.setEnabled(state);
        NoteContextRefComboBox.setEnabled(state);
        NoteContent.setEnabled(state); 
        NonNumericElementsComboBox.setEnabled(state);
        SecondaryContextAxisComboBox.setEnabled(false);
        SecondaryContextDimensionComboBox.setEnabled(false);
    }//GEN-LAST:event_UnitCheckBoxActionPerformed

    private void NoteCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoteCheckBoxActionPerformed
        // TODO add your handling code here:
        //The software only provides entry for one element at a time, so its necessary to prevent the user to use components that are not related tho the element he/she is trying to add
        boolean state;
        if(NoteCheckBox.isSelected()){
        state=false;      
        }else{
        state=true;
        }
        StatementCheckBox.setEnabled(state);
        StatementIdComboBox.setEnabled(state);
        StatementValue.setEnabled(state);
        StatementDecimals.setEnabled(state);
        availableUnitsComboBox.setEnabled(state);
        availableContextsComboBox.setEnabled(state);
        ContextCheckBox.setEnabled(state);
        ContextId.setEnabled(state);
        SiconfiCodeTextBox.setEnabled(state);
        ContextAxisComboBox.setEnabled(state);
        StartDate.setEnabled(state);
        EndDate.setEnabled(state);
        SchemaComboBox.setEnabled(state);
        ContextMemberComboBox.setEnabled(state);
        UnitCheckBox.setEnabled(state);
        UnitId.setEnabled(state);
        ISOCodeComboBox.setEnabled(state);   
        SecondaryContextAxisComboBox.setEnabled(false);
        SecondaryContextDimensionComboBox.setEnabled(false);
    }//GEN-LAST:event_NoteCheckBoxActionPerformed

    private void ContextMemberComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContextMemberComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContextMemberComboBoxActionPerformed

    private void ContextAxisComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContextAxisComboBoxActionPerformed
        // TODO add your handling code here:
        Vector<String> axisList = new Vector<String>();
        boolean thereIsCoupledAxis=false;        
        int i, j;
        String CodeLine,CodeLine1;
        InputStream reader;
        BufferedReader bufferedReader;
        ContextMemberComboBox.removeAllItems();
        SecondaryContextAxisComboBox.removeAllItems();
        SecondaryContextDimensionComboBox.removeAllItems();
        axisList.removeAllElements();
        try{
            ContextDimensionComboBoxFiller(contextAxisComboBox,contextMemberComboBox);
            if(ContextAxisComboBox.getItemCount()!=0){
            for(i=0;i<coupledAxisList.size();i++){                
                if(ContextAxisComboBox.getSelectedItem().toString().equals(coupledAxisList.elementAt(i))){
                   thereIsCoupledAxis=true;
                   reader = getClass().getResourceAsStream("SecondarySiconfiAxis"+String.valueOf(i)+".txt");
                   bufferedReader = new BufferedReader(new InputStreamReader(reader));
                   while ((CodeLine = bufferedReader.readLine()) != null) {
                       SecondaryContextAxisComboBox.addItem(CodeLine);
                       axisList.add(CodeLine);
                   }
                   reader.close();
                   for (j=0;j<SecondaryContextAxisComboBox.getItemCount();j++){
                       if(SecondaryContextAxisComboBox.getSelectedItem().toString().equals(axisList.elementAt(j))){
                           reader = getClass().getResourceAsStream("SecondaryContextMember"+String.valueOf(j)+"Axis"+String.valueOf(i)+".txt");
                           bufferedReader = new BufferedReader(new InputStreamReader(reader));
                           while ((CodeLine1 = bufferedReader.readLine()) != null) {
                               SecondaryContextDimensionComboBox.addItem(CodeLine1);
                            }
                           reader.close();                           
                       }
                   } 
                }
            }
            if(thereIsCoupledAxis){
                SecondaryContextAxisComboBox.setEnabled(true);
                SecondaryContextDimensionComboBox.setEnabled(true);
            }else{
                SecondaryContextAxisComboBox.setEnabled(false);
                SecondaryContextDimensionComboBox.setEnabled(false);
            }
            }
        }catch(Exception e){}
    }//GEN-LAST:event_ContextAxisComboBoxActionPerformed

    private void availableContextsComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_availableContextsComboBoxActionPerformed
        // TODO add your handling code here:
        StatementIdComboBox.removeAllItems();        
        try{StatementIdComboBoxFiller(contextAxisComboBox,statementIdComboBox,instanceReport);}catch(Exception e){}
        
    }//GEN-LAST:event_availableContextsComboBoxActionPerformed

    private void ContextAxisComboBoxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ContextAxisComboBoxMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ContextAxisComboBoxMouseClicked

    private void availableContextsComboBoxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_availableContextsComboBoxMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_availableContextsComboBoxMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddButton;
    private javax.swing.JButton CancelButton;
    private javax.swing.JComboBox<String> ContextAxisComboBox;
    private javax.swing.JLabel ContextAxisLabel;
    private javax.swing.JCheckBox ContextCheckBox;
    private javax.swing.JLabel ContextDimensionLabel;
    private javax.swing.JTextField ContextId;
    private javax.swing.JLabel ContextIdLabel;
    private javax.swing.JComboBox<String> ContextMemberComboBox;
    private javax.swing.JComboBox<String> EndDate;
    private javax.swing.JLabel EndDateFormatLabel;
    private javax.swing.JLabel EndDateLabel;
    private javax.swing.JComboBox<String> ISOCodeComboBox;
    private javax.swing.JLabel ISOCodeLabel;
    private javax.swing.JComboBox<String> NonNumericElementsComboBox;
    private javax.swing.JLabel NonNumericElementsComboBoxLabel;
    private javax.swing.JCheckBox NoteCheckBox;
    private javax.swing.JTextField NoteContent;
    private javax.swing.JLabel NoteContentLabel;
    private javax.swing.JComboBox<String> NoteContextRefComboBox;
    private javax.swing.JLabel NoteContextRefLabel;
    private javax.swing.JComboBox<String> SchemaComboBox;
    private javax.swing.JLabel SchemaLabel;
    private javax.swing.JComboBox<String> SecondaryContextAxisComboBox;
    private javax.swing.JLabel SecondaryContextAxisLabel;
    private javax.swing.JComboBox<String> SecondaryContextDimensionComboBox;
    private javax.swing.JLabel SecondaryContextDimensionLabel;
    private javax.swing.JLabel SiconfiCodeLabel;
    private javax.swing.JTextField SiconfiCodeTextBox;
    private javax.swing.JComboBox<String> StartDate;
    private javax.swing.JLabel StartDateFormatLabel;
    private javax.swing.JLabel StartDateLabel;
    private javax.swing.JCheckBox StatementCheckBox;
    private javax.swing.JLabel StatementContextLabel;
    private javax.swing.JTextField StatementDecimals;
    private javax.swing.JLabel StatementDecimalsLabel;
    private javax.swing.JComboBox<String> StatementIdComboBox;
    private javax.swing.JLabel StatementTagLabel;
    private javax.swing.JLabel StatementUnitLabel;
    private javax.swing.JTextField StatementValue;
    private javax.swing.JLabel StatementValueLabel;
    private javax.swing.JCheckBox UnitCheckBox;
    private javax.swing.JTextField UnitId;
    private javax.swing.JLabel UnitNameLabel;
    private javax.swing.JComboBox<String> availableContextsComboBox;
    private javax.swing.JComboBox<String> availableUnitsComboBox;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    // End of variables declaration//GEN-END:variables
}
