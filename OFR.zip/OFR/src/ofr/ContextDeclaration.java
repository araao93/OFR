/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ofr;
/**
 *
 * @author anton
 */
public class ContextDeclaration {
  private int index;
  private String id;
  private String entityIdentifier;
  private String entityScheme;
  private String explicitMemberDimension;
  private String siconfiDimension;
  private String periodStartDate;
  private String periodEndDate;
  private String secondaryExplicitMemberDimension;
  private String secondarySiconfiDimension;
  private boolean hasCoupledAxis=false;
    public ContextDeclaration(int index,String id,String entityIdentifier,String entityScheme,String explicitMemberDimension,String siconfiDimension,String periodStartDate,String periodEndDate){
    this.index=index;
    this.id=id;
    this.entityIdentifier=entityIdentifier;
    this.entityScheme=entityScheme;
    this.explicitMemberDimension="siconfi-dim:"+explicitMemberDimension+"Axis";
    this.siconfiDimension="siconfi-dim:"+siconfiDimension+"Member";
    this.periodStartDate=periodStartDate;
    this.periodEndDate=periodEndDate;
    }
    public int getIndex() {
        return index;
    }
    public void setIndex(int index) {
        this.index = index;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getEntityIdentifier() {
        return entityIdentifier;
    }
    public void seteEntityIdentifier(String entityIdentifier) {
        this.entityIdentifier = entityIdentifier;
    }
    public String getEntityScheme() {
        return entityScheme;
    }
    public void setEntityScheme(String entityScheme) {
        this.entityScheme = entityScheme;
    }
    public String getExplicitMemberDimension() {
        return explicitMemberDimension;
    }
    public void setExplicitMemberDimension(String explicitMemberDimension) {
        this.explicitMemberDimension = "siconfi-dim:"+explicitMemberDimension+"Axis";
    }
    public String getSiconfiDimension() {
        return siconfiDimension;
    }
    public void setSiconfiDimension(String siconfiDimension) {
        this.siconfiDimension = "siconfi-dim:"+siconfiDimension+"Member";
    }
    public String getSecondaryExplicitMemberDimension() {
        return secondaryExplicitMemberDimension;
    }
    public void setSecondaryExplicitMemberDimension(String secondaryExplicitMemberDimension) {
        this.secondaryExplicitMemberDimension = "siconfi-dim:"+secondaryExplicitMemberDimension+"Axis";
    }
    public String getSecondarySiconfiDimension() {
        return secondarySiconfiDimension;
    }
    public void setSecondarySiconfiDimension(String secondarySiconfiDimension) {
        this.secondarySiconfiDimension = "siconfi-dim:"+secondarySiconfiDimension+"Member";
    }    
    public String getPeriodStartDate() {
        return periodStartDate;
    }    
    public void setPeriodStartDate(String periodStartDate) {
        this.periodStartDate = periodStartDate;
    }
    public String getPeriodEndDate() {
        return periodEndDate;
    }
    public void setPeriodEndDate(String periodEndDate) {
        this.periodEndDate = periodEndDate;
    }
    public boolean getHasCoupledAxis (){
        return hasCoupledAxis;
    }    
    public void setHasCoupledAxis (boolean hasCoupledAxis){
        this.hasCoupledAxis = hasCoupledAxis;
    }
    public String toString() {
        return id;
    }
}
